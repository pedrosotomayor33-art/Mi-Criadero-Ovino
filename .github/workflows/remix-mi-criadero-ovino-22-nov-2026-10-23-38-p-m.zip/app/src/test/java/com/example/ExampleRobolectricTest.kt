package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: CriaderoDatabase
    private lateinit var repo: CriaderoRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, CriaderoDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = CriaderoRepository(db)
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `app name matches Mi Criadero Ovino`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Mi Criadero Ovino", context.getString(R.string.app_name))
    }

    @Test
    fun `rejects duplicate arete and registers parto with automatic lamb creation`() = runTest {
        val now = System.currentTimeMillis()
        val madreRes = repo.saveAnimal(
            AnimalEntity(
                arete = "CL-901",
                nombre = "Luna",
                sexo = "Hembra",
                raza = "Suffolk Down",
                fechaNacimiento = now - 900 * CriaderoRepository.DAY_MS,
                pesoNacimientoKg = 4.0,
                pesoActualKg = 68.0,
                fechaIngreso = now
            )
        )
        assertTrue(madreRes.isSuccess)
        val madreId = madreRes.getOrThrow()

        // Duplicado debe fallar
        val dupRes = repo.saveAnimal(
            AnimalEntity(
                arete = "CL-901",
                sexo = "Hembra",
                raza = "Corriedale",
                fechaNacimiento = now,
                pesoNacimientoKg = 4.0,
                pesoActualKg = 4.0,
                fechaIngreso = now
            )
        )
        assertTrue(dupRes.isFailure)

        // Registrar parto mellizo crea 2 fichas de cordero automáticamente
        val partoRes = repo.registrarPartoYCrearCorderos(
            madreId = madreId,
            padreId = null,
            fechaParto = now,
            asistencia = "Normal",
            observaciones = "Parto normal",
            crias = listOf(
                LambBirthInput("CL-902", "Sol", "Macho", 4.3, true),
                LambBirthInput("CL-903", "Nube", "Hembra", 3.9, true)
            )
        )
        assertEquals(2, partoRes.getOrThrow())

        val animales = repo.animales.first()
        assertEquals(3, animales.size)
        val cordero = animales.first { it.arete == "CL-902" }
        assertEquals(madreId, cordero.madreId)
        assertEquals(4.3, cordero.pesoActualKg, 0.01)
    }

    @Test
    fun `detects consanguinity and calculates GMD accurately`() = runTest {
        val now = System.currentTimeMillis()
        val padreId = repo.saveAnimal(
            AnimalEntity(
                arete = "CL-P1",
                sexo = "Macho",
                raza = "Suffolk Down",
                fechaNacimiento = now - 1000 * CriaderoRepository.DAY_MS,
                pesoNacimientoKg = 4.5,
                pesoActualKg = 90.0,
                fechaIngreso = now
            )
        ).getOrThrow()

        val hijaId = repo.saveAnimal(
            AnimalEntity(
                arete = "CL-H1",
                sexo = "Hembra",
                raza = "Suffolk Down",
                fechaNacimiento = now - 400 * CriaderoRepository.DAY_MS,
                pesoNacimientoKg = 4.0,
                pesoActualKg = 55.0,
                padreId = padreId,
                fechaIngreso = now
            )
        ).getOrThrow()

        val animales = repo.animales.first()
        val consang = repo.checkConsanguinity(hijaId, padreId, animales)
        assertTrue(consang.hayParentesco)
        assertEquals("Alto Riesgo", consang.nivelRiesgo)

        // GMD de 10 kg en 40 días = 250 g/día
        val p1 = PesajeEntity(id = 1, animalId = hijaId, fecha = now - 40 * CriaderoRepository.DAY_MS, pesoKg = 45.0, edadDias = 360)
        val p2 = PesajeEntity(id = 2, animalId = hijaId, fecha = now, pesoKg = 55.0, edadDias = 400)
        val stats = repo.calculateWeightStats(animales.first { it.id == hijaId }, listOf(p1, p2))
        assertEquals(250.0, stats.gmdGramsPerDay!!, 1.0)
        assertEquals(10.0, stats.gananciaUltimoPesajeKg!!, 0.01)
    }

    @Test
    fun `maps each ovine disease category to its photo resource`() {
        assertEquals(
            com.example.ui.components.OvineDiseaseType.PODAL,
            com.example.ui.components.OvineDiseaseType.resolve("Tratamiento", "Pododermatitis leve (Pietín)")
        )
        assertEquals(
            com.example.ui.components.OvineDiseaseType.PARASITARIA,
            com.example.ui.components.OvineDiseaseType.resolve("Desparasitación", "Control parasitosis gastrointestinal")
        )
        assertEquals(
            com.example.ui.components.OvineDiseaseType.INFECCIOSA,
            com.example.ui.components.OvineDiseaseType.resolve("Vacunación", "Prevención Clostridiosis preparto")
        )
        assertEquals(
            com.example.ui.components.OvineDiseaseType.RESPIRATORIA,
            com.example.ui.components.OvineDiseaseType.resolve("Tratamiento", "Neumonía aguda")
        )
        assertEquals(
            com.example.ui.components.OvineDiseaseType.METABOLICA,
            com.example.ui.components.OvineDiseaseType.resolve("Vitaminas y minerales", "Mastitis / Carencia de selenio")
        )
    }

    @Test
    fun `lossless v2 JSON backup roundtrip preserves all farm modules`() = runTest {
        val now = System.currentTimeMillis()
        val payload = FullCriaderoBackupPayload(
            version = 2,
            exportedAt = now,
            predioNombre = "Fundo Santa Elena",
            animales = listOf(
                AnimalEntity(
                    id = 10L,
                    arete = "CL-777",
                    nombre = "Austral",
                    sexo = "Hembra",
                    raza = "Suffolk Down",
                    fechaNacimiento = now - 500 * CriaderoRepository.DAY_MS,
                    pesoNacimientoKg = 4.2,
                    pesoActualKg = 62.5,
                    fechaIngreso = now,
                    prenada = true,
                    observaciones = "Registro completo"
                )
            ),
            pesajes = listOf(
                PesajeEntity(id = 20L, animalId = 10L, fecha = now, pesoKg = 62.5, edadDias = 500)
            ),
            sanidad = listOf(
                SanidadEntity(id = 30L, animalId = 10L, tipoManejo = "Vacunación", diagnostico = "Clostridiosis", fecha = now)
            ),
            potreros = listOf(
                PotreroEntity(id = 40L, nombre = "Potrero Norte", superficieHa = 4.5, tipoPradera = "Ballica", disponibilidadForrajeKgMsHa = 2400.0)
            ),
            transacciones = listOf(
                TransaccionEconomicaEntity(id = 50L, tipo = "Ingreso", categoria = "Venta de corderos", montoClp = 450000.0, fecha = now)
            ),
            lotes = listOf(
                LoteEntity(id = 60L, nombre = "Lote Engorda", criterio = "Peso", objetivoProductivo = "Engorda")
            )
        )

        val json = BackupJsonSerializer.serializeFullBackup(payload, pretty = false)
        val parsed = BackupJsonSerializer.parseFullBackup(json).getOrThrow()

        assertEquals(2, parsed.version)
        assertEquals("Fundo Santa Elena", parsed.predioNombre)
        assertEquals(6, parsed.totalRecords())
        assertEquals("CL-777", parsed.animales.first().arete)
        assertTrue(parsed.animales.first().prenada)
        assertEquals(62.5, parsed.pesajes.first().pesoKg, 0.01)
        assertEquals("Clostridiosis", parsed.sanidad.first().diagnostico)
        assertEquals("Potrero Norte", parsed.potreros.first().nombre)
        assertEquals(450000.0, parsed.transacciones.first().montoClp, 0.01)
        assertEquals("Lote Engorda", parsed.lotes.first().nombre)
    }

    @Test
    fun `cloud animal DTO maps cleanly to domain entity and admin email matches bootstrapped owner`() {
        val dto = CloudAnimalDto(
            docId = "101",
            recordId = 101L,
            memberUids = listOf("u1"),
            arete = "CL-101",
            nombre = "Canela",
            sexo = "Hembra",
            raza = "Corriedale",
            pesoNacimientoKg = 3.8,
            pesoActualKg = 54.0,
            registroActivo = true
        )
        val entity = dto.toEntity()
        assertEquals(101L, entity.id)
        assertEquals("CL-101", entity.arete)
        assertEquals("Canela", entity.nombre)
        assertEquals(54.0, entity.pesoActualKg, 0.01)
        assertEquals("criadero_principal", CloudSchema.DEFAULT_CRIADERO_ID)
        assertEquals("", CriaderoWorkspace().pendingAdminEmail)
    }
}
