package com.example

import com.example.data.*
import com.example.util.ChileanFormatters
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun cloudSchemaHasNoFixedAdminAndDefaultsCleanly() {
        assertEquals("criadero_principal", CloudSchema.DEFAULT_CRIADERO_ID)
        val session = CloudAccessSession()
        assertFalse(session.isAuthorized)
        assertFalse(session.isAdmin)
        assertEquals("", CriaderoWorkspace().pendingAdminEmail)
    }

    @Test
    fun formattersAndAgeClassificationWorkCorrectly() {
        val now = System.currentTimeMillis()
        val lamb = AnimalEntity(
            id = 1L,
            arete = "CL-001",
            sexo = "Hembra",
            raza = "Suffolk Down",
            fechaNacimiento = now - 60L * 86_400_000L,
            pesoNacimientoKg = 4.0,
            pesoActualKg = 18.5,
            fechaIngreso = now
        )
        assertEquals("Cordera", ChileanFormatters.animalCategory(lamb, now))
        assertTrue(ChileanFormatters.formatKg(18.5).contains("18"))
    }

    @Test
    fun buildConfigAdminEmailIsString() {
        assertNotNull(BuildConfig.CRIADERO_ADMIN_EMAIL)
    }
}
