package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        AnimalEntity::class,
        PesajeEntity::class,
        EncasteEntity::class,
        GestacionEntity::class,
        PartoEntity::class,
        SanidadEntity::class,
        PotreroEntity::class,
        MovimientoPotreroEntity::class,
        AlimentoRacionEntity::class,
        InventarioItemEntity::class,
        MovimientoInventarioEntity::class,
        TransaccionEconomicaEntity::class,
        LoteEntity::class,
        DesteteEntity::class,
        UserAccountEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CriaderoDatabase : RoomDatabase() {
    abstract fun criaderoDao(): CriaderoDao

    companion object {
        @Volatile
        private var INSTANCE: CriaderoDatabase? = null

        fun getInstance(context: Context): CriaderoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CriaderoDatabase::class.java,
                    "mi_criadero_ovino.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    DatabaseSeeder.seedIfEmpty(database.criaderoDao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
