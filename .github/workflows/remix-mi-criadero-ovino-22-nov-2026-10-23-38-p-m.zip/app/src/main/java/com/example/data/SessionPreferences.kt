package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "criadero_prefs")

class SessionPreferences(private val context: Context) {
    companion object {
        private val KEY_ACTIVE_USER_ID = longPreferencesKey("active_user_id")
        private val KEY_PREDIO_NOMBRE = stringPreferencesKey("predio_nombre")
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode") // "SYSTEM", "LIGHT", "DARK"
        private val KEY_CRIADERO_ID = stringPreferencesKey("criadero_id")
    }

    val activeUserIdFlow: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_ACTIVE_USER_ID] ?: 1L
    }

    val predioNombreFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_PREDIO_NOMBRE] ?: "Fundo Santa Elena · Biobío"
    }

    val themeModeFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_THEME_MODE] ?: "SYSTEM"
    }

    val criaderoIdFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_CRIADERO_ID]?.takeIf { it.isNotBlank() } ?: CloudSchema.DEFAULT_CRIADERO_ID
    }

    suspend fun setActiveUserId(userId: Long) {
        context.dataStore.edit { it[KEY_ACTIVE_USER_ID] = userId }
    }

    suspend fun setPredioNombre(nombre: String) {
        context.dataStore.edit { it[KEY_PREDIO_NOMBRE] = nombre.ifBlank { "Mi Criadero Ovino" } }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode }
    }

    suspend fun setCriaderoId(id: String) {
        val clean = id.trim().replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        if (clean.isNotBlank()) {
            context.dataStore.edit { it[KEY_CRIADERO_ID] = clean.take(64) }
        }
    }
}
