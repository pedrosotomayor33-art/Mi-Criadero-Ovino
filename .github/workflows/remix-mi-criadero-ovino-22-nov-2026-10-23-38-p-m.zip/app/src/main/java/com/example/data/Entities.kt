package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "animales",
    indices = [Index(value = ["arete"], unique = true)]
)
data class AnimalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val arete: String,
    val nombre: String = "",
    val photoUri: String? = null,
    val sexo: String, // "Hembra", "Macho"
    val raza: String, // "Suffolk Down", "Corriedale", "Texel", "Merino Precoz", "Romney Marsh", "Chilota", "Criolla"
    val fechaNacimiento: Long,
    val pesoNacimientoKg: Double,
    val pesoActualKg: Double,
    val madreId: Long? = null,
    val padreId: Long? = null,
    val tipoNacimiento: String = "Único", // "Único", "Mellizo", "Trillizo"
    val predioOrigen: String = "Propio",
    val fechaIngreso: Long,
    val estado: String = "Activo", // "Activo", "Venta", "Muerte", "Consumo", "Descarte"
    val proposito: String = "Reproducción", // "Reproducción", "Engorda", "Reemplazo", "Venta"
    val potreroId: Long? = null,
    val loteId: Long? = null,
    val prenada: Boolean = false,
    val fechaProbableParto: Long? = null,
    val destetado: Boolean = false,
    val observaciones: String = ""
)

@Entity(tableName = "pesajes")
data class PesajeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val animalId: Long,
    val fecha: Long,
    val pesoKg: Double,
    val edadDias: Int,
    val observaciones: String = ""
)

@Entity(tableName = "encastes")
data class EncasteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fechaInicio: Long,
    val fechaTermino: Long,
    val carneroId: Long,
    val ovejaIdsCsv: String, // IDs separados por coma
    val metodo: String = "Monta natural", // "Monta natural", "Inseminación artificial"
    val observaciones: String = ""
)

@Entity(tableName = "gestaciones")
data class GestacionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ovejaId: Long,
    val carneroId: Long? = null,
    val encasteId: Long? = null,
    val fechaEncaste: Long,
    val fechaDiagnostico: Long,
    val estadoGestacion: String = "Preñada", // "Preñada", "Vacía", "Dudosa", "Parida", "Aborto"
    val numeroFetos: Int = 1,
    val fechaProbableParto: Long,
    val observaciones: String = ""
)

@Entity(tableName = "partos")
data class PartoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val madreId: Long,
    val padreId: Long? = null,
    val fechaParto: Long,
    val cantidadCrias: Int,
    val criasVivas: Int,
    val criasMuertas: Int,
    val tipoParto: String, // "Único", "Mellizo", "Trillizo"
    val asistencia: String = "Normal", // "Normal", "Asistido", "Cesárea"
    val detalleCrias: String = "", // Ej: "Hembra 4,1 kg (Viva); Macho 3,8 kg (Vivo)"
    val observaciones: String = ""
)

@Entity(tableName = "registros_sanitarios")
data class SanidadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val animalId: Long? = null, // null si es manejo colectivo por lote
    val loteNombre: String? = null,
    val tipoManejo: String, // "Tratamiento", "Vacunación", "Desparasitación", "Vitaminas y minerales", "Revisión", "Manejo podal"
    val diagnostico: String,
    val fecha: Long,
    val sintomas: String = "",
    val medicamento: String = "",
    val principioActivo: String = "",
    val dosis: Double = 0.0,
    val unidadDosis: String = "ml",
    val viaAdministracion: String = "Subcutánea",
    val duracionDias: Int = 1,
    val fechaProximaDosis: Long? = null,
    val veterinario: String = "",
    val evolucion: String = "En tratamiento", // "En tratamiento", "Recuperado", "Programado", "Crónico"
    val observaciones: String = ""
)

@Entity(tableName = "potreros")
data class PotreroEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val superficieHa: Double,
    val tipoPradera: String, // "Ballica + Trébol blanco", "Alfalfa", "Pradera natural", "Avena forrajera", "Festuca"
    val disponibilidadForrajeKgMsHa: Double,
    val estadoPasto: String = "Óptimo", // "Óptimo", "En uso", "En descanso", "Degradado"
    val fechaEntrada: Long? = null,
    val fechaSalida: Long? = null,
    val diasDescansoObjetivo: Int = 30,
    val posicionX: Float = 0.1f,
    val posicionY: Float = 0.1f,
    val observaciones: String = ""
)

@Entity(tableName = "movimientos_potrero")
data class MovimientoPotreroEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val potreroOrigenId: Long? = null,
    val potreroDestinoId: Long,
    val cantidadAnimales: Int,
    val animalIdsCsv: String,
    val fechaMovimiento: Long,
    val motivo: String = "Rotación de pradera",
    val observaciones: String = ""
)

@Entity(tableName = "raciones_alimento")
data class AlimentoRacionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val tipoAlimento: String, // "Avena", "Concentrado", "Heno", "Ensilaje", "Pradera", "Sales minerales", "Otro"
    val ingrediente: String,
    val cantidadKg: Double,
    val porcentajeInclusion: Double,
    val costoPorKgClp: Double,
    val cantidadDiariaAnimalKg: Double,
    val grupoDestinatario: String,
    val cantidadAnimales: Int,
    val stockDisponibleKg: Double,
    val observaciones: String = ""
)

@Entity(tableName = "inventario")
data class InventarioItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val categoria: String, // "Medicamentos", "Vacunas", "Antiparasitarios", "Alimentos", "Fardos", "Minerales", "Insumos veterinarios"
    val unidad: String, // "ml", "dosis", "kg", "fardos", "unidades"
    val cantidadDisponible: Double,
    val stockMinimo: Double,
    val fechaVencimiento: Long? = null,
    val ultimoCostoUnitarioClp: Double = 0.0,
    val observaciones: String = ""
)

@Entity(tableName = "movimientos_inventario")
data class MovimientoInventarioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val tipo: String, // "Entrada / Compra", "Salida / Consumo"
    val cantidad: Double,
    val fecha: Long,
    val costoTotalClp: Double = 0.0,
    val nota: String = ""
)

@Entity(tableName = "transacciones_economicas")
data class TransaccionEconomicaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tipo: String, // "Ingreso", "Gasto"
    val categoria: String,
    val montoClp: Double,
    val fecha: Long,
    val cantidadKg: Double? = null,
    val animalId: Long? = null,
    val loteId: Long? = null,
    val descripcion: String = ""
)

@Entity(tableName = "lotes")
data class LoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val criterio: String, // "Edad", "Sexo", "Peso", "Raza", "Estado sanitario", "Potrero", "Objetivo productivo"
    val objetivoProductivo: String, // "Engorda", "Reproducción", "Reemplazo", "Destete", "Tratamiento"
    val potreroId: Long? = null,
    val observaciones: String = ""
)

@Entity(tableName = "destetes")
data class DesteteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val corderoId: Long,
    val madreId: Long? = null,
    val fecha: Long,
    val pesoKg: Double,
    val tipoDestete: String = "Tradicional", // "Tradicional", "Precoz", "Temporario"
    val loteDestinoId: Long? = null,
    val observaciones: String = ""
)

@Entity(tableName = "usuarios")
data class UserAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val rol: String, // "Administrador", "Consulta"
    val etiqueta: String, // "Administrador", "Socio 1", "Socio 2", etc.
    val activo: Boolean = true
)
