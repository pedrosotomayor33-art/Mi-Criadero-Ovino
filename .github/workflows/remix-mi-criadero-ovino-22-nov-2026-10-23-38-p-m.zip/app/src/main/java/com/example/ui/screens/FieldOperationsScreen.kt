package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.*
import com.example.ui.CriaderoUiState
import com.example.ui.CriaderoViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.ChileanFormatters
import java.util.concurrent.TimeUnit

@Composable
fun FieldOperationsScreen(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel
) {
    var activeTab by remember { mutableIntStateOf(0) }
    var selectedPotreroId by remember { mutableStateOf(state.potreros.firstOrNull()?.id) }
    var selectedDiseaseFilter by remember { mutableStateOf<OvineDiseaseType?>(null) }
    var preselectedDiseaseForDialog by remember { mutableStateOf<OvineDiseaseType?>(null) }
    var previewPhoto by remember { mutableStateOf<Pair<OvineDiseaseType, String>?>(null) }

    var showSanidadDialog by remember { mutableStateOf(false) }
    var showPotreroDialog by remember { mutableStateOf(false) }
    var showMovePotreroDialog by remember { mutableStateOf(false) }
    var showRacionDialog by remember { mutableStateOf(false) }
    var showLoteDialog by remember { mutableStateOf(false) }
    var showDesteteDialog by remember { mutableStateOf(false) }
    var pendingDeleteSanidad by remember { mutableStateOf<SanidadEntity?>(null) }
    var pendingDeleteRacion by remember { mutableStateOf<AlimentoRacionEntity?>(null) }

    val animalById = remember(state.animales) { state.animales.associateBy { it.id } }
    val potreroById = remember(state.potreros) { state.potreros.associateBy { it.id } }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            if (state.canEdit) {
                FloatingActionButton(
                    onClick = {
                        when (activeTab) {
                            0 -> {
                                preselectedDiseaseForDialog = selectedDiseaseFilter
                                showSanidadDialog = true
                            }
                            1 -> showMovePotreroDialog = true
                            2 -> showRacionDialog = true
                            3 -> showDesteteDialog = true
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "Agregar registro de campo")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            TabRow(selectedTabIndex = activeTab) {
                listOf("Sanidad", "Potreros", "Alimento", "Destete").forEachIndexed { idx, title ->
                    Tab(
                        selected = activeTab == idx,
                        onClick = { activeTab = idx },
                        text = { Text(title, maxLines = 1) }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                when (activeTab) {
                    0 -> { // SANIDAD Y ENFERMEDADES
                        item(key = "disease_gallery") {
                            DiseaseTypesGallerySection(
                                sanidadRecords = state.sanidad,
                                selectedDisease = selectedDiseaseFilter,
                                canEdit = state.canEdit,
                                onSelectDisease = { selectedDiseaseFilter = it },
                                onRegisterForDisease = { type ->
                                    preselectedDiseaseForDialog = type
                                    showSanidadDialog = true
                                }
                            )
                        }

                        val filteredSanidad = if (selectedDiseaseFilter == null) {
                            state.sanidad
                        } else {
                            state.sanidad.filter { OvineDiseaseType.resolve(it) == selectedDiseaseFilter }
                        }

                        item(key = "sanidad_list_header") {
                            Text(
                                text = if (selectedDiseaseFilter == null) {
                                    "Registros sanitarios y enfermedades (${filteredSanidad.size})"
                                } else {
                                    "Casos de ${selectedDiseaseFilter!!.shortTitle} (${filteredSanidad.size})"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        if (filteredSanidad.isEmpty()) {
                            item(key = "empty_sanidad") {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Text(
                                        text = "No hay casos registrados para esta enfermedad todavía.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(16.dp)
                                    )
                                }
                            }
                        } else {
                            items(filteredSanidad, key = { it.id }) { s ->
                                val sujeto = s.animalId?.let { animalById[it]?.arete } ?: s.loteNombre ?: "Rebaño"
                                val diseaseType = OvineDiseaseType.resolve(s)
                                val color = when (s.evolucion) {
                                    "Recuperado" -> MeadowGreen
                                    "En tratamiento" -> CrimsonAlert
                                    else -> EarthTerracotta
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            DiseaseThumbnail(
                                                diseaseType = diseaseType,
                                                size = 82.dp,
                                                onClick = { previewPhoto = diseaseType to s.diagnostico }
                                            )
                                            Column(
                                                modifier = Modifier.weight(1f),
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Row(
                                                    Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "${s.tipoManejo} · $sujeto",
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Surface(color = color.copy(alpha = 0.14f), shape = RoundedCornerShape(6.dp)) {
                                                        Text(
                                                            text = s.evolucion,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = color,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Text(s.diagnostico, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                                Surface(
                                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = diseaseType.shortTitle,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                        if (s.medicamento.isNotBlank()) {
                                            Text(
                                                text = "${s.medicamento} (${s.principioActivo}) · ${s.dosis} ${s.unidadDosis} ${s.viaAdministracion}",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                        Text(
                                            text = "Fecha: ${ChileanFormatters.formatDate(s.fecha)}" +
                                                (s.fechaProximaDosis?.let { " · Próx: ${ChileanFormatters.formatDate(it)}" } ?: ""),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (state.canEdit) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                if (s.evolucion != "Recuperado") {
                                                    TextButton(onClick = { viewModel.marcarSanidadRecuperada(s) }) {
                                                        Text("Marcar recuperado")
                                                    }
                                                }
                                                TextButton(
                                                    onClick = { pendingDeleteSanidad = s },
                                                    colors = ButtonDefaults.textButtonColors(contentColor = CrimsonAlert)
                                                ) {
                                                    Text("Eliminar")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> { // POTREROS Y ROTACIÓN
                        val animalesPorPotrero = state.animales
                            .filter { it.estado == "Activo" && it.potreroId != null }
                            .groupingBy { it.potreroId!! }
                            .eachCount()

                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Mapa esquemático de potreros", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (state.canEdit) {
                                    TextButton(onClick = { showPotreroDialog = true }) {
                                        Text("+ Nuevo potrero")
                                    }
                                }
                            }
                            PastureSchematicMap(
                                potreros = state.potreros,
                                animalesPorPotrero = animalesPorPotrero,
                                selectedPotreroId = selectedPotreroId,
                                onSelectPotrero = { selectedPotreroId = it.id }
                            )
                        }

                        items(state.potreros, key = { it.id }) { p ->
                            val count = animalesPorPotrero[p.id] ?: 0
                            val now = System.currentTimeMillis()
                            val diasOcupacion = p.fechaEntrada?.let { maxOf(0L, TimeUnit.MILLISECONDS.toDays(now - it)) }
                            val diasDescanso = p.fechaSalida?.let { maxOf(0L, TimeUnit.MILLISECONDS.toDays(now - it)) }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                border = BorderStroke(1.dp, if (p.id == selectedPotreroId) ForestGreen else MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(p.nombre, fontWeight = FontWeight.Bold, color = ForestGreen)
                                        Text("${ChileanFormatters.formatNumber(p.superficieHa)} ha · $count ovinos", style = MaterialTheme.typography.labelLarge)
                                    }
                                    Text("${p.tipoPradera} · ${p.disponibilidadForrajeKgMsHa.toInt()} kg MS/ha", style = MaterialTheme.typography.bodySmall)
                                    val tiempoStr = when {
                                        p.estadoPasto == "En uso" && diasOcupacion != null -> "Ocupación actual: $diasOcupacion días"
                                        p.estadoPasto == "En descanso" && diasDescanso != null -> "En descanso: $diasDescanso / ${p.diasDescansoObjetivo} días"
                                        else -> "Disponible para pastoreo"
                                    }
                                    Text("${p.estadoPasto} · $tiempoStr", style = MaterialTheme.typography.labelMedium, color = MeadowGreen)
                                    if (p.observaciones.isNotBlank()) Text(p.observaciones, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        if (state.movimientosPotrero.isNotEmpty()) {
                            item {
                                Text("Historial de rotaciones", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }
                            items(state.movimientosPotrero.take(8), key = { it.id }) { mov ->
                                val orig = mov.potreroOrigenId?.let { potreroById[it]?.nombre } ?: "Ingreso"
                                val dest = potreroById[mov.potreroDestinoId]?.nombre ?: "Potrero"
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                    Row(modifier = Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("$orig → $dest", style = MaterialTheme.typography.labelLarge)
                                            Text("${mov.cantidadAnimales} ovinos · ${mov.motivo}", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text(ChileanFormatters.formatDate(mov.fechaMovimiento), style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }

                    2 -> { // ALIMENTACIÓN Y RACIONES
                        val costoDiarioTotal = state.raciones.sumOf { it.cantidadDiariaAnimalKg * it.cantidadAnimales * it.costoPorKgClp }
                        item {
                            KpiMetricCard(
                                title = "Costo diario de suplementación",
                                value = ChileanFormatters.formatClp(costoDiarioTotal),
                                subtitle = "Proyección mensual: ${ChileanFormatters.formatClp(costoDiarioTotal * 30)}",
                                icon = Icons.Outlined.Grass,
                                accentColor = MeadowGreen
                            )
                        }
                        items(state.raciones, key = { it.id }) { r ->
                            val consumoDiarioTotal = r.cantidadDiariaAnimalKg * r.cantidadAnimales
                            val consumoMensual = consumoDiarioTotal * 30.0
                            val costoAnimalDia = r.cantidadDiariaAnimalKg * r.costoPorKgClp
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${r.nombre} (${r.tipoAlimento})", fontWeight = FontWeight.Bold, color = ForestGreen)
                                        Text(ChileanFormatters.formatClp(costoAnimalDia) + "/ovino·día", style = MaterialTheme.typography.labelMedium, color = EarthTerracotta)
                                    }
                                    Text("Ingrediente: ${r.ingrediente} (${r.porcentajeInclusion.toInt()}% inclusión)", style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        "Grupo: ${r.grupoDestinatario} (${r.cantidadAnimales} ovinos) · Consumo: ${ChileanFormatters.formatKg(consumoDiarioTotal)}/día (${ChileanFormatters.formatKg(consumoMensual)}/mes)",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        "Stock disponible: ${ChileanFormatters.formatKg(r.stockDisponibleKg)} · Costo: ${ChileanFormatters.formatClp(r.costoPorKgClp)}/kg",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (state.canEdit) {
                                        TextButton(
                                            onClick = { pendingDeleteRacion = r },
                                            colors = ButtonDefaults.textButtonColors(contentColor = CrimsonAlert)
                                        ) { Text("Eliminar ración") }
                                    }
                                }
                            }
                        }
                    }

                    3 -> { // DESTETE Y LOTES
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Lotes productivos (${state.lotes.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (state.canEdit) {
                                    TextButton(onClick = { showLoteDialog = true }) { Text("+ Crear lote") }
                                }
                            }
                        }
                        items(state.lotes, key = { "lote_${it.id}" }) { lote ->
                            val miembros = state.animales.filter { it.loteId == lote.id && it.estado == "Activo" }
                            val pesoProm = if (miembros.isNotEmpty()) miembros.map { it.pesoActualKg }.average() else 0.0
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(lote.nombre, fontWeight = FontWeight.Bold, color = ForestGreen)
                                        Text("${miembros.size} ovinos", style = MaterialTheme.typography.labelLarge)
                                    }
                                    Text("Criterio: ${lote.criterio} · Objetivo: ${lote.objetivoProductivo} · Promedio: ${ChileanFormatters.formatKg(pesoProm)}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        item {
                            Spacer(Modifier.height(6.dp))
                            Text("Destetes registrados (${state.destetes.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        items(state.destetes, key = { "dest_${it.id}" }) { d ->
                            val cordero = animalById[d.corderoId]
                            val madre = d.madreId?.let { animalById[it] }
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Cordero: ${cordero?.arete ?: "#${d.corderoId}"} (${d.tipoDestete})", fontWeight = FontWeight.Bold)
                                        Text("Madre: ${madre?.arete ?: "No reg."} · ${ChileanFormatters.formatDate(d.fecha)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(ChileanFormatters.formatKg(d.pesoKg), fontWeight = FontWeight.Bold, color = ForestGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSanidadDialog) {
        QuickSanidadDialog(
            initialDiseaseType = preselectedDiseaseForDialog,
            state = state,
            viewModel = viewModel
        ) {
            showSanidadDialog = false
            preselectedDiseaseForDialog = null
        }
    }
    previewPhoto?.let { (type, diag) ->
        DiseasePhotoPreviewDialog(diseaseType = type, diagnostico = diag) {
            previewPhoto = null
        }
    }
    if (showMovePotreroDialog) QuickMovePastureDialog(state = state, viewModel = viewModel) { showMovePotreroDialog = false }
    if (showPotreroDialog) AddPotreroDialog(state = state, viewModel = viewModel) { showPotreroDialog = false }
    if (showRacionDialog) AddRacionDialog(viewModel = viewModel) { showRacionDialog = false }
    if (showLoteDialog) AddLoteDialog(state = state, viewModel = viewModel) { showLoteDialog = false }
    if (showDesteteDialog) AddDesteteDialog(state = state, viewModel = viewModel) { showDesteteDialog = false }

    pendingDeleteSanidad?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDeleteSanidad = null },
            title = { Text("¿Enviar registro sanitario a Papelera?") },
            text = { Text("Se enviará '${item.diagnostico}' a la Papelera recuperable y quedará registrado en el historial.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSanidad(item)
                        pendingDeleteSanidad = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert)
                ) { Text("Enviar a Papelera") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteSanidad = null }) { Text("Cancelar") }
            }
        )
    }

    pendingDeleteRacion?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDeleteRacion = null },
            title = { Text("¿Enviar ración a Papelera?") },
            text = { Text("Se enviará '${item.nombre}' a la Papelera recuperable y quedará registrado en el historial.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRacion(item)
                        pendingDeleteRacion = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert)
                ) { Text("Enviar a Papelera") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteRacion = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun AddPotreroDialog(state: CriaderoUiState, viewModel: CriaderoViewModel, onDismiss: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var haStr by remember { mutableStateOf("4.0") }
    var pradera by remember { mutableStateOf("Ballica + Trébol blanco") }
    var forrajeStr by remember { mutableStateOf("2400") }
    var descansoStr by remember { mutableStateOf("30") }
    var obs by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo Potrero") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre o N° de potrero *") }, singleLine = true)
                OutlinedTextField(value = haStr, onValueChange = { haStr = it }, label = { Text("Superficie (ha)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(value = pradera, onValueChange = { pradera = it }, label = { Text("Tipo de pradera") }, singleLine = true)
                OutlinedTextField(value = forrajeStr, onValueChange = { forrajeStr = it }, label = { Text("Disponibilidad (kg MS/ha)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(value = descansoStr, onValueChange = { descansoStr = it }, label = { Text("Días de descanso objetivo") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(value = obs, onValueChange = { obs = it }, label = { Text("Observaciones") })
            }
        },
        confirmButton = {
            Button(onClick = {
                val idx = state.potreros.size
                val px = if (idx % 2 == 0) 0.08f else 0.54f
                val py = if ((idx / 2) % 2 == 0) 0.12f else 0.56f
                viewModel.savePotrero(
                    PotreroEntity(
                        nombre = nombre.trim(),
                        superficieHa = haStr.replace(",", ".").toDoubleOrNull() ?: 1.0,
                        tipoPradera = pradera,
                        disponibilidadForrajeKgMsHa = forrajeStr.toDoubleOrNull() ?: 2000.0,
                        estadoPasto = "Óptimo",
                        diasDescansoObjetivo = descansoStr.toIntOrNull() ?: 30,
                        posicionX = px,
                        posicionY = py,
                        observaciones = obs
                    ),
                    onSuccess = onDismiss
                )
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun AddRacionDialog(viewModel: CriaderoViewModel, onDismiss: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var tipo by remember { mutableStateOf("Avena") }
    var ingrediente by remember { mutableStateOf("") }
    var inclusionStr by remember { mutableStateOf("50") }
    var costoStr by remember { mutableStateOf("300") }
    var diariaStr by remember { mutableStateOf("0.5") }
    var grupo by remember { mutableStateOf("Ovejas preñadas") }
    var animalesStr by remember { mutableStateOf("10") }
    var stockStr by remember { mutableStateOf("250") }

    val tipos = listOf("Avena", "Concentrado", "Heno", "Ensilaje", "Pradera", "Sales minerales", "Otro")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva Ración / Suplemento") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre ración *") }, singleLine = true)
                DropdownField(label = "Tipo alimento", selectedText = tipo, options = tipos, onSelect = { tipo = tipos[it] })
                OutlinedTextField(value = ingrediente, onValueChange = { ingrediente = it }, label = { Text("Ingrediente principal") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = inclusionStr, onValueChange = { inclusionStr = it }, label = { Text("% inclusión") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = costoStr, onValueChange = { costoStr = it }, label = { Text("$/kg CLP") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = diariaStr, onValueChange = { diariaStr = it }, label = { Text("kg/ovino·día") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = animalesStr, onValueChange = { animalesStr = it }, label = { Text("N° ovinos") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = grupo, onValueChange = { grupo = it }, label = { Text("Grupo destinatario") }, singleLine = true)
                OutlinedTextField(value = stockStr, onValueChange = { stockStr = it }, label = { Text("Stock disponible (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                viewModel.saveRacion(
                    AlimentoRacionEntity(
                        nombre = nombre.trim(),
                        tipoAlimento = tipo,
                        ingrediente = ingrediente.ifBlank { tipo },
                        cantidadKg = stockStr.toDoubleOrNull() ?: 100.0,
                        porcentajeInclusion = inclusionStr.toDoubleOrNull() ?: 50.0,
                        costoPorKgClp = costoStr.toDoubleOrNull() ?: 300.0,
                        cantidadDiariaAnimalKg = diariaStr.replace(",", ".").toDoubleOrNull() ?: 0.5,
                        grupoDestinatario = grupo,
                        cantidadAnimales = animalesStr.toIntOrNull() ?: 1,
                        stockDisponibleKg = stockStr.replace(",", ".").toDoubleOrNull() ?: 100.0
                    ),
                    onSuccess = onDismiss
                )
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun AddLoteDialog(state: CriaderoUiState, viewModel: CriaderoViewModel, onDismiss: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var criterio by remember { mutableStateOf("Objetivo productivo") }
    var objetivo by remember { mutableStateOf("Engorda") }
    val selectedIds = remember { mutableStateListOf<Long>() }
    val criterios = listOf("Edad", "Sexo", "Peso", "Raza", "Estado sanitario", "Potrero", "Objetivo productivo")
    val objetivos = listOf("Engorda", "Reproducción", "Reemplazo", "Destete", "Tratamiento")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crear Lote de Ovinos") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre del lote *") }, singleLine = true)
                DropdownField(label = "Criterio", selectedText = criterio, options = criterios, onSelect = { criterio = criterios[it] })
                DropdownField(label = "Objetivo productivo", selectedText = objetivo, options = objetivos, onSelect = { objetivo = objetivos[it] })
                Text("Integrantes (${selectedIds.size}):", style = MaterialTheme.typography.labelLarge)
                state.animales.filter { it.estado == "Activo" }.forEach { a ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = selectedIds.contains(a.id), onCheckedChange = {
                            if (it) selectedIds.add(a.id) else selectedIds.remove(a.id)
                        })
                        Text("${a.arete} · ${a.raza} (${a.pesoActualKg} kg)", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                viewModel.saveLote(
                    LoteEntity(nombre = nombre.trim(), criterio = criterio, objetivoProductivo = objetivo),
                    selectedIds.toList(),
                    onSuccess = onDismiss
                )
            }) { Text("Guardar Lote") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun AddDesteteDialog(state: CriaderoUiState, viewModel: CriaderoViewModel, onDismiss: () -> Unit) {
    val candidatos = remember(state.animales) { state.animales.filter { it.estado == "Activo" && !it.destetado } }
    var corderoId by remember { mutableStateOf(candidatos.firstOrNull()?.id) }
    var pesoStr by remember { mutableStateOf(candidatos.firstOrNull()?.pesoActualKg?.toString() ?: "24.0") }
    var tipo by remember { mutableStateOf("Tradicional") }
    var loteId by remember { mutableStateOf(state.lotes.firstOrNull()?.id) }
    var obs by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Destete") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (candidatos.isEmpty()) {
                    Text("Todos los animales activos ya están destetados.")
                } else {
                    val sel = candidatos.firstOrNull { it.id == corderoId } ?: candidatos.first()
                    DropdownField(
                        label = "Cordero a destetar",
                        selectedText = "${sel.arete} · ${sel.nombre.ifBlank { sel.raza }}",
                        options = candidatos.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" },
                        onSelect = {
                            corderoId = candidatos[it].id
                            pesoStr = candidatos[it].pesoActualKg.toString()
                        }
                    )
                    OutlinedTextField(
                        value = pesoStr,
                        onValueChange = { pesoStr = it },
                        label = { Text("Peso al destete (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                    DropdownField(
                        label = "Tipo de destete",
                        selectedText = tipo,
                        options = listOf("Tradicional", "Precoz", "Temporario"),
                        onSelect = { tipo = listOf("Tradicional", "Precoz", "Temporario")[it] }
                    )
                    if (state.lotes.isNotEmpty()) {
                        val lTxt = state.lotes.firstOrNull { it.id == loteId }?.nombre ?: "Sin lote"
                        DropdownField(
                            label = "Lote destino (engorda / reemplazo)",
                            selectedText = lTxt,
                            options = state.lotes.map { it.nombre },
                            onSelect = { loteId = state.lotes[it].id }
                        )
                    }
                    OutlinedTextField(value = obs, onValueChange = { obs = it }, label = { Text("Observaciones") })
                }
            }
        },
        confirmButton = {
            Button(
                enabled = candidatos.isNotEmpty(),
                onClick = {
                    val cid = corderoId ?: return@Button
                    val p = pesoStr.replace(",", ".").toDoubleOrNull() ?: 20.0
                    viewModel.registrarDestete(cid, System.currentTimeMillis(), p, tipo, loteId, obs, onSuccess = onDismiss)
                }
            ) { Text("Registrar Destete") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
