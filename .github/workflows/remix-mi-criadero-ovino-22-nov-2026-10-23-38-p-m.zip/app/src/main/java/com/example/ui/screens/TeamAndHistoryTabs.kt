package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.*
import com.example.ui.CriaderoUiState
import com.example.ui.CriaderoViewModel
import com.example.ui.theme.*
import com.example.util.ChileanFormatters
import com.example.util.ReportExporter
import kotlinx.coroutines.launch

@Composable
fun HistoryAndTrashTab(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel
) {
    var actionFilter by remember { mutableStateOf("Todos") }
    var pendingPurgeItem by remember { mutableStateOf<DeletedRecordItem?>(null) }

    val actions = listOf("Todos", "CREAR", "ACTUALIZAR", "ELIMINAR", "RESTAURAR", "MIGRAR", "RESPALDO", "CONFIGURACION")
    val filteredLogs = remember(state.auditLogs, actionFilter) {
        if (actionFilter == "Todos") state.auditLogs
        else state.auditLogs.filter { it.accion == actionFilter }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.RestoreFromTrash, contentDescription = null, tint = ForestGreen)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Papelera y Recuperación (${state.deletedRecords.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "Los registros eliminados quedan protegidos aquí para evitar borrados accidentales.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (state.deletedRecords.isEmpty()) {
            item {
                Text(
                    text = "La papelera está vacía.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        } else {
            items(state.deletedRecords, key = { "${it.collection}_${it.docId}" }) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = AmberSoft.copy(alpha = 0.55f)),
                    border = BorderStroke(1.dp, EarthTerracotta.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${item.modulo} · ${item.titulo}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (item.eliminadoAt > 0L) {
                                Text(ChileanFormatters.formatDateTime(item.eliminadoAt), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        if (item.detalle.isNotBlank()) {
                            Text(item.detalle, style = MaterialTheme.typography.bodySmall)
                        }
                        if (item.eliminadoPor.isNotBlank()) {
                            Text("Eliminado por: ${item.eliminadoPor}", style = MaterialTheme.typography.labelSmall, color = SaddleBrown)
                        }
                        if (state.canEdit) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { viewModel.restoreDeletedRecord(item) }) {
                                    Icon(Icons.Filled.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Restaurar")
                                }
                                TextButton(
                                    onClick = { pendingPurgeItem = item },
                                    colors = ButtonDefaults.textButtonColors(contentColor = CrimsonAlert)
                                ) {
                                    Text("Eliminar definitivo")
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
            Text(
                text = "Historial de Cambios (${filteredLogs.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                actions.forEach { act ->
                    FilterChip(
                        selected = actionFilter == act,
                        onClick = { actionFilter = act },
                        label = { Text(act) }
                    )
                }
            }
        }

        if (filteredLogs.isEmpty()) {
            item {
                Text(
                    text = "Aún no hay movimientos registrados en este filtro.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(filteredLogs, key = { it.docId.ifBlank { "${it.fechaClienteMs}_${it.entidadId}_${it.resumen}" } }) { log ->
                val pillColor = when (log.accion) {
                    "CREAR" -> MeadowGreen
                    "ACTUALIZAR" -> SkyInfo
                    "ELIMINAR" -> CrimsonAlert
                    "RESTAURAR" -> ForestGreen
                    else -> EarthTerracotta
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val logTime = log.createdAt?.toDate()?.time ?: log.fechaClienteMs
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(color = pillColor.copy(alpha = 0.14f), shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = "${log.accion} · ${log.modulo}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = pillColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Text(
                                text = ChileanFormatters.formatDateTime(logTime),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (log.entidadNombre.isNotBlank()) {
                            Text("${log.entidadNombre} (#${log.entidadId})", fontWeight = FontWeight.Bold)
                        }
                        Text(log.resumen, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "Por: ${log.actorNombre} (${log.actorEmail}) · UID ${log.actorUid.take(8)}… · ${log.actorRol}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (log.valorAnterior.isNotBlank() || log.valorNuevo.isNotBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    if (log.valorAnterior.isNotBlank()) {
                                        Text("Anterior: ${log.valorAnterior}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    if (log.valorNuevo.isNotBlank()) {
                                        Text("Nuevo: ${log.valorNuevo}", style = MaterialTheme.typography.labelSmall, color = ForestGreen)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingPurgeItem?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingPurgeItem = null },
            title = { Text("¿Eliminar definitivamente?") },
            text = { Text("Esta acción eliminará permanentemente '${item.titulo}' de la base de datos y no se podrá recuperar.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.purgeDeletedRecord(item)
                        pendingPurgeItem = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert)
                ) { Text("Eliminar para siempre") }
            },
            dismissButton = {
                TextButton(onClick = { pendingPurgeItem = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
fun TeamCloudAndBackupTab(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val ws = state.cloudSession.workspace

    var predioInput by remember(state.predioNombre) { mutableStateOf(state.predioNombre) }
    var socio1Input by remember(ws?.socio1Email) { mutableStateOf(ws?.socio1Email.orEmpty()) }
    var socio2Input by remember(ws?.socio2Email) { mutableStateOf(ws?.socio2Email.orEmpty()) }

    var showMigrateConfirm by remember { mutableStateOf(false) }
    var showCreateCloudBackupDialog by remember { mutableStateOf(false) }
    var showEncryptedExportDialog by remember { mutableStateOf(false) }
    var showTransferAdminDialog by remember { mutableStateOf(false) }
    var transferTargetEmail by remember { mutableStateOf("") }
    var backupPassphraseInput by remember { mutableStateOf("") }
    var importPassphraseInput by remember { mutableStateOf("") }
    var backupNameInput by remember { mutableStateOf("Respaldo ${ChileanFormatters.formatDate(System.currentTimeMillis())}") }
    var pendingRestoreCloudBackup by remember { mutableStateOf<CloudBackupSnapshot?>(null) }
    var pendingRestoreJsonPair by remember { mutableStateOf<Pair<String, String>?>(null) }

    val jsonPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            }.onSuccess { text ->
                if (!text.isNullOrBlank()) {
                    pendingRestoreJsonPair = text to (uri.lastPathSegment ?: "archivo.json")
                } else {
                    viewModel.notifyMessage("El archivo JSON seleccionado está vacío.")
                }
            }.onFailure {
                viewModel.notifyMessage("No se pudo leer el archivo seleccionado.")
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Estado de Cuenta y Sincronización
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftMint.copy(alpha = 0.55f)),
                border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (state.canEdit) Icons.Filled.AdminPanelSettings else Icons.Filled.Visibility,
                            contentDescription = null,
                            tint = ForestGreen
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "${state.activeUser?.etiqueta ?: "Cuenta"} · ${state.activeUser?.rol ?: "Consulta"}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = state.cloudSession.currentMember?.email ?: "",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = when {
                            !state.isOnline -> "Sin conexión a internet: usando caché local persistente (protegida por cifrado de sistema Android)."
                            state.isSyncPendingWrites -> "Sincronizando cambios locales hacia Firestore..."
                            else -> "Conectado y sincronizado en tiempo real (Plan gratuito Spark)."
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (!state.isOnline) EarthTerracotta else ForestGreen
                    )
                    Text(
                        text = "Código de Criadero: ${state.cloudSession.criaderoId}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!state.syncErrorMessage.isNullOrBlank()) {
                        Text(
                            text = "Aviso de sincronización: ${state.syncErrorMessage}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CrimsonAlert
                        )
                    }
                }
            }
        }

        // 2. Equipo Multiusuario (3 Cuentas Reales)
        item {
            Text("Equipo del Criadero (3 teléfonos)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = ForestGreen)
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Administrador Principal (Control Total)", fontWeight = FontWeight.Bold)
                            Text(
                                text = ws?.adminEmail?.ifBlank { "No asignado" } ?: "No asignado",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (state.canEdit) {
                            TextButton(onClick = { showTransferAdminDialog = true }) {
                                Text("Transferir")
                            }
                        }
                    }

                    if (!ws?.pendingAdminEmail.isNullOrBlank()) {
                        Surface(
                            color = AmberSoft.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Traspaso pendiente a: ${ws.pendingAdminEmail}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SaddleBrown,
                                    modifier = Modifier.weight(1f)
                                )
                                if (state.canEdit) {
                                    TextButton(onClick = { viewModel.requestAdminTransfer("") }) {
                                        Text("Cancelar")
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider()

                    if (state.canEdit) {
                        Text(
                            text = "Autoriza aquí los correos Google exactos de Socio 1 y Socio 2. Solo podrán consultar los datos en sus teléfonos.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = socio1Input,
                            onValueChange = { socio1Input = it },
                            label = { Text("Correo Google · Socio 1 (Solo Consulta)") },
                            placeholder = { Text("socio1@gmail.com") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("socio1_email_input")
                        )
                        OutlinedTextField(
                            value = socio2Input,
                            onValueChange = { socio2Input = it },
                            label = { Text("Correo Google · Socio 2 (Solo Consulta)") },
                            placeholder = { Text("socio2@gmail.com") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("socio2_email_input")
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { viewModel.updatePartnerEmails(socio1Input, socio2Input) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("save_partners_button")
                            ) {
                                Text("Guardar socios")
                            }
                            OutlinedButton(
                                onClick = { viewModel.syncAccessForMembers() },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Sincronizar accesos")
                            }
                        }
                    } else {
                        Text("Socio 1: ${ws?.socio1Email?.ifBlank { "No configurado" } ?: "No configurado"}", style = MaterialTheme.typography.bodySmall)
                        Text("Socio 2: ${ws?.socio2Email?.ifBlank { "No configurado" } ?: "No configurado"}", style = MaterialTheme.typography.bodySmall)
                    }

                    if (state.members.isNotEmpty()) {
                        HorizontalDivider()
                        Text("Cuentas activas conectadas:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        state.members.forEach { m ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${m.etiqueta} · ${m.email}", style = MaterialTheme.typography.bodySmall)
                                Text(m.rol, style = MaterialTheme.typography.labelSmall, color = if (m.rol == "Administrador") ForestGreen else SaddleBrown, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 3. Migración Segura SQLite -> Firestore
        if (state.canEdit) {
            item {
                Text("Migración Segura desde Almacenamiento Local", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val migrated = ws?.migratedFromLocal == true
                        Text(
                            text = if (migrated) {
                                "Estado: Migración verificada en la nube (los datos locales originales se conservan intactos)."
                            } else {
                                "Estado: ${state.localPendingMigrationCount} animales detectados en SQLite local."
                            },
                            fontWeight = FontWeight.SemiBold,
                            color = if (migrated) MeadowGreen else EarthTerracotta
                        )
                        Text(
                            text = "Proceso seguro: 1) Respaldo JSON previo automático · 2) Detección anti-duplicados · 3) Verificación de registros · 4) Conserva los datos locales.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = { showMigrateConfirm = true },
                            enabled = !state.isMigrating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("migrate_local_button")
                        ) {
                            if (state.isMigrating) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(Modifier.width(8.dp))
                                Text("Migrando de forma segura...")
                            } else {
                                Icon(Icons.Filled.CloudUpload, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (migrated) "Re-verificar y sincronizar datos locales" else "Migrar datos locales a la nube")
                            }
                        }
                    }
                }
            }
        }

        // 4. Copias de Seguridad (Nube, Cifrado AES-GCM y Archivo JSON v2)
        item {
            Text("Copias de Seguridad y Recuperación", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.canEdit) {
                    Button(
                        onClick = { showCreateCloudBackupDialog = true },
                        enabled = !state.isBackingUp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("create_cloud_backup_button")
                    ) {
                        Icon(Icons.Filled.CloudDone, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Crear Copia de Seguridad en la Nube")
                    }
                }
                Button(
                    onClick = {
                        backupPassphraseInput = ""
                        showEncryptedExportDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaddleBrown),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.EnhancedEncryption, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Exportar Respaldo Cifrado con Contraseña (.mco.json)")
                }
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            val json = viewModel.buildBackupJson()
                            ReportExporter.shareJsonBackup(context, json)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Exportar Respaldo JSON sin cifrar")
                }
                if (state.canEdit) {
                    OutlinedButton(
                        onClick = { jsonPickerLauncher.launch(arrayOf("application/json", "*/*")) },
                        enabled = !state.isBackingUp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.UploadFile, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Importar / Restaurar (JSON o Cifrado)")
                    }
                }
            }
        }

        if (state.backups.isNotEmpty()) {
            item {
                Text("Copias guardadas en la nube (${state.backups.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            items(state.backups, key = { it.docId }) { bkp ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(bkp.nombre, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(ChileanFormatters.formatDateTime(bkp.fechaMs), style = MaterialTheme.typography.labelSmall)
                        }
                        Text("${bkp.totalRegistros} registros · ${bkp.resumen}", style = MaterialTheme.typography.bodySmall)
                        Text("Creado por: ${bkp.creadoPorEmail}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (state.canEdit) {
                            TextButton(onClick = { pendingRestoreCloudBackup = bkp }) {
                                Text("Restaurar esta copia")
                            }
                        }
                    }
                }
            }
        }

        // 5. Predio y Apariencia
        item {
            HorizontalDivider()
            Spacer(Modifier.height(4.dp))
            Text("Configuración del Predio y Apariencia", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = predioInput,
                    onValueChange = { predioInput = it },
                    label = { Text("Nombre del criadero / predio") },
                    singleLine = true,
                    enabled = state.canEdit,
                    modifier = Modifier.weight(1f)
                )
                if (state.canEdit) {
                    Button(onClick = { viewModel.updatePredioNombre(predioInput) }) {
                        Text("Guardar")
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SYSTEM" to "Auto", "LIGHT" to "Claro", "DARK" to "Oscuro").forEach { (code, label) ->
                    FilterChip(
                        selected = state.themeMode == code,
                        onClick = { viewModel.setThemeMode(code) },
                        label = { Text(label) }
                    )
                }
            }
        }
        // 6. Seguridad de Almacenamiento Local
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Security, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Seguridad de Datos Locales y Respaldo", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "• Respaldo pre-migración interno (.enc): cifrado AES-256-GCM con Android KeyStore.\n" +
                            "• Respaldo exportado con contraseña (.mco.json): cifrado PBKDF2 + AES-256-GCM.\n" +
                            "• Caché offline Firestore y Room local: protegidos por el sandbox Android y cifrado de disco del dispositivo (FBE), no por contraseña propia de app.\n" +
                            "• Protección ante pérdida del teléfono: Android Auto-Backup está desactivado (allowBackup=false); usa bloqueo biométrico/PIN en el equipo y revoca accesos o transfiere el Administrador desde otro equipo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    if (showMigrateConfirm) {
        AlertDialog(
            onDismissRequest = { showMigrateConfirm = false },
            title = { Text("Confirmar Migración Segura") },
            text = {
                Text("Se creará automáticamente una copia de seguridad local cifrada (Android KeyStore) y una en la nube antes de migrar. Los registros ya existentes en Firestore serán omitidos para evitar duplicados o sobrescrituras.")
            },
            confirmButton = {
                Button(onClick = {
                    showMigrateConfirm = false
                    viewModel.migrateLocalToCloud()
                }) { Text("Iniciar Migración") }
            },
            dismissButton = {
                TextButton(onClick = { showMigrateConfirm = false }) { Text("Cancelar") }
            }
        )
    }

    if (showCreateCloudBackupDialog) {
        AlertDialog(
            onDismissRequest = { showCreateCloudBackupDialog = false },
            title = { Text("Nueva Copia de Seguridad en la Nube") },
            text = {
                OutlinedTextField(
                    value = backupNameInput,
                    onValueChange = { backupNameInput = it },
                    label = { Text("Nombre del respaldo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    showCreateCloudBackupDialog = false
                    viewModel.createCloudBackup(backupNameInput)
                }) { Text("Guardar copia") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateCloudBackupDialog = false }) { Text("Cancelar") }
            }
        )
    }

    if (showEncryptedExportDialog) {
        AlertDialog(
            onDismissRequest = { showEncryptedExportDialog = false },
            title = { Text("Exportar Respaldo Cifrado") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Ingresa una contraseña de al menos 6 caracteres. Se cifrará con PBKDF2-HMAC-SHA256 + AES-256-GCM.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = backupPassphraseInput,
                        onValueChange = { backupPassphraseInput = it },
                        label = { Text("Contraseña de cifrado") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = backupPassphraseInput.length >= 6,
                    onClick = {
                        val pass = backupPassphraseInput
                        showEncryptedExportDialog = false
                        scope.launch {
                            runCatching {
                                val encrypted = viewModel.buildEncryptedBackupString(pass)
                                ReportExporter.shareEncryptedBackup(context, encrypted).getOrThrow()
                            }.onFailure {
                                viewModel.notifyMessage(it.message ?: "Error al cifrar respaldo")
                            }
                        }
                    }
                ) { Text("Cifrar y Exportar") }
            },
            dismissButton = {
                TextButton(onClick = { showEncryptedExportDialog = false }) { Text("Cancelar") }
            }
        )
    }

    if (showTransferAdminDialog) {
        AlertDialog(
            onDismissRequest = { showTransferAdminDialog = false },
            title = { Text("Transferir Administración Principal") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Ingresa el correo Google verificado del nuevo Administrador. Cuando inicie sesión y acepte el traspaso, tú perderás los privilegios de Administrador en este criadero.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = transferTargetEmail,
                        onValueChange = { transferTargetEmail = it },
                        label = { Text("Correo Google del nuevo Administrador") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = transferTargetEmail.contains("@"),
                    onClick = {
                        viewModel.requestAdminTransfer(transferTargetEmail)
                        showTransferAdminDialog = false
                        transferTargetEmail = ""
                    }
                ) { Text("Enviar traspaso") }
            },
            dismissButton = {
                TextButton(onClick = { showTransferAdminDialog = false }) { Text("Cancelar") }
            }
        )
    }

    pendingRestoreCloudBackup?.let { bkp ->
        AlertDialog(
            onDismissRequest = { pendingRestoreCloudBackup = null },
            title = { Text("¿Restaurar copia de seguridad?") },
            text = { Text("Se recuperarán desde '${bkp.nombre}' los registros faltantes en la nube sin duplicar los aretes o registros existentes.") },
            confirmButton = {
                Button(onClick = {
                    viewModel.restoreFromCloudBackup(bkp)
                    pendingRestoreCloudBackup = null
                }) { Text("Restaurar") }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestoreCloudBackup = null }) { Text("Cancelar") }
            }
        )
    }

    pendingRestoreJsonPair?.let { (rawText, fileName) ->
        val isEncrypted = remember(rawText) { BackupCryptoHelper.isEncryptedEnvelope(rawText) }
        AlertDialog(
            onDismissRequest = {
                pendingRestoreJsonPair = null
                importPassphraseInput = ""
            },
            title = { Text(if (isEncrypted) "Desbloquear Respaldo Cifrado" else "¿Importar respaldo JSON?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Se restaurarán en la nube los registros faltantes desde '$fileName' sin duplicar ni sobrescribir registros existentes.")
                    if (isEncrypted) {
                        OutlinedTextField(
                            value = importPassphraseInput,
                            onValueChange = { importPassphraseInput = it },
                            label = { Text("Contraseña del archivo cifrado") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = !isEncrypted || importPassphraseInput.isNotBlank(),
                    onClick = {
                        val pass = if (isEncrypted) importPassphraseInput else null
                        viewModel.restoreFromJsonOrEncrypted(rawText, pass, fileName)
                        pendingRestoreJsonPair = null
                        importPassphraseInput = ""
                    }
                ) { Text("Importar y Restaurar") }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingRestoreJsonPair = null
                    importPassphraseInput = ""
                }) { Text("Cancelar") }
            }
        )
    }
}
