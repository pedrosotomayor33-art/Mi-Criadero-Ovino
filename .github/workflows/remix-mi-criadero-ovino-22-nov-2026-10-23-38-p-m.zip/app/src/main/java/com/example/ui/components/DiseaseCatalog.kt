package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.SanidadEntity

enum class OvineDiseaseType(
    val shortTitle: String,
    val fullTitle: String,
    val resumenClinico: String,
    val tipoManejoSugerido: String,
    val diagnosticoSugerido: String,
    @param:DrawableRes val imageRes: Int
) {
    PODAL(
        shortTitle = "Podal / Pietín",
        fullTitle = "Pododermatitis (Pietín)",
        resumenClinico = "Inflamación interdigital, cojera y mal olor en pezuñas. Requiere recorte podal y pediluvio.",
        tipoManejoSugerido = "Manejo podal",
        diagnosticoSugerido = "Pododermatitis (Pietín)",
        imageRes = R.drawable.img_enfermedad_podal
    ),
    PARASITARIA(
        shortTitle = "Parasitosis",
        fullTitle = "Parasitosis Gastrointestinal / Externa",
        resumenClinico = "Palidez de mucosas, diarrea o pérdida de condición por nematodos, fasciola o sarna.",
        tipoManejoSugerido = "Desparasitación",
        diagnosticoSugerido = "Parasitosis gastrointestinal",
        imageRes = R.drawable.img_enfermedad_parasitaria
    ),
    INFECCIOSA(
        shortTitle = "Clostridiosis",
        fullTitle = "Clostridiosis e Infecciosas",
        resumenClinico = "Enterotoxemia, tétanos y cuadros clostridiales agudos. Prevención clave mediante vacunación.",
        tipoManejoSugerido = "Vacunación",
        diagnosticoSugerido = "Prevención Clostridiosis",
        imageRes = R.drawable.img_enfermedad_infecciosa
    ),
    RESPIRATORIA(
        shortTitle = "Respiratoria",
        fullTitle = "Enfermedad Respiratoria / Neumonía",
        resumenClinico = "Tos, secreción nasal, decaimiento y fiebre por cambios bruscos de temperatura.",
        tipoManejoSugerido = "Tratamiento",
        diagnosticoSugerido = "Cuadro respiratorio / Neumonía",
        imageRes = R.drawable.img_enfermedad_respiratoria
    ),
    METABOLICA(
        shortTitle = "Mastitis / Carencial",
        fullTitle = "Mastitis y Trastornos Carenciales",
        resumenClinico = "Inflamación mamaria en lactancia, hipocalcemia o deficiencia de selenio y minerales.",
        tipoManejoSugerido = "Vitaminas y minerales",
        diagnosticoSugerido = "Mastitis / Carencia mineral",
        imageRes = R.drawable.img_enfermedad_metabolica
    );

    companion object {
        fun resolve(sanidad: SanidadEntity): OvineDiseaseType =
            resolve(sanidad.tipoManejo, sanidad.diagnostico, sanidad.medicamento)

        fun resolve(
            tipoManejo: String,
            diagnostico: String,
            medicamento: String = ""
        ): OvineDiseaseType {
            val text = "$tipoManejo $diagnostico $medicamento".lowercase()
            return when {
                listOf("pietín", "pietin", "podal", "pododermatitis", "pezuña", "pezuna", "cojera", "casco")
                    .any { it in text } -> PODAL
                listOf("parasit", "desparasit", "ivermectina", "triclabendazol", "sarna", "fasciola", "distomatosis", "piojo", "lombriz")
                    .any { it in text } -> PARASITARIA
                listOf("clostrid", "vacun", "enterotoxemia", "tetano", "tétano", "infecc", "carbunclo", "septicemia")
                    .any { it in text } -> INFECCIOSA
                listOf("neumon", "respirat", "tos", "pulmon", "pulmón", "fiebre", "moco", "bronqu")
                    .any { it in text } -> RESPIRATORIA
                listOf("mastit", "ubre", "vitamin", "mineral", "selenio", "calcio", "carenc", "metab", "toxemia")
                    .any { it in text } -> METABOLICA
                tipoManejo == "Manejo podal" -> PODAL
                tipoManejo == "Desparasitación" -> PARASITARIA
                tipoManejo == "Vacunación" -> INFECCIOSA
                tipoManejo == "Vitaminas y minerales" -> METABOLICA
                else -> RESPIRATORIA
            }
        }
    }
}

@Composable
fun DiseaseThumbnail(
    diseaseType: OvineDiseaseType,
    size: Dp = 76.dp,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Image(
        painter = painterResource(id = diseaseType.imageRes),
        contentDescription = "Foto de ${diseaseType.fullTitle}",
        contentScale = ContentScale.Crop,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    )
}

@Composable
fun DiseaseTypesGallerySection(
    sanidadRecords: List<SanidadEntity>,
    selectedDisease: OvineDiseaseType?,
    canEdit: Boolean,
    onSelectDisease: (OvineDiseaseType?) -> Unit,
    onRegisterForDisease: (OvineDiseaseType) -> Unit
) {
    val countByType = remember(sanidadRecords) {
        sanidadRecords.groupingBy { OvineDiseaseType.resolve(it) }.eachCount()
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Tipos de Enfermedades Ovinas",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Toca un tipo para ver su ficha fotográfica y filtrar casos",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (selectedDisease != null) {
                TextButton(onClick = { onSelectDisease(null) }) {
                    Text("Ver todas")
                }
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("disease_types_gallery")
        ) {
            items(OvineDiseaseType.entries, key = { it.name }) { type ->
                val isSelected = selectedDisease == type
                val count = countByType[type] ?: 0
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerLowest
                        }
                    ),
                    border = BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.outlineVariant
                        }
                    ),
                    modifier = Modifier
                        .width(156.dp)
                        .clickable {
                            onSelectDisease(if (isSelected) null else type)
                        }
                        .testTag("disease_type_card_${type.name}")
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                        ) {
                            Image(
                                painter = painterResource(id = type.imageRes),
                                contentDescription = "Foto de ${type.fullTitle}",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, Color(0xAA000000))
                                        )
                                    )
                            )
                            if (count > 0) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                ) {
                                    Text(
                                        text = "$count",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Seleccionado",
                                    tint = Color.White,
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(6.dp)
                                        .size(20.dp)
                                )
                            }
                            Text(
                                text = type.shortTitle,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(8.dp)
                            )
                        }
                        Text(
                            text = type.resumenClinico,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        if (selectedDisease != null) {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                    ) {
                        Image(
                            painter = painterResource(id = selectedDisease.imageRes),
                            contentDescription = "Fotografía clínica de ${selectedDisease.fullTitle}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0x22000000), Color(0xCC0F291E))
                                    )
                                )
                        )
                        IconButton(
                            onClick = { onSelectDisease(null) },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Cerrar vista de enfermedad",
                                tint = Color.White
                            )
                        }
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(14.dp)
                        ) {
                            Text(
                                text = selectedDisease.fullTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Manejo sugerido: ${selectedDisease.tipoManejoSugerido}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFD8F3DC)
                            )
                        }
                    }
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = selectedDisease.resumenClinico,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (canEdit) {
                            Button(
                                onClick = { onRegisterForDisease(selectedDisease) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Registrar caso de ${selectedDisease.shortTitle}")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DiseasePhotoPreviewDialog(
    diseaseType: OvineDiseaseType,
    diagnostico: String,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(diseaseType.fullTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Image(
                    painter = painterResource(id = diseaseType.imageRes),
                    contentDescription = "Foto ampliada de ${diseaseType.fullTitle}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(14.dp))
                )
                if (diagnostico.isNotBlank()) {
                    Text(
                        text = "Diagnóstico: $diagnostico",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = diseaseType.resumenClinico,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cerrar") }
        }
    )
}
