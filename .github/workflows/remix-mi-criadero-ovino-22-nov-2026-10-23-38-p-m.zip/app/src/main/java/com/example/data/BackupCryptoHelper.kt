package com.example.data

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object BackupCryptoHelper {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEYSTORE_ALIAS = "mi_criadero_ovino_backup_aes_key"
    private const val AES_GCM = "AES/GCM/NoPadding"
    private const val PBKDF2_ALGO = "PBKDF2WithHmacSHA256"
    private const val PBKDF2_ITERATIONS = 120_000
    private const val GCM_TAG_BITS = 128
    private const val IV_BYTES = 12
    private const val SALT_BYTES = 16

    const val ENVELOPE_FORMAT = "MCO_ENCRYPTED_BACKUP_V1"

    fun isEncryptedEnvelope(raw: String): Boolean = runCatching {
        val trimmed = raw.trim()
        trimmed.startsWith("{") && JSONObject(trimmed).optString("format") == ENVELOPE_FORMAT
    }.getOrDefault(false)

    /**
     * Cifra un respaldo interno del dispositivo usando Android KeyStore (AES-256-GCM).
     */
    fun encryptWithDeviceKeyStore(plainText: String): String {
        val key = getOrCreateKeyStoreKey()
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val ciphertext = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return JSONObject().apply {
            put("format", "MCO_KEYSTORE_BACKUP_V1")
            put("cipher", AES_GCM)
            put("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            put("ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
        }.toString()
    }

    fun decryptWithDeviceKeyStore(envelopeJson: String): Result<String> = runCatching {
        val obj = JSONObject(envelopeJson)
        require(obj.optString("format") == "MCO_KEYSTORE_BACKUP_V1") { "Formato de respaldo interno inválido." }
        val iv = Base64.decode(obj.getString("iv"), Base64.NO_WRAP)
        val ciphertext = Base64.decode(obj.getString("ciphertext"), Base64.NO_WRAP)
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val key = keyStore.getKey(KEYSTORE_ALIAS, null) as SecretKey
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }

    /**
     * Cifra un respaldo portable con contraseña elegida por el Administrador (PBKDF2 + AES-256-GCM).
     */
    fun encryptWithPassphrase(plainText: String, passphrase: String): String {
        require(passphrase.length >= 6) { "La contraseña de respaldo debe tener al menos 6 caracteres." }
        val random = SecureRandom()
        val salt = ByteArray(SALT_BYTES).also { random.nextBytes(it) }
        val iv = ByteArray(IV_BYTES).also { random.nextBytes(it) }
        val secretKey = deriveAesKey(passphrase, salt, PBKDF2_ITERATIONS)
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_BITS, iv))
        val ciphertext = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        return JSONObject().apply {
            put("format", ENVELOPE_FORMAT)
            put("kdf", PBKDF2_ALGO)
            put("iterations", PBKDF2_ITERATIONS)
            put("cipher", AES_GCM)
            put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
            put("ciphertext", Base64.encodeToString(ciphertext, Base64.NO_WRAP))
        }.toString(2)
    }

    fun decryptWithPassphrase(envelopeJson: String, passphrase: String): Result<String> = runCatching {
        require(passphrase.isNotEmpty()) { "Ingresa la contraseña del respaldo cifrado." }
        val obj = JSONObject(envelopeJson)
        require(obj.optString("format") == ENVELOPE_FORMAT) { "El archivo no corresponde a un respaldo cifrado válido." }
        val iterations = obj.optInt("iterations", PBKDF2_ITERATIONS).coerceAtLeast(10_000)
        val salt = Base64.decode(obj.getString("salt"), Base64.NO_WRAP)
        val iv = Base64.decode(obj.getString("iv"), Base64.NO_WRAP)
        val ciphertext = Base64.decode(obj.getString("ciphertext"), Base64.NO_WRAP)
        val secretKey = deriveAesKey(passphrase, salt, iterations)
        val cipher = Cipher.getInstance(AES_GCM)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_BITS, iv))
        String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }.recoverCatching {
        throw IllegalArgumentException("Contraseña incorrecta o archivo de respaldo dañado.", it)
    }

    private fun deriveAesKey(passphrase: String, salt: ByteArray, iterations: Int): SecretKey {
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, iterations, 256)
        val factory = SecretKeyFactory.getInstance(PBKDF2_ALGO)
        val bytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    private fun getOrCreateKeyStoreKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEYSTORE_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEYSTORE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }
}
