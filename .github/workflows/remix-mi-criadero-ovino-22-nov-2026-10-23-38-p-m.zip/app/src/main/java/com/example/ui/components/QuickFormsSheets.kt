package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.*
import com.example.ui.CriaderoUiState
import com.example.ui.CriaderoViewModel
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.HarvestAmber
import com.example.ui.theme.AmberSoft
import kotlinx.coroutines.launch

val CHILEAN_BREEDS = listOf(
    "Suffolk Down", "Corriedale", "Texel", "Merino Precoz",
    "Romney Marsh", "Hampshire Down", "Chilota", "Araucana", "Criolla"
)

@Composable
fun QuickAnimalDialog(
    initialAnimal: AnimalEntity? = null,
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var arete by remember { mutableStateOf(initialAnimal?.arete ?: "") }
    var nombre by remember { mutableStateOf(initialAnimal?.nombre ?: "") }
    var photoUri by remember { mutableStateOf(initialAnimal?.photoUri) }
    var sexo by remember { mutableStateOf(initialAnimal?.sexo ?: "Hembra") }
    var raza by remember { mutableStateOf(initialAnimal?.raza ?: CHILEAN_BREEDS.first()) }
    var edadMesesStr by remember {
        val meses = initialAnimal?.let {
            ((System.currentTimeMillis() - it.fechaNacimiento) / (30L * 86_400_000L)).coerceAtLeast(0L)
        } ?: 6L
        mutableStateOf(meses.toString())
    }
    var pesoNacStr by remember { mutableStateOf(initialAnimal?.pesoNacimientoKg?.toString() ?: "4.0") }
    var pesoActStr by remember { mutableStateOf(initialAnimal?.pesoActualKg?.toString() ?: "32.0") }
    var tipoNac by remember { mutableStateOf(initialAnimal?.tipoNacimiento ?: "Único") }
    var proposito by remember { mutableStateOf(initialAnimal?.proposito ?: "Reproducción") }
    var predioOrigen by remember { mutableStateOf(initialAnimal?.predioOrigen ?: "Propio") }
    var selectedPotreroId by remember { mutableStateOf(initialAnimal?.potreroId ?: state.potreros.firstOrNull()?.id) }
    var selectedMadreId by remember { mutableStateOf(initialAnimal?.madreId) }
    var selectedPadreId by remember { mutableStateOf(initialAnimal?.padreId) }
    var observaciones by remember { mutableStateOf(initialAnimal?.observaciones ?: "") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                photoUri = viewModel.persistPhotoFromPicker(uri)
            }
        }
    }

    val madres = remember(state.animales) {
        state.animales.filter { it.sexo == "Hembra" && it.id != initialAnimal?.id }
    }
    val padres = remember(state.animales) {
        state.animales.filter { it.sexo == "Macho" && it.id != initialAnimal?.id }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialAnimal == null) "Registrar Ovino" else "Editar Ficha ${initialAnimal.arete}") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.AddAPhoto, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (photoUri == null) "Adjuntar fotografía (opcional)" else "Fotografía seleccionada ✓")
                }

                OutlinedTextField(
                    value = arete,
                    onValueChange = { arete = it; errorMsg = null },
                    label = { Text("N° Arete / DIIO (único) *") },
                    placeholder = { Text("Ej: CL-215") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("animal_arete_input")
                )
                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre o apodo visual") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DropdownField(
                        label = "Sexo",
                        selectedText = sexo,
                        options = listOf("Hembra", "Macho"),
                        onSelect = { sexo = listOf("Hembra", "Macho")[it] },
                        modifier = Modifier.weight(1f)
                    )
                    DropdownField(
                        label = "Tipo nac.",
                        selectedText = tipoNac,
                        options = listOf("Único", "Mellizo", "Trillizo"),
                        onSelect = { tipoNac = listOf("Único", "Mellizo", "Trillizo")[it] },
                        modifier = Modifier.weight(1f)
                    )
                }

                DropdownField(
                    label = "Raza",
                    selectedText = raza,
                    options = CHILEAN_BREEDS,
                    onSelect = { raza = CHILEAN_BREEDS[it] }
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pesoNacStr,
                        onValueChange = { pesoNacStr = it },
                        label = { Text("Peso nac. (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = pesoActStr,
                        onValueChange = { pesoActStr = it },
                        label = { Text("Peso actual (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (initialAnimal == null) {
                    OutlinedTextField(
                        value = edadMesesStr,
                        onValueChange = { edadMesesStr = it },
                        label = { Text("Edad aproximada (meses)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                val propositos = listOf("Reproducción", "Engorda", "Reemplazo", "Venta")
                DropdownField(
                    label = "Propósito productivo",
                    selectedText = proposito,
                    options = propositos,
                    onSelect = { proposito = propositos[it] }
                )

                if (state.potreros.isNotEmpty()) {
                    val potOptions = listOf("Sin asignar") + state.potreros.map { it.nombre }
                    val potText = state.potreros.firstOrNull { it.id == selectedPotreroId }?.nombre ?: "Sin asignar"
                    DropdownField(
                        label = "Potrero actual",
                        selectedText = potText,
                        options = potOptions,
                        onSelect = { idx ->
                            selectedPotreroId = if (idx == 0) null else state.potreros[idx - 1].id
                        }
                    )
                }

                if (madres.isNotEmpty()) {
                    val madreOpts = listOf("Desconocida") + madres.map { "${it.arete} (${it.nombre.ifBlank { it.raza }})" }
                    val madreTxt = madres.firstOrNull { it.id == selectedMadreId }?.let { "${it.arete} (${it.nombre.ifBlank { it.raza }})" } ?: "Desconocida"
                    DropdownField(
                        label = "Madre",
                        selectedText = madreTxt,
                        options = madreOpts,
                        onSelect = { idx -> selectedMadreId = if (idx == 0) null else madres[idx - 1].id }
                    )
                }

                if (padres.isNotEmpty()) {
                    val padreOpts = listOf("Desconocido") + padres.map { "${it.arete} (${it.nombre.ifBlank { it.raza }})" }
                    val padreTxt = padres.firstOrNull { it.id == selectedPadreId }?.let { "${it.arete} (${it.nombre.ifBlank { it.raza }})" } ?: "Desconocido"
                    DropdownField(
                        label = "Padre",
                        selectedText = padreTxt,
                        options = padreOpts,
                        onSelect = { idx -> selectedPadreId = if (idx == 0) null else padres[idx - 1].id }
                    )
                }

                OutlinedTextField(
                    value = predioOrigen,
                    onValueChange = { predioOrigen = it },
                    label = { Text("Predio de origen") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = observaciones,
                    onValueChange = { observaciones = it },
                    label = { Text("Observaciones") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                errorMsg?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanArete = arete.trim()
                    val pNac = pesoNacStr.replace(",", ".").toDoubleOrNull() ?: -1.0
                    val pAct = pesoActStr.replace(",", ".").toDoubleOrNull() ?: -1.0
                    if (cleanArete.isBlank()) {
                        errorMsg = "Ingrese el número de arete."
                        return@Button
                    }
                    if (state.animales.any { it.id != initialAnimal?.id && it.arete.equals(cleanArete, ignoreCase = true) }) {
                        errorMsg = "Ya existe un ovino con el arete '$cleanArete'."
                        return@Button
                    }
                    if (pNac < 0 || pAct < 0) {
                        errorMsg = "Ingrese pesos válidos en kg."
                        return@Button
                    }
                    val now = System.currentTimeMillis()
                    val meses = edadMesesStr.toLongOrNull()?.coerceAtLeast(0L) ?: 6L
                    val fechaNac = initialAnimal?.fechaNacimiento ?: (now - meses * 30L * 86_400_000L)
                    val entity = (initialAnimal ?: AnimalEntity(
                        arete = arete.trim(),
                        sexo = sexo,
                        raza = raza,
                        fechaNacimiento = fechaNac,
                        pesoNacimientoKg = pNac,
                        pesoActualKg = pAct,
                        fechaIngreso = now
                    )).copy(
                        arete = arete.trim(),
                        nombre = nombre.trim(),
                        photoUri = photoUri,
                        sexo = sexo,
                        raza = raza,
                        pesoNacimientoKg = pNac,
                        pesoActualKg = pAct,
                        madreId = selectedMadreId,
                        padreId = selectedPadreId,
                        tipoNacimiento = tipoNac,
                        predioOrigen = predioOrigen.trim().ifBlank { "Propio" },
                        proposito = proposito,
                        potreroId = selectedPotreroId,
                        observaciones = observaciones.trim()
                    )
                    viewModel.saveAnimal(entity, onSuccess = onDismiss)
                },
                modifier = Modifier.testTag("save_animal_button")
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun QuickWeightDialog(
    preselectedAnimalId: Long? = null,
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onDismiss: () -> Unit
) {
    val activos = remember(state.animales) { state.animales.filter { it.estado == "Activo" } }
    var selectedAnimalId by remember {
        mutableStateOf(preselectedAnimalId ?: activos.firstOrNull()?.id)
    }
    var pesoStr by remember { mutableStateOf("") }
    var obs by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Pesaje Rápido") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (activos.isEmpty()) {
                    Text("No hay animales activos registrados.")
                } else {
                    val selected = activos.firstOrNull { it.id == selectedAnimalId } ?: activos.first()
                    DropdownField(
                        label = "Ovino (Arete)",
                        selectedText = "${selected.arete} · ${selected.nombre.ifBlank { selected.raza }} (${selected.pesoActualKg} kg)",
                        options = activos.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }} (${it.pesoActualKg} kg)" },
                        onSelect = { selectedAnimalId = activos[it].id }
                    )
                    OutlinedTextField(
                        value = pesoStr,
                        onValueChange = { pesoStr = it; errorMsg = null },
                        label = { Text("Nuevo peso (kg) *") },
                        placeholder = { Text("Ej: 38.5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("quick_weight_input")
                    )
                    OutlinedTextField(
                        value = obs,
                        onValueChange = { obs = it },
                        label = { Text("Observaciones (opcional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                enabled = activos.isNotEmpty(),
                onClick = {
                    val peso = pesoStr.replace(",", ".").toDoubleOrNull()
                    val targetId = selectedAnimalId
                    if (targetId == null || peso == null || peso <= 0.0) {
                        errorMsg = "Ingrese un peso válido mayor a 0 kg."
                        return@Button
                    }
                    viewModel.registrarPesaje(targetId, peso, System.currentTimeMillis(), obs, onSuccess = onDismiss)
                },
                modifier = Modifier.testTag("confirm_weight_button")
            ) {
                Text("Guardar Pesaje")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun QuickEncasteDialog(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onDismiss: () -> Unit
) {
    val carneros = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Macho" } }
    val ovejas = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Hembra" } }
    var selectedCarneroId by remember { mutableStateOf(carneros.firstOrNull()?.id) }
    val selectedOvejas = remember { mutableStateListOf<Long>() }
    var metodo by remember { mutableStateOf("Monta natural") }
    var diasDuracionStr by remember { mutableStateOf("35") }
    var obs by remember { mutableStateOf("") }

    val alertasConsanguinidad = remember(selectedCarneroId, selectedOvejas.toList(), state.animales) {
        selectedOvejas.mapNotNull { ovejaId ->
            val res = viewModel.repo.checkConsanguinity(ovejaId, selectedCarneroId, state.animales)
            if (res.hayParentesco) {
                val ovejaArete = state.animales.firstOrNull { it.id == ovejaId }?.arete ?: ""
                "$ovejaArete: ${res.nivelRiesgo} - ${res.detalle}"
            } else null
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Encaste") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (carneros.isEmpty() || ovejas.isEmpty()) {
                    Text("Requiere al menos 1 macho y 1 hembra activos.")
                } else {
                    val carnero = carneros.firstOrNull { it.id == selectedCarneroId } ?: carneros.first()
                    DropdownField(
                        label = "Carnero reproductor",
                        selectedText = "${carnero.arete} · ${carnero.nombre.ifBlank { carnero.raza }}",
                        options = carneros.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" },
                        onSelect = { selectedCarneroId = carneros[it].id }
                    )
                    DropdownField(
                        label = "Método",
                        selectedText = metodo,
                        options = listOf("Monta natural", "Inseminación artificial"),
                        onSelect = { metodo = listOf("Monta natural", "Inseminación artificial")[it] }
                    )
                    OutlinedTextField(
                        value = diasDuracionStr,
                        onValueChange = { diasDuracionStr = it },
                        label = { Text("Duración del encaste (días)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Ovejas encastadas (${selectedOvejas.size} sel.):", style = MaterialTheme.typography.labelLarge)
                    ovejas.forEach { o ->
                        val checked = selectedOvejas.contains(o.id)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    if (it) selectedOvejas.add(o.id) else selectedOvejas.remove(o.id)
                                }
                            )
                            Text("${o.arete} · ${o.nombre.ifBlank { o.raza }}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    if (alertasConsanguinidad.isNotEmpty()) {
                        Surface(
                            color = CrimsonSoft,
                            shape = MaterialTheme.shapes.small,
                            border = BorderStroke(1.dp, CrimsonAlert)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Warning, contentDescription = null, tint = CrimsonAlert, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Alerta de Consanguinidad", fontWeight = FontWeight.Bold, color = CrimsonAlert, style = MaterialTheme.typography.labelMedium)
                                }
                                alertasConsanguinidad.forEach { msg ->
                                    Text("• $msg", style = MaterialTheme.typography.bodySmall, color = CrimsonAlert)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = obs,
                        onValueChange = { obs = it },
                        label = { Text("Observaciones") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = carneros.isNotEmpty() && selectedOvejas.isNotEmpty(),
                onClick = {
                    val now = System.currentTimeMillis()
                    val dias = diasDuracionStr.toLongOrNull()?.coerceAtLeast(1L) ?: 35L
                    selectedCarneroId?.let { cid ->
                        viewModel.registrarEncaste(
                            fechaInicio = now,
                            fechaTermino = now + dias * 86_400_000L,
                            carneroId = cid,
                            ovejaIds = selectedOvejas.toList(),
                            metodo = metodo,
                            observaciones = obs,
                            onSuccess = onDismiss
                        )
                    }
                }
            ) {
                Text("Guardar Encaste")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun QuickPartoDialog(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onDismiss: () -> Unit
) {
    val madres = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Hembra" } }
    val padres = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Macho" } }
    var madreId by remember { mutableStateOf(madres.firstOrNull { it.prenada }?.id ?: madres.firstOrNull()?.id) }
    var padreId by remember { mutableStateOf(padres.firstOrNull()?.id) }
    var asistencia by remember { mutableStateOf("Normal") }
    var obs by remember { mutableStateOf("") }

    var cantidadCrias by remember { mutableIntStateOf(1) }
    val nextNum = state.animales.size + 210
    val aretes = remember { mutableStateListOf("CL-$nextNum", "CL-${nextNum + 1}", "CL-${nextNum + 2}") }
    val sexos = remember { mutableStateListOf("Hembra", "Macho", "Hembra") }
    val pesos = remember { mutableStateListOf("4.2", "3.9", "3.5") }
    val vivos = remember { mutableStateListOf(true, true, true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Parto + Corderos") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (madres.isEmpty()) {
                    Text("No hay hembras registradas para parto.")
                } else {
                    val m = madres.firstOrNull { it.id == madreId } ?: madres.first()
                    DropdownField(
                        label = "Madre",
                        selectedText = "${m.arete} · ${m.nombre.ifBlank { m.raza }}",
                        options = madres.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" },
                        onSelect = { madreId = madres[it].id }
                    )
                    if (padres.isNotEmpty()) {
                        val pOpts = listOf("Desconocido") + padres.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" }
                        val pTxt = padres.firstOrNull { it.id == padreId }?.let { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" } ?: "Desconocido"
                        DropdownField(
                            label = "Padre (Carnero)",
                            selectedText = pTxt,
                            options = pOpts,
                            onSelect = { idx -> padreId = if (idx == 0) null else padres[idx - 1].id }
                        )
                    }
                    DropdownField(
                        label = "Asistencia al parto",
                        selectedText = asistencia,
                        options = listOf("Normal", "Asistido", "Cesárea"),
                        onSelect = { asistencia = listOf("Normal", "Asistido", "Cesárea")[it] }
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Crías nacidas:", style = MaterialTheme.typography.labelLarge)
                        listOf(1, 2, 3).forEach { n ->
                            FilterChip(
                                selected = cantidadCrias == n,
                                onClick = { cantidadCrias = n },
                                label = { Text("$n") }
                            )
                        }
                    }

                    for (i in 0 until cantidadCrias) {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Cría #${i + 1}", fontWeight = FontWeight.Bold)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = vivos[i], onCheckedChange = { vivos[i] = it })
                                        Text(if (vivos[i]) "Viva" else "Mortinato", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                                if (vivos[i]) {
                                    OutlinedTextField(
                                        value = aretes[i],
                                        onValueChange = { aretes[i] = it },
                                        label = { Text("Arete automático/nuevo *") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DropdownField(
                                        label = "Sexo",
                                        selectedText = sexos[i],
                                        options = listOf("Hembra", "Macho"),
                                        onSelect = { sexos[i] = listOf("Hembra", "Macho")[it] },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = pesos[i],
                                        onValueChange = { pesos[i] = it },
                                        label = { Text("Peso (kg)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = obs,
                        onValueChange = { obs = it },
                        label = { Text("Observaciones") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(
                enabled = madres.isNotEmpty(),
                onClick = {
                    val mId = madreId ?: return@Button
                    val inputs = (0 until cantidadCrias).map { i ->
                        val w = pesos[i].replace(",", ".").toDoubleOrNull() ?: 4.0
                        LambBirthInput(
                            arete = aretes[i].trim(),
                            nombre = "",
                            sexo = sexos[i],
                            pesoNacimientoKg = w,
                            vivo = vivos[i]
                        )
                    }
                    viewModel.registrarParto(
                        madreId = mId,
                        padreId = padreId,
                        fechaParto = System.currentTimeMillis(),
                        asistencia = asistencia,
                        observaciones = obs,
                        crias = inputs,
                        onSuccess = onDismiss
                    )
                }
            ) {
                Text("Registrar Parto")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun QuickSanidadDialog(
    preselectedAnimalId: Long? = null,
    initialDiseaseType: OvineDiseaseType? = null,
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onDismiss: () -> Unit
) {
    val activos = remember(state.animales) { state.animales.filter { it.estado == "Activo" } }
    var porLote by remember { mutableStateOf(false) }
    var selectedAnimalId by remember { mutableStateOf(preselectedAnimalId ?: activos.firstOrNull()?.id) }
    var selectedLote by remember { mutableStateOf(state.lotes.firstOrNull()?.nombre ?: "Todo el rebaño") }
    var selectedDiseaseType by remember { mutableStateOf(initialDiseaseType ?: OvineDiseaseType.PODAL) }
    var tipoManejo by remember { mutableStateOf(initialDiseaseType?.tipoManejoSugerido ?: "Tratamiento") }
    var diagnostico by remember { mutableStateOf(initialDiseaseType?.diagnosticoSugerido ?: "") }
    var medicamento by remember { mutableStateOf("") }
    var principio by remember { mutableStateOf("") }
    var dosisStr by remember { mutableStateOf("2.0") }
    var unidad by remember { mutableStateOf("ml") }
    var via by remember { mutableStateOf("Subcutánea") }
    var proxDiasStr by remember { mutableStateOf("14") }
    var vet by remember { mutableStateOf("") }
    var obs by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val tipos = listOf("Tratamiento", "Vacunación", "Desparasitación", "Vitaminas y minerales", "Revisión", "Manejo podal")
    val vias = listOf("Subcutánea", "Intramuscular", "Oral", "Tópica", "Podal")
    val unidades = listOf("ml", "cc", "mg", "comprimidos")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Manejo Sanitario") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Tipo de enfermedad (referencia visual):", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OvineDiseaseType.entries.forEach { type ->
                        val isSel = selectedDiseaseType == type
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = BorderStroke(
                                width = if (isSel) 2.dp else 1.dp,
                                color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .width(104.dp)
                                .clickable {
                                    val prevSuggested = selectedDiseaseType.diagnosticoSugerido
                                    selectedDiseaseType = type
                                    tipoManejo = type.tipoManejoSugerido
                                    if (diagnostico.isBlank() || diagnostico == prevSuggested) {
                                        diagnostico = type.diagnosticoSugerido
                                    }
                                    errorMsg = null
                                }
                        ) {
                            Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                DiseaseThumbnail(
                                    diseaseType = type,
                                    size = 92.dp,
                                    modifier = Modifier.fillMaxWidth().height(58.dp)
                                )
                                Text(
                                    text = type.shortTitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = !porLote, onClick = { porLote = false }, label = { Text("Por animal") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = porLote, onClick = { porLote = true }, label = { Text("Por lote") })
                }

                if (!porLote && activos.isNotEmpty()) {
                    val sel = activos.firstOrNull { it.id == selectedAnimalId } ?: activos.first()
                    DropdownField(
                        label = "Animal",
                        selectedText = "${sel.arete} · ${sel.nombre.ifBlank { sel.raza }}",
                        options = activos.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" },
                        onSelect = { selectedAnimalId = activos[it].id }
                    )
                } else {
                    val loteOpts = (listOf("Todo el rebaño") + state.lotes.map { it.nombre }).distinct()
                    DropdownField(
                        label = "Lote / Grupo",
                        selectedText = selectedLote,
                        options = loteOpts,
                        onSelect = { selectedLote = loteOpts[it] }
                    )
                }

                DropdownField(
                    label = "Tipo de manejo",
                    selectedText = tipoManejo,
                    options = tipos,
                    onSelect = { tipoManejo = tipos[it] }
                )
                OutlinedTextField(
                    value = diagnostico,
                    onValueChange = { diagnostico = it; errorMsg = null },
                    label = { Text("Diagnóstico / Motivo *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = medicamento,
                    onValueChange = { medicamento = it },
                    label = { Text("Medicamento o vacuna") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = principio,
                    onValueChange = { principio = it },
                    label = { Text("Principio activo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = dosisStr,
                        onValueChange = { dosisStr = it },
                        label = { Text("Dosis") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    DropdownField(
                        label = "Unidad",
                        selectedText = unidad,
                        options = unidades,
                        onSelect = { unidad = unidades[it] },
                        modifier = Modifier.weight(1f)
                    )
                }
                DropdownField(
                    label = "Vía de administración",
                    selectedText = via,
                    options = vias,
                    onSelect = { via = vias[it] }
                )
                OutlinedTextField(
                    value = proxDiasStr,
                    onValueChange = { proxDiasStr = it },
                    label = { Text("Próxima dosis / control (en días, vacío si no aplica)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = vet,
                    onValueChange = { vet = it },
                    label = { Text("Veterinario responsable") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = obs,
                    onValueChange = { obs = it },
                    label = { Text("Observaciones") },
                    modifier = Modifier.fillMaxWidth()
                )
                errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (diagnostico.isBlank()) {
                    errorMsg = "Ingrese el diagnóstico o motivo."
                    return@Button
                }
                val now = System.currentTimeMillis()
                val proxDias = proxDiasStr.toLongOrNull()
                val proxDate = proxDias?.let { now + it * 86_400_000L }
                viewModel.saveSanidad(
                    SanidadEntity(
                        animalId = if (porLote) null else selectedAnimalId,
                        loteNombre = if (porLote) selectedLote else null,
                        tipoManejo = tipoManejo,
                        diagnostico = diagnostico.trim(),
                        fecha = now,
                        medicamento = medicamento.trim(),
                        principioActivo = principio.trim(),
                        dosis = dosisStr.replace(",", ".").toDoubleOrNull() ?: 0.0,
                        unidadDosis = unidad,
                        viaAdministracion = via,
                        fechaProximaDosis = proxDate,
                        veterinario = vet.trim(),
                        evolucion = if (tipoManejo == "Tratamiento") "En tratamiento" else "Programado",
                        observaciones = obs.trim()
                    ),
                    onSuccess = onDismiss
                )
            }) {
                Text("Guardar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun QuickMovePastureDialog(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onDismiss: () -> Unit
) {
    val activos = remember(state.animales) { state.animales.filter { it.estado == "Activo" } }
    var origenId by remember { mutableStateOf(state.potreros.firstOrNull()?.id) }
    var destinoId by remember { mutableStateOf(state.potreros.getOrNull(1)?.id ?: state.potreros.firstOrNull()?.id) }
    var motivo by remember { mutableStateOf("Rotación por disponibilidad de forraje") }
    var obs by remember { mutableStateOf("") }

    val animalesEnOrigen = remember(activos, origenId) {
        if (origenId == null) activos else activos.filter { it.potreroId == origenId }
    }
    val selectedIds = remember(origenId) {
        mutableStateListOf<Long>().apply { addAll(animalesEnOrigen.map { it.id }) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Movimiento de Potrero") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (state.potreros.size < 2) {
                    Text("Cree al menos 2 potreros para realizar rotaciones.")
                } else {
                    val origOpts = listOf("Todos los activos") + state.potreros.map { it.nombre }
                    val origTxt = state.potreros.firstOrNull { it.id == origenId }?.nombre ?: "Todos los activos"
                    DropdownField(
                        label = "Potrero origen",
                        selectedText = origTxt,
                        options = origOpts,
                        onSelect = { idx ->
                            origenId = if (idx == 0) null else state.potreros[idx - 1].id
                        }
                    )
                    val destTxt = state.potreros.firstOrNull { it.id == destinoId }?.nombre ?: ""
                    DropdownField(
                        label = "Potrero destino",
                        selectedText = destTxt,
                        options = state.potreros.map { it.nombre },
                        onSelect = { destinoId = state.potreros[it].id }
                    )
                    Text("Ovinos a trasladar (${selectedIds.size} de ${animalesEnOrigen.size}):", style = MaterialTheme.typography.labelLarge)
                    animalesEnOrigen.forEach { a ->
                        val checked = selectedIds.contains(a.id)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    if (it) selectedIds.add(a.id) else selectedIds.remove(a.id)
                                }
                            )
                            Text("${a.arete} · ${a.nombre.ifBlank { a.raza }}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    OutlinedTextField(
                        value = motivo,
                        onValueChange = { motivo = it },
                        label = { Text("Motivo") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = obs,
                        onValueChange = { obs = it },
                        label = { Text("Observaciones") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = state.potreros.isNotEmpty() && destinoId != null && selectedIds.isNotEmpty(),
                onClick = {
                    viewModel.moverAnimalesDePotrero(
                        animalIds = selectedIds.toList(),
                        origenId = origenId,
                        destinoId = destinoId!!,
                        motivo = motivo,
                        observaciones = obs,
                        onSuccess = onDismiss
                    )
                }
            ) {
                Text("Confirmar Traslado")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
