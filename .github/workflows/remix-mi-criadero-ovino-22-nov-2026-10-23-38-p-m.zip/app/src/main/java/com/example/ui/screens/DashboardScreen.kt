package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.CriaderoUiState
import com.example.ui.CriaderoViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.ChileanFormatters

@Composable
fun DashboardScreen(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onOpenAnimalDetail: (Long) -> Unit,
    onNavigateToAlerts: () -> Unit,
    onNavigateToAnimals: () -> Unit,
    onNavigateToCloudMigration: () -> Unit = {}
) {
    var showAddAnimal by remember { mutableStateOf(false) }
    var showQuickWeight by remember { mutableStateOf(false) }
    var showQuickEncaste by remember { mutableStateOf(false) }
    var showQuickParto by remember { mutableStateOf(false) }
    var showQuickSanidad by remember { mutableStateOf(false) }
    var showQuickMove by remember { mutableStateOf(false) }

    val k = state.kpis
    val animalById = remember(state.animales) { state.animales.associateBy { it.id } }

    // Top 3 animales con pesajes para el gráfico de evolución del dashboard
    val weightSeries = remember(state.animales, state.pesajes) {
        val grouped = state.pesajes.groupBy { it.animalId }
        state.animales
            .filter { (grouped[it.id]?.size ?: 0) >= 2 }
            .take(3)
            .map { a -> a.arete to (grouped[a.id] ?: emptyList()) }
    }

    val recentWeighings = remember(state.pesajes) { state.pesajes.take(5) }
    val urgentAlerts = remember(state.alertas) { state.alertas.take(4) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner Pradera Chilena
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(148.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_pasture_hero),
                        contentDescription = "Pradera chilena del criadero ovino",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color(0x330F291E),
                                        Color(0xDD0F291E)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val syncBadgeText = when {
                                !state.isOnline -> "Sin conexión · Caché local"
                                state.isSyncPendingWrites -> "Sincronizando cambios..."
                                state.isFromCache -> "Caché sincronizado"
                                else -> "Nube en tiempo real"
                            }
                            Surface(
                                color = (if (!state.isOnline) EarthTerracotta else FreshGrass).copy(alpha = 0.28f),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = syncBadgeText,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SoftMint,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                color = Color.White.copy(alpha = 0.18f),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.clickable { onNavigateToAnimals() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Search, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Buscar arete", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = "${k.totalOvinos} ovinos activos",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Biomasa total: ${ChileanFormatters.formatKg(k.kilosTotalesRebano)} · +${ChileanFormatters.formatKg(k.kilosProducidosMes)} (30d)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SoftMint
                                )
                            }
                        }
                    }
                }
            }
        }

        if (state.canEdit && state.localPendingMigrationCount > 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AmberSoft),
                    border = BorderStroke(1.dp, EarthTerracotta.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.CloudUpload, contentDescription = null, tint = SaddleBrown)
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Datos locales pendientes de migrar (${state.localPendingMigrationCount} animales)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = SaddleBrown
                            )
                            Text(
                                text = "Se creará respaldo previo y se evitarán duplicados antes de subir a los 3 teléfonos.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SaddleBrown
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = onNavigateToCloudMigration) {
                            Text("Migrar", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Botones de acceso rápido en campo
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Acciones rápidas de campo",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionCardButton(
                        label = "Registrar animal",
                        icon = Icons.Filled.AddCircle,
                        tint = ForestGreen,
                        enabled = state.canEdit,
                        testTag = "quick_add_animal",
                        onClick = { showAddAnimal = true },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionCardButton(
                        label = "Registrar pesaje",
                        icon = Icons.Filled.MonitorWeight,
                        tint = MeadowGreen,
                        enabled = state.canEdit,
                        testTag = "quick_add_weight",
                        onClick = { showQuickWeight = true },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionCardButton(
                        label = "Registrar encaste",
                        icon = Icons.Filled.Favorite,
                        tint = EarthTerracotta,
                        enabled = state.canEdit,
                        testTag = "quick_add_encaste",
                        onClick = { showQuickEncaste = true },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionCardButton(
                        label = "Registrar parto",
                        icon = Icons.Filled.ChildFriendly,
                        tint = HarvestAmber,
                        enabled = state.canEdit,
                        testTag = "quick_add_parto",
                        onClick = { showQuickParto = true },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionCardButton(
                        label = "Tratamiento",
                        icon = Icons.Filled.MedicalServices,
                        tint = CrimsonAlert,
                        enabled = state.canEdit,
                        testTag = "quick_add_sanidad",
                        onClick = { showQuickSanidad = true },
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionCardButton(
                        label = "Mover potrero",
                        icon = Icons.Filled.SwapHoriz,
                        tint = SkyInfo,
                        enabled = state.canEdit,
                        testTag = "quick_move_pasture",
                        onClick = { showQuickMove = true },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Resumen del Rebaño (Tarjetas estadísticas completas)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Resumen actualizado del criadero",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiMetricCard(
                        title = "Ovejas reprod.",
                        value = "${k.ovejasReproductoras}",
                        subtitle = "${k.hembrasPrenadas} preñadas · ${k.hembrasVacias} vacías",
                        icon = Icons.Outlined.Pets,
                        accentColor = ForestGreen,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        title = "Carneros / Corderos",
                        value = "${k.carneros} / ${k.corderos}",
                        subtitle = "${k.enEngorda} en engorda",
                        icon = Icons.Outlined.Category,
                        accentColor = MeadowGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KpiMetricCard(
                        title = "Nacimientos / Mortalidad",
                        value = "${k.nacimientosAnio} / ${k.mortalidadAnual}",
                        subtitle = "Temporada anual",
                        icon = Icons.Outlined.TrendingUp,
                        accentColor = PastureGreen,
                        modifier = Modifier.weight(1f)
                    )
                    KpiMetricCard(
                        title = "Sanidad y Partos",
                        value = "${k.enTratamiento} trat. · ${k.proximosPartosCount} partos",
                        subtitle = "${k.proximosManejosCount} manejos próx.",
                        icon = Icons.Outlined.EventAvailable,
                        accentColor = EarthTerracotta,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Alertas importantes
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = EarthTerracotta)
                            Spacer(Modifier.width(8.dp))
                            Text("Alertas importantes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        TextButton(onClick = onNavigateToAlerts) {
                            Text("Ver todas (${state.alertas.size})")
                        }
                    }
                    if (urgentAlerts.isEmpty()) {
                        Text(
                            "Sin alertas urgentes hoy. Todo el manejo al día.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        urgentAlerts.forEach { al ->
                            val badgeColor = when (al.prioridad) {
                                "Atrasada" -> CrimsonAlert
                                "Hoy" -> EarthTerracotta
                                else -> MeadowGreen
                            }
                            Surface(
                                color = badgeColor.copy(alpha = 0.08f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = badgeColor,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = al.prioridad,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(al.titulo, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(al.detalle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Gráfico de Evolución del Peso
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Evolución de peso del lote (kg)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Curvas recientes de crecimiento registrado", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    WeightEvolutionChart(series = weightSeries)
                }
            }
        }

        // Gráfico de Nacimientos y Mortalidad
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Nacimientos vs Mortalidad (6 meses)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    BirthsMortalityChart(partos = state.partos, animales = state.animales)
                }
            }
        }

        // Últimos Pesajes
        item {
            Text("Últimos pesajes registrados", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(recentWeighings, key = { it.id }) { p ->
            val animal = animalById[p.animalId]
            Card(
                shape = MaterialTheme.shapes.small,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = animal != null) { animal?.let { onOpenAnimalDetail(it.id) } }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Scale, contentDescription = null, tint = MeadowGreen)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = animal?.let { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" } ?: "Ovino #${p.animalId}",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "${ChileanFormatters.formatDate(p.fecha)} · ${p.observaciones.ifBlank { "Control de peso" }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = ChileanFormatters.formatKg(p.pesoKg),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ForestGreen
                    )
                }
            }
        }
    }

    if (showAddAnimal) QuickAnimalDialog(state = state, viewModel = viewModel) { showAddAnimal = false }
    if (showQuickWeight) QuickWeightDialog(state = state, viewModel = viewModel) { showQuickWeight = false }
    if (showQuickEncaste) QuickEncasteDialog(state = state, viewModel = viewModel) { showQuickEncaste = false }
    if (showQuickParto) QuickPartoDialog(state = state, viewModel = viewModel) { showQuickParto = false }
    if (showQuickSanidad) QuickSanidadDialog(state = state, viewModel = viewModel) { showQuickSanidad = false }
    if (showQuickMove) QuickMovePastureDialog(state = state, viewModel = viewModel) { showQuickMove = false }
}
