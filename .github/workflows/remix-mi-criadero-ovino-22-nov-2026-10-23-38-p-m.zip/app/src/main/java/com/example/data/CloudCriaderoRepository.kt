package com.example.data

import com.example.BuildConfig
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.WriteBatch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max

data class SyncMetadataSnapshot(
    val isFromCache: Boolean = false,
    val hasPendingWrites: Boolean = false
)

data class CloudSnapshotBundle(
    val workspace: CriaderoWorkspace? = null,
    val syncMeta: SyncMetadataSnapshot = SyncMetadataSnapshot()
)

class CloudCriaderoRepository(
    val db: FirebaseFirestore,
    val currentUser: FirebaseUser,
    val criaderoId: String = CloudSchema.DEFAULT_CRIADERO_ID
) {
    private val idCounter = AtomicLong(0L)
    private val workspacePath = "${CloudSchema.COL_CRIADEROS}/$criaderoId"
    val workspaceRef = db.collection(CloudSchema.COL_CRIADEROS).document(criaderoId)

    val currentUid: String get() = currentUser.uid
    val currentEmail: String get() = (currentUser.email ?: "").trim().lowercase()
    val currentDisplayName: String
        get() = currentUser.displayName?.takeIf { it.isNotBlank() }
            ?: currentEmail.substringBefore("@").ifBlank { "Usuario" }

    fun configuredInitialAdminEmail(): String =
        BuildConfig.CRIADERO_ADMIN_EMAIL.trim().lowercase()

    fun subCol(subcollection: String) = workspaceRef.collection(subcollection)

    fun nextRecordId(): Long =
        System.currentTimeMillis() * 100L + (idCounter.getAndIncrement() % 100L)

    // --- Access Bootstrap & Membership Resolution ---
    suspend fun resolveAndInitializeAccess(): Result<CloudAccessSession> {
        return try {
            if (!currentUser.isEmailVerified || currentEmail.isBlank()) {
                return Result.success(
                    CloudAccessSession(
                        isLoading = false,
                        isAuthorized = false,
                        isAdmin = false,
                        criaderoId = criaderoId,
                        statusMessage = "Tu cuenta Google debe tener correo verificado para acceder al criadero."
                    )
                )
            }

            val wsSnap = try {
                workspaceRef.get().await()
            } catch (e: FirebaseFirestoreException) {
                if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                    return Result.success(
                        CloudAccessSession(
                            isLoading = false,
                            isAuthorized = false,
                            isAdmin = false,
                            criaderoId = criaderoId,
                            statusMessage = "Tu correo ($currentEmail) no está autorizado en el criadero '$criaderoId'."
                        )
                    )
                }
                throw e
            }

            if (!wsSnap.exists()) {
                val expectedAdmin = configuredInitialAdminEmail()
                val canInit = expectedAdmin.isBlank() || expectedAdmin == currentEmail
                return Result.success(
                    CloudAccessSession(
                        isLoading = false,
                        isAuthorized = false,
                        isAdmin = false,
                        needsInitialSetup = true,
                        criaderoId = criaderoId,
                        statusMessage = if (canInit) {
                            "El criadero '$criaderoId' aún no está configurado en la nube."
                        } else {
                            "La creación inicial del criadero está reservada al correo configurado ($expectedAdmin). Si eres Socio, verifica el código de criadero."
                        }
                    )
                )
            }

            val ws = wsSnap.toObject(CriaderoWorkspace::class.java)
            if (ws == null) {
                return Result.success(
                    CloudAccessSession(
                        isLoading = false,
                        isAuthorized = false,
                        criaderoId = criaderoId,
                        statusMessage = "No se pudo leer la configuración del criadero."
                    )
                )
            }

            val pendingTarget = ws.pendingAdminEmail.trim().lowercase()
            if (ws.adminUid == currentUid) {
                val memberRef = subCol(CloudSchema.SUB_MEMBERS).document(currentUid)
                val memberSnap = memberRef.get().await()
                val batch = db.batch()
                var dirty = false
                if (currentUid !in ws.memberUids) {
                    batch.update(
                        workspaceRef,
                        mapOf(
                            "memberUids" to (ws.memberUids + currentUid).distinct().take(5),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    dirty = true
                }
                if (!memberSnap.exists()) {
                    batch.set(
                        memberRef,
                        mapOf(
                            "uid" to currentUid,
                            "adminUid" to currentUid,
                            "email" to currentEmail,
                            "displayName" to currentDisplayName.take(120),
                            "etiqueta" to "Administrador",
                            "rol" to "Administrador",
                            "activo" to true,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    dirty = true
                }
                if (dirty) batch.commit().await()

                val latestWs = workspaceRef.get().await().toObject(CriaderoWorkspace::class.java)
                val latestMember = memberRef.get().await().toObject(CriaderoMember::class.java)
                return Result.success(
                    CloudAccessSession(
                        isLoading = false,
                        isAuthorized = true,
                        isAdmin = true,
                        criaderoId = criaderoId,
                        workspace = latestWs,
                        currentMember = latestMember,
                        statusMessage = "Sesión de Administrador verificada."
                    )
                )
            }

            if (pendingTarget.isNotEmpty() && pendingTarget == currentEmail) {
                return Result.success(
                    CloudAccessSession(
                        isLoading = false,
                        isAuthorized = false,
                        isAdmin = false,
                        hasPendingAdminTransfer = true,
                        pendingTransferTargetEmail = ws.pendingAdminEmail,
                        criaderoId = criaderoId,
                        workspace = ws,
                        statusMessage = "Tienes una invitación pendiente para asumir como Administrador principal de '${ws.nombrePredio}'."
                    )
                )
            }

            val s1 = ws.socio1Email.trim().lowercase()
            val s2 = ws.socio2Email.trim().lowercase()
            val isInvited = currentEmail == s1 || currentEmail == s2
            if (!isInvited) {
                return Result.success(
                    CloudAccessSession(
                        isLoading = false,
                        isAuthorized = false,
                        isAdmin = false,
                        criaderoId = criaderoId,
                        statusMessage = "Acceso restringido: el Administrador del criadero '$criaderoId' debe autorizar '$currentEmail' como Socio 1 o Socio 2."
                    )
                )
            }

            if (currentUid !in ws.memberUids) {
                workspaceRef.update(
                    mapOf(
                        "memberUids" to (ws.memberUids + currentUid).distinct().take(5),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val memberRef = subCol(CloudSchema.SUB_MEMBERS).document(currentUid)
            val memberSnap = memberRef.get().await()
            if (!memberSnap.exists()) {
                val etiqueta = if (currentEmail == s1) "Socio 1" else "Socio 2"
                memberRef.set(
                    mapOf(
                        "uid" to currentUid,
                        "adminUid" to ws.adminUid,
                        "email" to currentEmail,
                        "displayName" to currentDisplayName.take(120),
                        "etiqueta" to etiqueta,
                        "rol" to "Consulta",
                        "activo" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            val latestWs = workspaceRef.get().await().toObject(CriaderoWorkspace::class.java)
            val latestMember = memberRef.get().await().toObject(CriaderoMember::class.java)
            val authorized = latestMember?.activo != false
            Result.success(
                CloudAccessSession(
                    isLoading = false,
                    isAuthorized = authorized,
                    isAdmin = false,
                    criaderoId = criaderoId,
                    workspace = latestWs,
                    currentMember = latestMember,
                    statusMessage = if (authorized) "Acceso de socio activo (Solo consulta)." else "Acceso deshabilitado por el Administrador."
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, workspacePath)
            Result.failure(e)
        }
    }

    suspend fun initializeWorkspaceAsAdmin(
        nombrePredio: String,
        socio1Email: String,
        socio2Email: String
    ): Result<CloudAccessSession> = runMutation(OperationType.CREATE, workspacePath) {
        require(currentUser.isEmailVerified && currentEmail.isNotBlank()) {
            "Tu cuenta Google debe tener correo verificado."
        }
        val expectedAdmin = configuredInitialAdminEmail()
        if (expectedAdmin.isNotBlank()) {
            require(currentEmail == expectedAdmin) {
                "La configuración de seguridad reserva el rol de Administrador inicial a $expectedAdmin."
            }
        }
        val existingSnap = workspaceRef.get().await()
        require(!existingSnap.exists()) {
            "Este criadero ya fue inicializado por otro Administrador."
        }

        val cleanNombre = nombrePredio.trim().ifBlank { "Mi Criadero Ovino" }.take(120)
        val s1 = socio1Email.trim().lowercase()
        val s2 = socio2Email.trim().lowercase()
        if (s1.isNotEmpty()) {
            require(s1.contains("@") && s1.contains(".")) { "Correo de Socio 1 inválido." }
            require(s1 != currentEmail) { "Socio 1 debe tener un correo diferente al Administrador." }
        }
        if (s2.isNotEmpty()) {
            require(s2.contains("@") && s2.contains(".")) { "Correo de Socio 2 inválido." }
            require(s2 != currentEmail) { "Socio 2 debe tener un correo diferente al Administrador." }
            require(s2 != s1) { "Socio 1 y Socio 2 deben tener correos distintos." }
        }

        // Paso 1: Crear y confirmar el documento raíz primero para que isCriaderoAdmin() vea el adminUid confirmado
        workspaceRef.set(
            mapOf(
                "nombrePredio" to cleanNombre,
                "adminUid" to currentUid,
                "adminEmail" to currentEmail,
                "socio1Email" to s1.take(160),
                "socio2Email" to s2.take(160),
                "pendingAdminEmail" to "",
                "memberUids" to listOf(currentUid),
                "migratedFromLocal" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        // Paso 2: Crear ficha de Administrador y registro inicial en auditoría
        val memberRef = subCol(CloudSchema.SUB_MEMBERS).document(currentUid)
        val batch = db.batch()
        batch.set(
            memberRef,
            mapOf(
                "uid" to currentUid,
                "adminUid" to currentUid,
                "email" to currentEmail,
                "displayName" to currentDisplayName.take(120),
                "etiqueta" to "Administrador",
                "rol" to "Administrador",
                "activo" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        appendAuditLog(
            batch = batch,
            memberUids = listOf(currentUid),
            accion = "CONFIGURACION",
            modulo = "Criadero",
            entidadId = criaderoId,
            entidadNombre = cleanNombre,
            resumen = "Inicialización del criadero y Administrador principal",
            valorAnterior = "",
            valorNuevo = "Admin=$currentEmail, S1=$s1, S2=$s2"
        )
        batch.commit().await()

        val latestWs = workspaceRef.get().await().toObject(CriaderoWorkspace::class.java)
        val latestMember = memberRef.get().await().toObject(CriaderoMember::class.java)
        CloudAccessSession(
            isLoading = false,
            isAuthorized = true,
            isAdmin = true,
            criaderoId = criaderoId,
            workspace = latestWs,
            currentMember = latestMember,
            statusMessage = "Criadero inicializado correctamente como Administrador."
        )
    }

    suspend fun requestAdminTransfer(
        targetEmail: String,
        currentWorkspace: CriaderoWorkspace?
    ): Result<Unit> = runMutation(OperationType.UPDATE, workspacePath) {
        val clean = targetEmail.trim().lowercase()
        if (clean.isNotEmpty()) {
            require(clean.contains("@") && clean.contains(".")) { "Ingresa un correo Google válido para el nuevo Administrador." }
            require(clean != currentEmail) { "El nuevo Administrador debe ser una cuenta Google distinta a la actual." }
        }
        val batch = db.batch()
        batch.update(
            workspaceRef,
            mapOf(
                "pendingAdminEmail" to clean.take(160),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        appendAuditLog(
            batch = batch,
            memberUids = currentWorkspace?.memberUids.orEmpty(),
            accion = "CONFIGURACION",
            modulo = "Equipo",
            entidadId = criaderoId,
            entidadNombre = "Traspaso de Administrador",
            resumen = if (clean.isEmpty()) "Cancelación de traspaso de Administrador" else "Invitación de traspaso de Administrador a $clean",
            valorAnterior = currentWorkspace?.adminEmail.orEmpty(),
            valorNuevo = clean.ifEmpty { "Cancelado" }
        )
        batch.commit().await()
    }

    suspend fun acceptAdminTransfer(): Result<CloudAccessSession> = runMutation(OperationType.UPDATE, workspacePath) {
        require(currentUser.isEmailVerified && currentEmail.isNotBlank()) {
            "Tu cuenta Google debe estar verificada."
        }
        val wsSnap = workspaceRef.get().await()
        val ws = wsSnap.toObject(CriaderoWorkspace::class.java)
            ?: throw IllegalStateException("El criadero no existe.")
        require(ws.pendingAdminEmail.trim().lowercase() == currentEmail) {
            "No hay un traspaso de administración pendiente para $currentEmail."
        }

        val oldAdminUid = ws.adminUid
        val oldAdminEmail = ws.adminEmail
        val updatedMemberUids = (ws.memberUids.filter { it != oldAdminUid } + currentUid).distinct().take(5)

        // Paso 1: Confirmar nuevo adminUid en el documento raíz
        workspaceRef.update(
            mapOf(
                "adminUid" to currentUid,
                "adminEmail" to currentEmail,
                "pendingAdminEmail" to "",
                "memberUids" to updatedMemberUids,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        // Paso 2: Si el nuevo administrador figuraba como socio, liberar esa ranura
        val clearSlots = mutableMapOf<String, Any>()
        if (ws.socio1Email.trim().lowercase() == currentEmail) clearSlots["socio1Email"] = ""
        if (ws.socio2Email.trim().lowercase() == currentEmail) clearSlots["socio2Email"] = ""
        if (clearSlots.isNotEmpty()) {
            clearSlots["updatedAt"] = FieldValue.serverTimestamp()
            workspaceRef.update(clearSlots).await()
        }

        // Paso 3: Actualizar miembros existentes, promover ficha propia, eliminar antiguo admin si corresponde y auditar
        val existingMembers = subCol(CloudSchema.SUB_MEMBERS).whereEqualTo("adminUid", oldAdminUid).get().await()
        val batch = db.batch()
        val myMemberRef = subCol(CloudSchema.SUB_MEMBERS).document(currentUid)
        val hadOwnMemberDoc = existingMembers.documents.any { it.id == currentUid }
        if (hadOwnMemberDoc) {
            batch.update(
                myMemberRef,
                mapOf(
                    "adminUid" to currentUid,
                    "displayName" to currentDisplayName.take(120),
                    "email" to currentEmail,
                    "etiqueta" to "Administrador",
                    "rol" to "Administrador",
                    "activo" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        } else {
            batch.set(
                myMemberRef,
                mapOf(
                    "uid" to currentUid,
                    "adminUid" to currentUid,
                    "email" to currentEmail,
                    "displayName" to currentDisplayName.take(120),
                    "etiqueta" to "Administrador",
                    "rol" to "Administrador",
                    "activo" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        existingMembers.documents.forEach { doc ->
            if (doc.id == oldAdminUid && oldAdminUid != currentUid) {
                batch.delete(doc.reference)
            } else if (doc.id != currentUid) {
                batch.update(
                    doc.reference,
                    mapOf(
                        "adminUid" to currentUid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }
        appendAuditLog(
            batch = batch,
            memberUids = updatedMemberUids,
            accion = "CONFIGURACION",
            modulo = "Equipo",
            entidadId = criaderoId,
            entidadNombre = ws.nombrePredio,
            resumen = "Traspaso de Administrador completado",
            valorAnterior = "$oldAdminEmail ($oldAdminUid)",
            valorNuevo = "$currentEmail ($currentUid)"
        )
        batch.commit().await()

        // Paso 4: Sincronizar memberUids en todas las subcolecciones (revoca acceso del admin anterior)
        syncMemberUidsAcrossFarm(updatedMemberUids)

        val latestWs = workspaceRef.get().await().toObject(CriaderoWorkspace::class.java)
        val latestMember = myMemberRef.get().await().toObject(CriaderoMember::class.java)
        CloudAccessSession(
            isLoading = false,
            isAuthorized = true,
            isAdmin = true,
            criaderoId = criaderoId,
            workspace = latestWs,
            currentMember = latestMember,
            statusMessage = "Administración principal transferida a $currentEmail."
        )
    }

    // --- Real-Time Snapshot Listeners ---
    fun observeWorkspace(): Flow<CloudSnapshotBundle> = callbackFlow {
        val reg = workspaceRef.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val ws = snap?.toObject(CriaderoWorkspace::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            val meta = snap?.metadata?.let {
                SyncMetadataSnapshot(isFromCache = it.isFromCache, hasPendingWrites = it.hasPendingWrites())
            } ?: SyncMetadataSnapshot()
            trySend(CloudSnapshotBundle(ws, meta))
        }
        awaitClose { reg.remove() }
    }

    fun observeAnimalesPendingWrites(): Flow<SyncMetadataSnapshot> = callbackFlow {
        val reg = subCol(CloudSchema.SUB_ANIMALES)
            .whereArrayContains("memberUids", currentUid)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val meta = snap?.metadata?.let {
                    SyncMetadataSnapshot(isFromCache = it.isFromCache, hasPendingWrites = it.hasPendingWrites())
                } ?: SyncMetadataSnapshot()
                trySend(meta)
            }
        awaitClose { reg.remove() }
    }

    fun observeCurrentMember(): Flow<CriaderoMember?> = callbackFlow {
        val reg = subCol(CloudSchema.SUB_MEMBERS).document(currentUid)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val member = snap?.toObject(CriaderoMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                trySend(member)
            }
        awaitClose { reg.remove() }
    }

    fun observeMembersForAdmin(adminUid: String): Flow<List<CriaderoMember>> = callbackFlow {
        val reg = subCol(CloudSchema.SUB_MEMBERS)
            .whereEqualTo("adminUid", adminUid)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val items = snap?.documents.orEmpty()
                    .mapNotNull { it.toObject(CriaderoMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                    .sortedBy { it.etiqueta }
                trySend(items)
            }
        awaitClose { reg.remove() }
    }

    inline fun <reified T> observeSubcollection(
        subcollection: String
    ): Flow<List<T>> = callbackFlow {
        val reg = subCol(subcollection)
            .whereArrayContains("memberUids", currentUid)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents.orEmpty().mapNotNull {
                    it.toObject(T::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    // --- Helper for Atomic Audit Logging ---
    fun appendAuditLog(
        batch: WriteBatch,
        memberUids: List<String>,
        accion: String,
        modulo: String,
        entidadId: String,
        entidadNombre: String,
        resumen: String,
        valorAnterior: String = "",
        valorNuevo: String = ""
    ) {
        val email = currentEmail
        require(email.isNotBlank()) { "Se requiere un correo autenticado para registrar auditoría." }
        val docRef = subCol(CloudSchema.SUB_AUDIT_LOGS).document()
        val entry = AuditLogEntry(
            memberUids = effectiveMemberUids(memberUids),
            actorUid = currentUid,
            actorEmail = email,
            actorNombre = currentDisplayName.ifBlank { email.substringBefore("@") },
            actorRol = "Administrador",
            accion = accion,
            modulo = modulo,
            entidadId = entidadId.ifBlank { criaderoId },
            entidadNombre = entidadNombre,
            resumen = resumen.ifBlank { "$accion en $modulo" },
            valorAnterior = valorAnterior,
            valorNuevo = valorNuevo,
            fechaClienteMs = System.currentTimeMillis()
        )
        batch.set(docRef, entry.toCreateMap())
    }

    fun effectiveMemberUids(memberUids: List<String>): List<String> =
        (memberUids + currentUid).distinct().take(5)

    // --- Partner & Workspace Admin Operations ---
    suspend fun updatePredioNombre(
        nombre: String,
        currentWorkspace: CriaderoWorkspace?
    ): Result<Unit> = runMutation(OperationType.UPDATE, workspacePath) {
        val clean = nombre.trim()
        require(clean.isNotBlank()) { "El nombre del criadero no puede estar vacío." }
        val batch = db.batch()
        batch.update(
            workspaceRef,
            mapOf(
                "nombrePredio" to clean.take(120),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        appendAuditLog(
            batch = batch,
            memberUids = currentWorkspace?.memberUids.orEmpty(),
            accion = "CONFIGURACION",
            modulo = "Criadero",
            entidadId = criaderoId,
            entidadNombre = clean,
            resumen = "Actualización del nombre del predio",
            valorAnterior = currentWorkspace?.nombrePredio ?: "",
            valorNuevo = clean
        )
        batch.commit().await()
    }

    suspend fun updatePartnerEmails(
        socio1Email: String,
        socio2Email: String,
        currentWorkspace: CriaderoWorkspace?
    ): Result<Unit> = runMutation(OperationType.UPDATE, workspacePath) {
        val s1 = socio1Email.trim().lowercase()
        val s2 = socio2Email.trim().lowercase()
        val adminEmail = (currentWorkspace?.adminEmail ?: currentEmail).lowercase()
        if (s1.isNotEmpty()) {
            require(s1.contains("@") && s1.contains(".")) { "Correo de Socio 1 inválido." }
            require(s1 != adminEmail) { "El Socio 1 debe usar una cuenta diferente al Administrador." }
        }
        if (s2.isNotEmpty()) {
            require(s2.contains("@") && s2.contains(".")) { "Correo de Socio 2 inválido." }
            require(s2 != adminEmail) { "El Socio 2 debe usar una cuenta diferente al Administrador." }
            require(s2 != s1) { "Socio 1 y Socio 2 deben tener correos distintos." }
        }

        // Detectar socios revocados y limpiar su UID para impedir lecturas futuras
        val allowedEmails = setOf(s1, s2).filter { it.isNotEmpty() }.toSet()
        val existingMembers = subCol(CloudSchema.SUB_MEMBERS).whereEqualTo("adminUid", currentUid).get().await()
        val revokedUids = mutableSetOf<String>()
        val revokedRefs = mutableListOf<com.google.firebase.firestore.DocumentReference>()
        existingMembers.documents.forEach { doc ->
            val uid = doc.getString("uid") ?: doc.id
            val mail = doc.getString("email")?.trim()?.lowercase().orEmpty()
            if (uid != currentUid && mail !in allowedEmails) {
                revokedUids += uid
                revokedRefs += doc.reference
            }
        }
        val cleanMemberUids = (currentWorkspace?.memberUids.orEmpty().filterNot { it in revokedUids } + currentUid)
            .distinct()
            .take(5)

        val batch = db.batch()
        batch.update(
            workspaceRef,
            mapOf(
                "socio1Email" to s1.take(160),
                "socio2Email" to s2.take(160),
                "memberUids" to cleanMemberUids,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        revokedRefs.forEach { batch.delete(it) }
        appendAuditLog(
            batch = batch,
            memberUids = cleanMemberUids,
            accion = "CONFIGURACION",
            modulo = "Equipo",
            entidadId = criaderoId,
            entidadNombre = "Accesos de Socios",
            resumen = "Actualización de correos autorizados para consulta",
            valorAnterior = "S1=${currentWorkspace?.socio1Email.orEmpty()}, S2=${currentWorkspace?.socio2Email.orEmpty()}",
            valorNuevo = "S1=$s1, S2=$s2"
        )
        batch.commit().await()

        if (revokedUids.isNotEmpty()) {
            syncMemberUidsAcrossFarm(cleanMemberUids)
        }
    }

    suspend fun syncMemberUidsAcrossFarm(targetMemberUids: List<String>): Result<Int> =
        runMutation(OperationType.UPDATE, "$workspacePath/syncMembers") {
            val targetSet = effectiveMemberUids(targetMemberUids).toSet()
            val targetList = targetSet.toList()
            val allSubcollections = listOf(
                CloudSchema.SUB_ANIMALES,
                CloudSchema.SUB_PESAJES,
                CloudSchema.SUB_ENCASTES,
                CloudSchema.SUB_GESTACIONES,
                CloudSchema.SUB_PARTOS,
                CloudSchema.SUB_SANIDAD,
                CloudSchema.SUB_POTREROS,
                CloudSchema.SUB_MOV_POTRERO,
                CloudSchema.SUB_RACIONES,
                CloudSchema.SUB_INVENTARIO,
                CloudSchema.SUB_MOV_INVENTARIO,
                CloudSchema.SUB_TRANSACCIONES,
                CloudSchema.SUB_LOTES,
                CloudSchema.SUB_DESTETES,
                CloudSchema.SUB_AUDIT_LOGS,
                CloudSchema.SUB_BACKUPS
            )
            var updatedCount = 0
            val pendingUpdates = mutableListOf<com.google.firebase.firestore.DocumentReference>()
            for (colName in allSubcollections) {
                val snap = subCol(colName).whereArrayContains("memberUids", currentUid).get().await()
                for (doc in snap.documents) {
                    @Suppress("UNCHECKED_CAST")
                    val existingUids = (doc.get("memberUids") as? List<String>)?.toSet().orEmpty()
                    if (existingUids != targetSet) {
                        pendingUpdates += doc.reference
                    }
                }
            }
            for (chunk in pendingUpdates.chunked(400)) {
                val batch = db.batch()
                chunk.forEach { ref ->
                    batch.update(
                        ref,
                        mapOf(
                            "memberUids" to targetList,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                batch.commit().await()
                updatedCount += chunk.size
            }
            updatedCount
        }

    // --- Animales ---
    suspend fun saveAnimal(
        animal: AnimalEntity,
        previousAnimal: AnimalEntity?,
        existingAnimales: List<AnimalEntity>,
        memberUids: List<String>
    ): Result<Long> = runMutation(OperationType.WRITE, "$workspacePath/${CloudSchema.SUB_ANIMALES}") {
        val cleanArete = animal.arete.trim()
        require(cleanArete.isNotEmpty()) { "El número de arete es obligatorio." }
        require(animal.pesoNacimientoKg >= 0.0 && animal.pesoActualKg >= 0.0) {
            "Los pesos deben ser valores positivos en kg."
        }
        val duplicate = existingAnimales.firstOrNull {
            it.arete.equals(cleanArete, ignoreCase = true) && it.id != animal.id
        }
        if (duplicate != null) {
            throw IllegalArgumentException("Ya existe un ovino registrado con el arete '$cleanArete'.")
        }

        val uids = effectiveMemberUids(memberUids)
        val batch = db.batch()
        val isCreate = animal.id == 0L
        val recordId = if (isCreate) nextRecordId() else animal.id
        val normalized = animal.copy(id = recordId, arete = cleanArete)
        val docRef = subCol(CloudSchema.SUB_ANIMALES).document(recordId.toString())

        if (isCreate) {
            batch.set(docRef, normalized.toCloudCreateMap(uids))
            if (normalized.pesoActualKg > 0) {
                val ageDays = max(0, ((System.currentTimeMillis() - normalized.fechaNacimiento) / CriaderoRepository.DAY_MS).toInt())
                val pesajeId = nextRecordId()
                val pesaje = PesajeEntity(
                    id = pesajeId,
                    animalId = recordId,
                    fecha = normalized.fechaIngreso,
                    pesoKg = normalized.pesoActualKg,
                    edadDias = ageDays,
                    observaciones = "Peso inicial al registrar ficha"
                )
                batch.set(subCol(CloudSchema.SUB_PESAJES).document(pesajeId.toString()), pesaje.toCloudCreateMap(uids))
            }
            appendAuditLog(
                batch, uids, "CREAR", "Animales", recordId.toString(),
                "${normalized.arete} ${normalized.nombre}".trim(),
                "Alta de ovino ${normalized.raza} (${normalized.sexo})",
                "",
                "Arete=${normalized.arete}, Peso=${normalized.pesoActualKg}kg, Estado=${normalized.estado}"
            )
        } else {
            batch.update(docRef, normalized.toCloudUpdateMap(uids))
            val prevSummary = previousAnimal?.let {
                "Peso=${it.pesoActualKg}kg, Estado=${it.estado}, Potrero=${it.potreroId}, Preñada=${it.prenada}"
            } ?: ""
            val newSummary = "Peso=${normalized.pesoActualKg}kg, Estado=${normalized.estado}, Potrero=${normalized.potreroId}, Preñada=${normalized.prenada}"
            appendAuditLog(
                batch, uids, "ACTUALIZAR", "Animales", recordId.toString(),
                "${normalized.arete} ${normalized.nombre}".trim(),
                "Edición de ficha ovina",
                prevSummary,
                newSummary
            )
        }
        batch.commit().await()
        recordId
    }

    suspend fun darDeBajaAnimal(
        animal: AnimalEntity,
        nuevoEstado: String,
        motivo: String,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.UPDATE, "$workspacePath/${CloudSchema.SUB_ANIMALES}/${animal.id}") {
        val uids = effectiveMemberUids(memberUids)
        val updatedObs = if (motivo.isBlank()) animal.observaciones else {
            listOf(animal.observaciones, "Baja ($nuevoEstado): $motivo")
                .filter { it.isNotBlank() }
                .joinToString("\n")
        }
        val updated = animal.copy(estado = nuevoEstado, prenada = false, fechaProbableParto = null, observaciones = updatedObs)
        val batch = db.batch()
        batch.update(subCol(CloudSchema.SUB_ANIMALES).document(animal.id.toString()), updated.toCloudUpdateMap(uids))
        appendAuditLog(
            batch, uids, "ACTUALIZAR", "Animales", animal.id.toString(),
            animal.arete,
            "Cambio de estado a $nuevoEstado",
            "Estado=${animal.estado}",
            "Estado=$nuevoEstado · ${motivo.ifBlank { "Sin motivo" }}"
        )
        batch.commit().await()
    }

    // --- Pesajes ---
    suspend fun registrarPesaje(
        animal: AnimalEntity,
        pesoKg: Double,
        fecha: Long,
        observaciones: String,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.WRITE, "$workspacePath/${CloudSchema.SUB_PESAJES}") {
        require(pesoKg > 0.0) { "El peso debe ser mayor a 0 kg." }
        val uids = effectiveMemberUids(memberUids)
        val edadDias = max(0, ((fecha - animal.fechaNacimiento) / CriaderoRepository.DAY_MS).toInt())
        val pesajeId = nextRecordId()
        val pesaje = PesajeEntity(
            id = pesajeId,
            animalId = animal.id,
            fecha = fecha,
            pesoKg = pesoKg,
            edadDias = edadDias,
            observaciones = observaciones.trim()
        )
        val updatedAnimal = animal.copy(pesoActualKg = pesoKg)
        val batch = db.batch()
        batch.set(subCol(CloudSchema.SUB_PESAJES).document(pesajeId.toString()), pesaje.toCloudCreateMap(uids))
        batch.update(subCol(CloudSchema.SUB_ANIMALES).document(animal.id.toString()), updatedAnimal.toCloudUpdateMap(uids))
        appendAuditLog(
            batch, uids, "CREAR", "Pesajes", pesajeId.toString(),
            animal.arete,
            "Registro de pesaje ${pesoKg} kg",
            "Peso=${animal.pesoActualKg} kg",
            "Peso=${pesoKg} kg"
        )
        batch.commit().await()
    }

    // --- Reproducción ---
    suspend fun registrarEncaste(
        fechaInicio: Long,
        fechaTermino: Long,
        carneroId: Long,
        ovejaIds: List<Long>,
        metodo: String,
        observaciones: String,
        memberUids: List<String>,
        crearGestacionesTentativas: Boolean = true
    ): Result<Unit> = runMutation(OperationType.CREATE, "$workspacePath/${CloudSchema.SUB_ENCASTES}") {
        require(ovejaIds.isNotEmpty()) { "Seleccione al menos una oveja para el encaste." }
        val uids = effectiveMemberUids(memberUids)
        val encasteId = nextRecordId()
        val encaste = EncasteEntity(
            id = encasteId,
            fechaInicio = fechaInicio,
            fechaTermino = fechaTermino,
            carneroId = carneroId,
            ovejaIdsCsv = ovejaIds.joinToString(","),
            metodo = metodo,
            observaciones = observaciones
        )
        val batch = db.batch()
        batch.set(subCol(CloudSchema.SUB_ENCASTES).document(encasteId.toString()), encaste.toCloudCreateMap(uids))
        if (crearGestacionesTentativas) {
            val fpp = fechaInicio + CriaderoRepository.GESTATION_DAYS * CriaderoRepository.DAY_MS
            ovejaIds.forEach { ovejaId ->
                val gestId = nextRecordId()
                val gest = GestacionEntity(
                    id = gestId,
                    ovejaId = ovejaId,
                    carneroId = carneroId,
                    encasteId = encasteId,
                    fechaEncaste = fechaInicio,
                    fechaDiagnostico = fechaInicio,
                    estadoGestacion = "Dudosa",
                    numeroFetos = 1,
                    fechaProbableParto = fpp,
                    observaciones = "Generada automáticamente desde encaste ($metodo)"
                )
                batch.set(subCol(CloudSchema.SUB_GESTACIONES).document(gestId.toString()), gest.toCloudCreateMap(uids))
            }
        }
        appendAuditLog(
            batch, uids, "CREAR", "Reproducción", encasteId.toString(),
            "Encaste $metodo",
            "Encaste con ${ovejaIds.size} oveja(s)",
            "",
            "Carnero #$carneroId · ${ovejaIds.size} ovejas"
        )
        batch.commit().await()
    }

    suspend fun registrarGestacion(
        oveja: AnimalEntity,
        carneroId: Long?,
        fechaEncaste: Long,
        fechaDiagnostico: Long,
        estadoGestacion: String,
        numeroFetos: Int,
        observaciones: String,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.WRITE, "$workspacePath/${CloudSchema.SUB_GESTACIONES}") {
        val uids = effectiveMemberUids(memberUids)
        val fpp = fechaEncaste + CriaderoRepository.GESTATION_DAYS * CriaderoRepository.DAY_MS
        val gestId = nextRecordId()
        val gest = GestacionEntity(
            id = gestId,
            ovejaId = oveja.id,
            carneroId = carneroId,
            fechaEncaste = fechaEncaste,
            fechaDiagnostico = fechaDiagnostico,
            estadoGestacion = estadoGestacion,
            numeroFetos = numeroFetos,
            fechaProbableParto = fpp,
            observaciones = observaciones
        )
        val isPregnant = estadoGestacion == "Preñada"
        val updatedOveja = oveja.copy(
            prenada = isPregnant,
            fechaProbableParto = if (isPregnant) fpp else null
        )
        val batch = db.batch()
        batch.set(subCol(CloudSchema.SUB_GESTACIONES).document(gestId.toString()), gest.toCloudCreateMap(uids))
        batch.update(subCol(CloudSchema.SUB_ANIMALES).document(oveja.id.toString()), updatedOveja.toCloudUpdateMap(uids))
        appendAuditLog(
            batch, uids, "CREAR", "Reproducción", gestId.toString(),
            oveja.arete,
            "Diagnóstico de gestación: $estadoGestacion",
            "Preñada=${oveja.prenada}",
            "Estado=$estadoGestacion · Fetos=$numeroFetos"
        )
        batch.commit().await()
    }

    suspend fun registrarPartoYCrearCorderos(
        madre: AnimalEntity,
        padre: AnimalEntity?,
        existingAnimales: List<AnimalEntity>,
        fechaParto: Long,
        asistencia: String,
        observaciones: String,
        crias: List<LambBirthInput>,
        memberUids: List<String>
    ): Result<Int> = runMutation(OperationType.WRITE, "$workspacePath/${CloudSchema.SUB_PARTOS}") {
        require(crias.isNotEmpty()) { "Debe ingresar al menos una cría." }
        val liveAretes = crias.filter { it.vivo }.map { it.arete.trim() }
        require(liveAretes.all { it.isNotEmpty() }) {
            "Cada cría viva requiere un número de arete único."
        }
        require(liveAretes.distinctBy { it.lowercase() }.size == liveAretes.size) {
            "Los aretes de las crías no pueden repetirse."
        }
        for (arete in liveAretes) {
            if (existingAnimales.any { it.arete.equals(arete, ignoreCase = true) }) {
                throw IllegalArgumentException("El arete '$arete' ya está registrado en el criadero.")
            }
        }

        val uids = effectiveMemberUids(memberUids)
        val tipoParto = when (crias.size) {
            1 -> "Único"
            2 -> "Mellizo"
            else -> "Trillizo"
        }
        val detalle = crias.joinToString("; ") {
            val estadoStr = if (it.vivo) "Vivo - ${it.arete}" else "Mortinato"
            "${it.sexo} ${"%.1f".format(it.pesoNacimientoKg)} kg ($estadoStr)"
        }
        val razaCordero = when {
            padre == null || padre.raza == madre.raza -> madre.raza
            else -> "${padre.raza} x ${madre.raza}"
        }

        val partoId = nextRecordId()
        val parto = PartoEntity(
            id = partoId,
            madreId = madre.id,
            padreId = padre?.id,
            fechaParto = fechaParto,
            cantidadCrias = crias.size,
            criasVivas = crias.count { it.vivo },
            criasMuertas = crias.count { !it.vivo },
            tipoParto = tipoParto,
            asistencia = asistencia,
            detalleCrias = detalle,
            observaciones = observaciones
        )

        val batch = db.batch()
        batch.set(subCol(CloudSchema.SUB_PARTOS).document(partoId.toString()), parto.toCloudCreateMap(uids))
        val updatedMadre = madre.copy(prenada = false, fechaProbableParto = null)
        batch.update(subCol(CloudSchema.SUB_ANIMALES).document(madre.id.toString()), updatedMadre.toCloudUpdateMap(uids))

        var createdCount = 0
        crias.filter { it.vivo }.forEach { cria ->
            val newId = nextRecordId()
            val cordero = AnimalEntity(
                id = newId,
                arete = cria.arete.trim(),
                nombre = cria.nombre.trim(),
                sexo = cria.sexo,
                raza = razaCordero,
                fechaNacimiento = fechaParto,
                pesoNacimientoKg = cria.pesoNacimientoKg,
                pesoActualKg = cria.pesoNacimientoKg,
                madreId = madre.id,
                padreId = padre?.id,
                tipoNacimiento = tipoParto,
                predioOrigen = "Propio",
                fechaIngreso = fechaParto,
                estado = "Activo",
                proposito = "Engorda",
                potreroId = madre.potreroId,
                loteId = null,
                destetado = false,
                observaciones = "Nacido de madre ${madre.arete}"
            )
            val pesajeId = nextRecordId()
            val pesaje = PesajeEntity(
                id = pesajeId,
                animalId = newId,
                fecha = fechaParto,
                pesoKg = cria.pesoNacimientoKg,
                edadDias = 0,
                observaciones = "Peso al nacimiento (Parto $tipoParto)"
            )
            batch.set(subCol(CloudSchema.SUB_ANIMALES).document(newId.toString()), cordero.toCloudCreateMap(uids))
            batch.set(subCol(CloudSchema.SUB_PESAJES).document(pesajeId.toString()), pesaje.toCloudCreateMap(uids))
            createdCount++
        }

        appendAuditLog(
            batch, uids, "CREAR", "Partos", partoId.toString(),
            "Parto ${madre.arete}",
            "Parto $tipoParto · $createdCount cría(s) viva(s)",
            "Preñada=true",
            detalle
        )
        batch.commit().await()
        createdCount
    }

    // --- Sanidad ---
    suspend fun saveSanidad(sanidad: SanidadEntity, memberUids: List<String>): Result<Long> =
        runMutation(OperationType.CREATE, "$workspacePath/${CloudSchema.SUB_SANIDAD}") {
            require(sanidad.diagnostico.isNotBlank()) { "El diagnóstico o manejo es obligatorio." }
            val uids = effectiveMemberUids(memberUids)
            val id = if (sanidad.id == 0L) nextRecordId() else sanidad.id
            val normalized = sanidad.copy(id = id)
            val batch = db.batch()
            batch.set(subCol(CloudSchema.SUB_SANIDAD).document(id.toString()), normalized.toCloudCreateMap(uids))
            appendAuditLog(
                batch, uids, "CREAR", "Sanidad", id.toString(),
                normalized.diagnostico,
                "${normalized.tipoManejo} registrado",
                "",
                "${normalized.medicamento} (${normalized.evolucion})"
            )
            batch.commit().await()
            id
        }

    suspend fun marcarSanidadRecuperada(sanidad: SanidadEntity, memberUids: List<String>): Result<Unit> =
        runMutation(OperationType.UPDATE, "$workspacePath/${CloudSchema.SUB_SANIDAD}/${sanidad.id}") {
            val uids = effectiveMemberUids(memberUids)
            val batch = db.batch()
            batch.update(
                subCol(CloudSchema.SUB_SANIDAD).document(sanidad.id.toString()),
                mapOf(
                    "evolucion" to "Recuperado",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            appendAuditLog(
                batch, uids, "ACTUALIZAR", "Sanidad", sanidad.id.toString(),
                sanidad.diagnostico,
                "Evolución sanitaria actualizada",
                sanidad.evolucion,
                "Recuperado"
            )
            batch.commit().await()
        }

    // --- Potreros & Movimientos ---
    suspend fun savePotrero(potrero: PotreroEntity, memberUids: List<String>): Result<Long> =
        runMutation(OperationType.CREATE, "$workspacePath/${CloudSchema.SUB_POTREROS}") {
            require(potrero.nombre.isNotBlank()) { "El nombre del potrero es obligatorio." }
            require(potrero.superficieHa > 0.0) { "La superficie en hectáreas debe ser mayor a 0." }
            val uids = effectiveMemberUids(memberUids)
            val id = if (potrero.id == 0L) nextRecordId() else potrero.id
            val normalized = potrero.copy(id = id)
            val batch = db.batch()
            batch.set(subCol(CloudSchema.SUB_POTREROS).document(id.toString()), normalized.toCloudCreateMap(uids))
            appendAuditLog(
                batch, uids, "CREAR", "Potreros", id.toString(),
                normalized.nombre,
                "Nuevo potrero ${normalized.superficieHa} ha",
                "",
                normalized.tipoPradera
            )
            batch.commit().await()
            id
        }

    suspend fun moverAnimalesDePotrero(
        selectedAnimals: List<AnimalEntity>,
        potreroOrigen: PotreroEntity?,
        potreroDestino: PotreroEntity,
        motivo: String,
        observaciones: String,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.WRITE, "$workspacePath/${CloudSchema.SUB_MOV_POTRERO}") {
        require(selectedAnimals.isNotEmpty()) { "Seleccione al menos un animal para mover." }
        val uids = effectiveMemberUids(memberUids)
        val now = System.currentTimeMillis()
        val movId = nextRecordId()
        val mov = MovimientoPotreroEntity(
            id = movId,
            potreroOrigenId = potreroOrigen?.id,
            potreroDestinoId = potreroDestino.id,
            cantidadAnimales = selectedAnimals.size,
            animalIdsCsv = selectedAnimals.joinToString(",") { it.id.toString() },
            fechaMovimiento = now,
            motivo = motivo.ifBlank { "Rotación de pradera" },
            observaciones = observaciones
        )
        val batch = db.batch()
        selectedAnimals.forEach { a ->
            batch.update(
                subCol(CloudSchema.SUB_ANIMALES).document(a.id.toString()),
                a.copy(potreroId = potreroDestino.id).toCloudUpdateMap(uids)
            )
        }
        batch.set(subCol(CloudSchema.SUB_MOV_POTRERO).document(movId.toString()), mov.toCloudCreateMap(uids))
        batch.update(
            subCol(CloudSchema.SUB_POTREROS).document(potreroDestino.id.toString()),
            mapOf(
                "estadoPasto" to "En uso",
                "fechaEntrada" to now,
                "fechaSalida" to FieldValue.delete(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        if (potreroOrigen != null && potreroOrigen.id != potreroDestino.id) {
            batch.update(
                subCol(CloudSchema.SUB_POTREROS).document(potreroOrigen.id.toString()),
                mapOf(
                    "estadoPasto" to "En descanso",
                    "fechaSalida" to now,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        appendAuditLog(
            batch, uids, "ACTUALIZAR", "Potreros", movId.toString(),
            potreroDestino.nombre,
            "Traslado de ${selectedAnimals.size} ovino(s) a ${potreroDestino.nombre}",
            potreroOrigen?.nombre ?: "Sin potrero",
            potreroDestino.nombre
        )
        batch.commit().await()
    }

    // --- Alimentación ---
    suspend fun saveRacion(racion: AlimentoRacionEntity, memberUids: List<String>): Result<Long> =
        runMutation(OperationType.CREATE, "$workspacePath/${CloudSchema.SUB_RACIONES}") {
            require(racion.nombre.isNotBlank()) { "El nombre de la ración es obligatorio." }
            val uids = effectiveMemberUids(memberUids)
            val id = if (racion.id == 0L) nextRecordId() else racion.id
            val normalized = racion.copy(id = id)
            val batch = db.batch()
            batch.set(subCol(CloudSchema.SUB_RACIONES).document(id.toString()), normalized.toCloudCreateMap(uids))
            appendAuditLog(
                batch, uids, "CREAR", "Alimentación", id.toString(),
                normalized.nombre,
                "Ración ${normalized.tipoAlimento} (${normalized.cantidadAnimales} ovinos)",
                "",
                "${normalized.cantidadDiariaAnimalKg} kg/día"
            )
            batch.commit().await()
            id
        }

    // --- Inventario ---
    suspend fun saveInventarioItem(item: InventarioItemEntity, memberUids: List<String>): Result<Long> =
        runMutation(OperationType.CREATE, "$workspacePath/${CloudSchema.SUB_INVENTARIO}") {
            require(item.nombre.isNotBlank()) { "El nombre del insumo es obligatorio." }
            val uids = effectiveMemberUids(memberUids)
            val id = if (item.id == 0L) nextRecordId() else item.id
            val normalized = item.copy(id = id)
            val batch = db.batch()
            batch.set(subCol(CloudSchema.SUB_INVENTARIO).document(id.toString()), normalized.toCloudCreateMap(uids))
            appendAuditLog(
                batch, uids, "CREAR", "Inventario", id.toString(),
                normalized.nombre,
                "Alta de insumo en bodega",
                "",
                "${normalized.cantidadDisponible} ${normalized.unidad}"
            )
            batch.commit().await()
            id
        }

    suspend fun registrarMovimientoInventario(
        item: InventarioItemEntity,
        tipo: String,
        cantidad: Double,
        costoTotalClp: Double,
        nota: String,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.WRITE, "$workspacePath/${CloudSchema.SUB_INVENTARIO}/${item.id}") {
        require(cantidad > 0.0) { "La cantidad debe ser mayor a 0." }
        val uids = effectiveMemberUids(memberUids)
        val nuevaCantidad = if (tipo.startsWith("Entrada")) {
            item.cantidadDisponible + cantidad
        } else {
            max(0.0, item.cantidadDisponible - cantidad)
        }
        val nuevoCosto = if (tipo.startsWith("Entrada") && costoTotalClp > 0) {
            costoTotalClp / cantidad
        } else {
            item.ultimoCostoUnitarioClp
        }
        val movId = nextRecordId()
        val mov = MovimientoInventarioEntity(
            id = movId,
            itemId = item.id,
            tipo = tipo,
            cantidad = cantidad,
            fecha = System.currentTimeMillis(),
            costoTotalClp = costoTotalClp,
            nota = nota
        )
        val batch = db.batch()
        batch.update(
            subCol(CloudSchema.SUB_INVENTARIO).document(item.id.toString()),
            mapOf(
                "cantidadDisponible" to nuevaCantidad,
                "ultimoCostoUnitarioClp" to nuevoCosto,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(subCol(CloudSchema.SUB_MOV_INVENTARIO).document(movId.toString()), mov.toCloudCreateMap(uids))
        appendAuditLog(
            batch, uids, "ACTUALIZAR", "Inventario", item.id.toString(),
            item.nombre,
            "$tipo de $cantidad ${item.unidad}",
            "${item.cantidadDisponible} ${item.unidad}",
            "$nuevaCantidad ${item.unidad}"
        )
        batch.commit().await()
    }

    // --- Economía ---
    suspend fun saveTransaccion(tx: TransaccionEconomicaEntity, memberUids: List<String>): Result<Long> =
        runMutation(OperationType.CREATE, "$workspacePath/${CloudSchema.SUB_TRANSACCIONES}") {
            require(tx.montoClp > 0.0) { "El monto en CLP debe ser mayor a 0." }
            val uids = effectiveMemberUids(memberUids)
            val id = if (tx.id == 0L) nextRecordId() else tx.id
            val normalized = tx.copy(id = id)
            val batch = db.batch()
            batch.set(subCol(CloudSchema.SUB_TRANSACCIONES).document(id.toString()), normalized.toCloudCreateMap(uids))
            appendAuditLog(
                batch, uids, "CREAR", "Economía", id.toString(),
                "${normalized.tipo}: ${normalized.categoria}",
                "Registro económico por ${normalized.montoClp.toLong()} CLP",
                "",
                normalized.descripcion
            )
            batch.commit().await()
            id
        }

    // --- Lotes & Destete ---
    suspend fun saveLote(
        lote: LoteEntity,
        selectedAnimals: List<AnimalEntity>,
        memberUids: List<String>
    ): Result<Long> = runMutation(OperationType.CREATE, "$workspacePath/${CloudSchema.SUB_LOTES}") {
        require(lote.nombre.isNotBlank()) { "El nombre del lote es obligatorio." }
        val uids = effectiveMemberUids(memberUids)
        val id = if (lote.id == 0L) nextRecordId() else lote.id
        val normalized = lote.copy(id = id)
        val batch = db.batch()
        batch.set(subCol(CloudSchema.SUB_LOTES).document(id.toString()), normalized.toCloudCreateMap(uids))
        selectedAnimals.forEach { a ->
            batch.update(
                subCol(CloudSchema.SUB_ANIMALES).document(a.id.toString()),
                a.copy(loteId = id).toCloudUpdateMap(uids)
            )
        }
        appendAuditLog(
            batch, uids, "CREAR", "Lotes", id.toString(),
            normalized.nombre,
            "Creación de lote con ${selectedAnimals.size} ovino(s)",
            "",
            "${normalized.criterio} · ${normalized.objetivoProductivo}"
        )
        batch.commit().await()
        id
    }

    suspend fun registrarDestete(
        cordero: AnimalEntity,
        fecha: Long,
        pesoKg: Double,
        tipoDestete: String,
        loteDestinoId: Long?,
        observaciones: String,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.WRITE, "$workspacePath/${CloudSchema.SUB_DESTETES}") {
        require(pesoKg > 0.0) { "El peso al destete debe ser mayor a 0 kg." }
        val uids = effectiveMemberUids(memberUids)
        val edadDias = max(0, ((fecha - cordero.fechaNacimiento) / CriaderoRepository.DAY_MS).toInt())
        val desteteId = nextRecordId()
        val destete = DesteteEntity(
            id = desteteId,
            corderoId = cordero.id,
            madreId = cordero.madreId,
            fecha = fecha,
            pesoKg = pesoKg,
            tipoDestete = tipoDestete,
            loteDestinoId = loteDestinoId,
            observaciones = observaciones
        )
        val pesajeId = nextRecordId()
        val pesaje = PesajeEntity(
            id = pesajeId,
            animalId = cordero.id,
            fecha = fecha,
            pesoKg = pesoKg,
            edadDias = edadDias,
            observaciones = "Pesaje de destete ($tipoDestete)"
        )
        val updatedCordero = cordero.copy(
            destetado = true,
            pesoActualKg = pesoKg,
            loteId = loteDestinoId ?: cordero.loteId
        )
        val batch = db.batch()
        batch.set(subCol(CloudSchema.SUB_DESTETES).document(desteteId.toString()), destete.toCloudCreateMap(uids))
        batch.set(subCol(CloudSchema.SUB_PESAJES).document(pesajeId.toString()), pesaje.toCloudCreateMap(uids))
        batch.update(subCol(CloudSchema.SUB_ANIMALES).document(cordero.id.toString()), updatedCordero.toCloudUpdateMap(uids))
        appendAuditLog(
            batch, uids, "CREAR", "Destetes", desteteId.toString(),
            cordero.arete,
            "Destete ($tipoDestete) a ${pesoKg} kg",
            "Destetado=${cordero.destetado}, Peso=${cordero.pesoActualKg}kg",
            "Destetado=true, Peso=${pesoKg}kg"
        )
        batch.commit().await()
    }

    // --- Soft Delete, Papelera Restore, Permanent Delete ---
    suspend fun softDeleteRecord(
        collection: String,
        docId: String,
        modulo: String,
        titulo: String,
        valorAnterior: String,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.UPDATE, "$workspacePath/$collection/$docId") {
        val uids = effectiveMemberUids(memberUids)
        val batch = db.batch()
        batch.update(
            subCol(collection).document(docId),
            mapOf(
                "registroActivo" to false,
                "eliminadoAt" to System.currentTimeMillis(),
                "eliminadoPor" to currentEmail.ifBlank { currentUid },
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        appendAuditLog(
            batch, uids, "ELIMINAR", modulo, docId, titulo,
            "Movido a Papelera (recuperable)",
            valorAnterior,
            "registroActivo=false"
        )
        batch.commit().await()
    }

    suspend fun restoreRecord(
        item: DeletedRecordItem,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.UPDATE, "$workspacePath/${item.collection}/${item.docId}") {
        val uids = effectiveMemberUids(memberUids)
        val batch = db.batch()
        batch.update(
            subCol(item.collection).document(item.docId),
            mapOf(
                "registroActivo" to true,
                "eliminadoAt" to FieldValue.delete(),
                "eliminadoPor" to FieldValue.delete(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        appendAuditLog(
            batch, uids, "RESTAURAR", item.modulo, item.docId, item.titulo,
            "Registro recuperado desde Papelera",
            "registroActivo=false",
            "registroActivo=true"
        )
        batch.commit().await()
    }

    suspend fun permanentDeleteRecord(
        item: DeletedRecordItem,
        memberUids: List<String>
    ): Result<Unit> = runMutation(OperationType.DELETE, "$workspacePath/${item.collection}/${item.docId}") {
        val uids = effectiveMemberUids(memberUids)
        val batch = db.batch()
        batch.delete(subCol(item.collection).document(item.docId))
        appendAuditLog(
            batch, uids, "ELIMINAR", item.modulo, item.docId, item.titulo,
            "Eliminación definitiva desde Papelera",
            item.detalle,
            "Eliminado permanentemente"
        )
        batch.commit().await()
    }

    suspend inline fun <T> runMutation(
        op: OperationType,
        path: String,
        crossinline block: suspend () -> T
    ): Result<T> {
        return try {
            Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }
}
