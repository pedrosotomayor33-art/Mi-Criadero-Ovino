package com.example.data

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class CriaderoWorkspace(
    @DocumentId val docId: String = "",
    val nombrePredio: String = "Fundo Santa Elena · Biobío",
    val adminUid: String = "",
    val adminEmail: String = "",
    val socio1Email: String = "",
    val socio2Email: String = "",
    val pendingAdminEmail: String = "",
    val memberUids: List<String> = emptyList(),
    val migratedFromLocal: Boolean = false,
    val migrationVerifiedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CriaderoMember(
    @DocumentId val docId: String = "",
    val uid: String = "",
    val adminUid: String = "",
    val email: String = "",
    val displayName: String = "",
    val etiqueta: String = "Consulta",
    val rol: String = "Consulta",
    val activo: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AuditLogEntry(
    @DocumentId val docId: String = "",
    val memberUids: List<String> = emptyList(),
    val actorUid: String = "",
    val actorEmail: String = "",
    val actorNombre: String = "",
    val actorRol: String = "Administrador",
    val accion: String = "CREAR",
    val modulo: String = "Animales",
    val entidadId: String = "",
    val entidadNombre: String = "",
    val resumen: String = "",
    val valorAnterior: String = "",
    val valorNuevo: String = "",
    val fechaClienteMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "memberUids" to memberUids,
        "actorUid" to actorUid,
        "actorEmail" to actorEmail.take(160),
        "actorNombre" to actorNombre.take(120),
        "actorRol" to actorRol,
        "accion" to accion,
        "modulo" to modulo.take(60),
        "entidadId" to entidadId.take(128),
        "entidadNombre" to entidadNombre.take(200),
        "resumen" to resumen.take(500),
        "valorAnterior" to valorAnterior.take(1000),
        "valorNuevo" to valorNuevo.take(1000),
        "fechaClienteMs" to fechaClienteMs,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class CloudBackupSnapshot(
    @DocumentId val docId: String = "",
    val memberUids: List<String> = emptyList(),
    val nombre: String = "",
    val creadoPorUid: String = "",
    val creadoPorEmail: String = "",
    val fechaMs: Long = 0L,
    val totalRegistros: Long = 0L,
    val resumen: String = "",
    val payloadJson: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "memberUids" to memberUids,
        "nombre" to nombre.take(140),
        "creadoPorUid" to creadoPorUid,
        "creadoPorEmail" to creadoPorEmail.take(160),
        "fechaMs" to fechaMs,
        "totalRegistros" to totalRegistros,
        "resumen" to resumen.take(400),
        "payloadJson" to payloadJson,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

data class DeletedRecordItem(
    val collection: String,
    val modulo: String,
    val docId: String,
    val recordId: Long,
    val titulo: String,
    val detalle: String,
    val eliminadoAt: Long,
    val eliminadoPor: String
)

data class CloudAccessSession(
    val isLoading: Boolean = true,
    val isAuthorized: Boolean = false,
    val isAdmin: Boolean = false,
    val needsInitialSetup: Boolean = false,
    val hasPendingAdminTransfer: Boolean = false,
    val pendingTransferTargetEmail: String = "",
    val criaderoId: String = CloudSchema.DEFAULT_CRIADERO_ID,
    val workspace: CriaderoWorkspace? = null,
    val currentMember: CriaderoMember? = null,
    val statusMessage: String = "",
    val isSyncPendingWrites: Boolean = false,
    val isFromCache: Boolean = false
)

object CloudSchema {
    const val DEFAULT_CRIADERO_ID = "criadero_principal"

    const val COL_CRIADEROS = "criaderos"
    const val SUB_MEMBERS = "members"
    const val SUB_ANIMALES = "animales"
    const val SUB_PESAJES = "pesajes"
    const val SUB_ENCASTES = "encastes"
    const val SUB_GESTACIONES = "gestaciones"
    const val SUB_PARTOS = "partos"
    const val SUB_SANIDAD = "sanidad"
    const val SUB_POTREROS = "potreros"
    const val SUB_MOV_POTRERO = "movimientosPotrero"
    const val SUB_RACIONES = "raciones"
    const val SUB_INVENTARIO = "inventario"
    const val SUB_MOV_INVENTARIO = "movimientosInventario"
    const val SUB_TRANSACCIONES = "transacciones"
    const val SUB_LOTES = "lotes"
    const val SUB_DESTETES = "destetes"
    const val SUB_AUDIT_LOGS = "auditLogs"
    const val SUB_BACKUPS = "backups"
}

// --- DTOs with @Keep, @IgnoreExtraProperties, @DocumentId (never "id"), and nullable @ServerTimestamp ---

@Keep
@IgnoreExtraProperties
data class CloudAnimalDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val arete: String = "",
    val nombre: String = "",
    val photoUri: String? = null,
    val sexo: String = "Hembra",
    val raza: String = "Suffolk Down",
    val fechaNacimiento: Long = 0L,
    val pesoNacimientoKg: Double = 0.0,
    val pesoActualKg: Double = 0.0,
    val madreId: Long? = null,
    val padreId: Long? = null,
    val tipoNacimiento: String = "Único",
    val predioOrigen: String = "Propio",
    val fechaIngreso: Long = 0L,
    val estado: String = "Activo",
    val proposito: String = "Reproducción",
    val potreroId: Long? = null,
    val loteId: Long? = null,
    val prenada: Boolean = false,
    val fechaProbableParto: Long? = null,
    val destetado: Boolean = false,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = AnimalEntity(
        id = recordId,
        arete = arete,
        nombre = nombre,
        photoUri = photoUri,
        sexo = sexo,
        raza = raza,
        fechaNacimiento = fechaNacimiento,
        pesoNacimientoKg = pesoNacimientoKg,
        pesoActualKg = pesoActualKg,
        madreId = madreId,
        padreId = padreId,
        tipoNacimiento = tipoNacimiento,
        predioOrigen = predioOrigen,
        fechaIngreso = fechaIngreso,
        estado = estado,
        proposito = proposito,
        potreroId = potreroId,
        loteId = loteId,
        prenada = prenada,
        fechaProbableParto = fechaProbableParto,
        destetado = destetado,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun AnimalEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "arete" to arete.take(60),
    "nombre" to nombre.take(100),
    "photoUri" to photoUri?.take(500),
    "sexo" to sexo,
    "raza" to raza.take(80),
    "fechaNacimiento" to fechaNacimiento,
    "pesoNacimientoKg" to pesoNacimientoKg,
    "pesoActualKg" to pesoActualKg,
    "madreId" to madreId,
    "padreId" to padreId,
    "tipoNacimiento" to tipoNacimiento.take(40),
    "predioOrigen" to predioOrigen.take(120),
    "fechaIngreso" to fechaIngreso,
    "estado" to estado,
    "proposito" to proposito.take(60),
    "potreroId" to potreroId,
    "loteId" to loteId,
    "prenada" to prenada,
    "fechaProbableParto" to fechaProbableParto,
    "destetado" to destetado,
    "observaciones" to observaciones.take(1000),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Suppress("UNCHECKED_CAST")
fun AnimalEntity.toCloudUpdateMap(memberUids: List<String>): Map<String, Any?> = mapOf(
    "memberUids" to memberUids,
    "arete" to arete.take(60),
    "nombre" to nombre.take(100),
    "photoUri" to (photoUri?.take(500) ?: FieldValue.delete()),
    "sexo" to sexo,
    "raza" to raza.take(80),
    "fechaNacimiento" to fechaNacimiento,
    "pesoNacimientoKg" to pesoNacimientoKg,
    "pesoActualKg" to pesoActualKg,
    "madreId" to (madreId ?: FieldValue.delete()),
    "padreId" to (padreId ?: FieldValue.delete()),
    "tipoNacimiento" to tipoNacimiento.take(40),
    "predioOrigen" to predioOrigen.take(120),
    "fechaIngreso" to fechaIngreso,
    "estado" to estado,
    "proposito" to proposito.take(60),
    "potreroId" to (potreroId ?: FieldValue.delete()),
    "loteId" to (loteId ?: FieldValue.delete()),
    "prenada" to prenada,
    "fechaProbableParto" to (fechaProbableParto ?: FieldValue.delete()),
    "destetado" to destetado,
    "observaciones" to observaciones.take(1000),
    "updatedAt" to FieldValue.serverTimestamp()
)

@Keep
@IgnoreExtraProperties
data class CloudPesajeDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val animalId: Long = 0L,
    val fecha: Long = 0L,
    val pesoKg: Double = 0.0,
    val edadDias: Int = 0,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = PesajeEntity(
        id = recordId,
        animalId = animalId,
        fecha = fecha,
        pesoKg = pesoKg,
        edadDias = edadDias,
        observaciones = observaciones
    )
}

fun PesajeEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "animalId" to animalId,
    "fecha" to fecha,
    "pesoKg" to pesoKg,
    "edadDias" to edadDias,
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
)

@Keep
@IgnoreExtraProperties
data class CloudEncasteDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val fechaInicio: Long = 0L,
    val fechaTermino: Long = 0L,
    val carneroId: Long = 0L,
    val ovejaIdsCsv: String = "",
    val metodo: String = "Monta natural",
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = EncasteEntity(
        id = recordId,
        fechaInicio = fechaInicio,
        fechaTermino = fechaTermino,
        carneroId = carneroId,
        ovejaIdsCsv = ovejaIdsCsv,
        metodo = metodo,
        observaciones = observaciones
    )
}

fun EncasteEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "fechaInicio" to fechaInicio,
    "fechaTermino" to fechaTermino,
    "carneroId" to carneroId,
    "ovejaIdsCsv" to ovejaIdsCsv.take(2000),
    "metodo" to metodo.take(80),
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
)

@Keep
@IgnoreExtraProperties
data class CloudGestacionDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val ovejaId: Long = 0L,
    val carneroId: Long? = null,
    val encasteId: Long? = null,
    val fechaEncaste: Long = 0L,
    val fechaDiagnostico: Long = 0L,
    val estadoGestacion: String = "Preñada",
    val numeroFetos: Int = 1,
    val fechaProbableParto: Long = 0L,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = GestacionEntity(
        id = recordId,
        ovejaId = ovejaId,
        carneroId = carneroId,
        encasteId = encasteId,
        fechaEncaste = fechaEncaste,
        fechaDiagnostico = fechaDiagnostico,
        estadoGestacion = estadoGestacion,
        numeroFetos = numeroFetos,
        fechaProbableParto = fechaProbableParto,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun GestacionEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "ovejaId" to ovejaId,
    "carneroId" to carneroId,
    "encasteId" to encasteId,
    "fechaEncaste" to fechaEncaste,
    "fechaDiagnostico" to fechaDiagnostico,
    "estadoGestacion" to estadoGestacion.take(40),
    "numeroFetos" to numeroFetos,
    "fechaProbableParto" to fechaProbableParto,
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudPartoDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val madreId: Long = 0L,
    val padreId: Long? = null,
    val fechaParto: Long = 0L,
    val cantidadCrias: Int = 1,
    val criasVivas: Int = 1,
    val criasMuertas: Int = 0,
    val tipoParto: String = "Único",
    val asistencia: String = "Normal",
    val detalleCrias: String = "",
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = PartoEntity(
        id = recordId,
        madreId = madreId,
        padreId = padreId,
        fechaParto = fechaParto,
        cantidadCrias = cantidadCrias,
        criasVivas = criasVivas,
        criasMuertas = criasMuertas,
        tipoParto = tipoParto,
        asistencia = asistencia,
        detalleCrias = detalleCrias,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun PartoEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "madreId" to madreId,
    "padreId" to padreId,
    "fechaParto" to fechaParto,
    "cantidadCrias" to cantidadCrias,
    "criasVivas" to criasVivas,
    "criasMuertas" to criasMuertas,
    "tipoParto" to tipoParto.take(40),
    "asistencia" to asistencia.take(40),
    "detalleCrias" to detalleCrias.take(1000),
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudSanidadDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val animalId: Long? = null,
    val loteNombre: String? = null,
    val tipoManejo: String = "Tratamiento",
    val diagnostico: String = "",
    val fecha: Long = 0L,
    val sintomas: String = "",
    val medicamento: String = "",
    val principioActivo: String = "",
    val dosis: Double = 0.0,
    val unidadDosis: String = "ml",
    val viaAdministracion: String = "Subcutánea",
    val duracionDias: Int = 1,
    val fechaProximaDosis: Long? = null,
    val veterinario: String = "",
    val evolucion: String = "En tratamiento",
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = SanidadEntity(
        id = recordId,
        animalId = animalId,
        loteNombre = loteNombre,
        tipoManejo = tipoManejo,
        diagnostico = diagnostico,
        fecha = fecha,
        sintomas = sintomas,
        medicamento = medicamento,
        principioActivo = principioActivo,
        dosis = dosis,
        unidadDosis = unidadDosis,
        viaAdministracion = viaAdministracion,
        duracionDias = duracionDias,
        fechaProximaDosis = fechaProximaDosis,
        veterinario = veterinario,
        evolucion = evolucion,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun SanidadEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "animalId" to animalId,
    "loteNombre" to loteNombre?.take(120),
    "tipoManejo" to tipoManejo.take(80),
    "diagnostico" to diagnostico.take(200),
    "fecha" to fecha,
    "sintomas" to sintomas.take(500),
    "medicamento" to medicamento.take(160),
    "principioActivo" to principioActivo.take(160),
    "dosis" to dosis,
    "unidadDosis" to unidadDosis.take(30),
    "viaAdministracion" to viaAdministracion.take(60),
    "duracionDias" to duracionDias,
    "fechaProximaDosis" to fechaProximaDosis,
    "veterinario" to veterinario.take(120),
    "evolucion" to evolucion.take(60),
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudPotreroDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val nombre: String = "",
    val superficieHa: Double = 1.0,
    val tipoPradera: String = "",
    val disponibilidadForrajeKgMsHa: Double = 0.0,
    val estadoPasto: String = "Óptimo",
    val fechaEntrada: Long? = null,
    val fechaSalida: Long? = null,
    val diasDescansoObjetivo: Int = 30,
    val posicionX: Float = 0.1f,
    val posicionY: Float = 0.1f,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = PotreroEntity(
        id = recordId,
        nombre = nombre,
        superficieHa = superficieHa,
        tipoPradera = tipoPradera,
        disponibilidadForrajeKgMsHa = disponibilidadForrajeKgMsHa,
        estadoPasto = estadoPasto,
        fechaEntrada = fechaEntrada,
        fechaSalida = fechaSalida,
        diasDescansoObjetivo = diasDescansoObjetivo,
        posicionX = posicionX,
        posicionY = posicionY,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun PotreroEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "nombre" to nombre.take(120),
    "superficieHa" to superficieHa,
    "tipoPradera" to tipoPradera.take(120),
    "disponibilidadForrajeKgMsHa" to disponibilidadForrajeKgMsHa,
    "estadoPasto" to estadoPasto.take(60),
    "fechaEntrada" to fechaEntrada,
    "fechaSalida" to fechaSalida,
    "diasDescansoObjetivo" to diasDescansoObjetivo,
    "posicionX" to posicionX.toDouble(),
    "posicionY" to posicionY.toDouble(),
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudMovimientoPotreroDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val potreroOrigenId: Long? = null,
    val potreroDestinoId: Long = 0L,
    val cantidadAnimales: Int = 0,
    val animalIdsCsv: String = "",
    val fechaMovimiento: Long = 0L,
    val motivo: String = "Rotación de pradera",
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = MovimientoPotreroEntity(
        id = recordId,
        potreroOrigenId = potreroOrigenId,
        potreroDestinoId = potreroDestinoId,
        cantidadAnimales = cantidadAnimales,
        animalIdsCsv = animalIdsCsv,
        fechaMovimiento = fechaMovimiento,
        motivo = motivo,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun MovimientoPotreroEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "potreroOrigenId" to potreroOrigenId,
    "potreroDestinoId" to potreroDestinoId,
    "cantidadAnimales" to cantidadAnimales,
    "animalIdsCsv" to animalIdsCsv.take(2000),
    "fechaMovimiento" to fechaMovimiento,
    "motivo" to motivo.take(200),
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudRacionDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val nombre: String = "",
    val tipoAlimento: String = "Avena",
    val ingrediente: String = "",
    val cantidadKg: Double = 0.0,
    val porcentajeInclusion: Double = 0.0,
    val costoPorKgClp: Double = 0.0,
    val cantidadDiariaAnimalKg: Double = 0.0,
    val grupoDestinatario: String = "",
    val cantidadAnimales: Int = 0,
    val stockDisponibleKg: Double = 0.0,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = AlimentoRacionEntity(
        id = recordId,
        nombre = nombre,
        tipoAlimento = tipoAlimento,
        ingrediente = ingrediente,
        cantidadKg = cantidadKg,
        porcentajeInclusion = porcentajeInclusion,
        costoPorKgClp = costoPorKgClp,
        cantidadDiariaAnimalKg = cantidadDiariaAnimalKg,
        grupoDestinatario = grupoDestinatario,
        cantidadAnimales = cantidadAnimales,
        stockDisponibleKg = stockDisponibleKg,
        observaciones = observaciones
    )
}

fun AlimentoRacionEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "nombre" to nombre.take(120),
    "tipoAlimento" to tipoAlimento.take(80),
    "ingrediente" to ingrediente.take(200),
    "cantidadKg" to cantidadKg,
    "porcentajeInclusion" to porcentajeInclusion,
    "costoPorKgClp" to costoPorKgClp,
    "cantidadDiariaAnimalKg" to cantidadDiariaAnimalKg,
    "grupoDestinatario" to grupoDestinatario.take(120),
    "cantidadAnimales" to cantidadAnimales,
    "stockDisponibleKg" to stockDisponibleKg,
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
)

@Keep
@IgnoreExtraProperties
data class CloudInventarioItemDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val nombre: String = "",
    val categoria: String = "",
    val unidad: String = "ml",
    val cantidadDisponible: Double = 0.0,
    val stockMinimo: Double = 0.0,
    val fechaVencimiento: Long? = null,
    val ultimoCostoUnitarioClp: Double = 0.0,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = InventarioItemEntity(
        id = recordId,
        nombre = nombre,
        categoria = categoria,
        unidad = unidad,
        cantidadDisponible = cantidadDisponible,
        stockMinimo = stockMinimo,
        fechaVencimiento = fechaVencimiento,
        ultimoCostoUnitarioClp = ultimoCostoUnitarioClp,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun InventarioItemEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "nombre" to nombre.take(140),
    "categoria" to categoria.take(80),
    "unidad" to unidad.take(40),
    "cantidadDisponible" to cantidadDisponible,
    "stockMinimo" to stockMinimo,
    "fechaVencimiento" to fechaVencimiento,
    "ultimoCostoUnitarioClp" to ultimoCostoUnitarioClp,
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudMovimientoInventarioDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val itemId: Long = 0L,
    val tipo: String = "",
    val cantidad: Double = 0.0,
    val fecha: Long = 0L,
    val costoTotalClp: Double = 0.0,
    val nota: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = MovimientoInventarioEntity(
        id = recordId,
        itemId = itemId,
        tipo = tipo,
        cantidad = cantidad,
        fecha = fecha,
        costoTotalClp = costoTotalClp,
        nota = nota
    )
}

fun MovimientoInventarioEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "itemId" to itemId,
    "tipo" to tipo.take(60),
    "cantidad" to cantidad,
    "fecha" to fecha,
    "costoTotalClp" to costoTotalClp,
    "nota" to nota.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
)

@Keep
@IgnoreExtraProperties
data class CloudTransaccionDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val tipo: String = "Ingreso",
    val categoria: String = "",
    val montoClp: Double = 0.0,
    val fecha: Long = 0L,
    val cantidadKg: Double? = null,
    val animalId: Long? = null,
    val loteId: Long? = null,
    val descripcion: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = TransaccionEconomicaEntity(
        id = recordId,
        tipo = tipo,
        categoria = categoria,
        montoClp = montoClp,
        fecha = fecha,
        cantidadKg = cantidadKg,
        animalId = animalId,
        loteId = loteId,
        descripcion = descripcion
    )
}

@Suppress("UNCHECKED_CAST")
fun TransaccionEconomicaEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "tipo" to tipo,
    "categoria" to categoria.take(100),
    "montoClp" to montoClp,
    "fecha" to fecha,
    "cantidadKg" to cantidadKg,
    "animalId" to animalId,
    "loteId" to loteId,
    "descripcion" to descripcion.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudLoteDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val nombre: String = "",
    val criterio: String = "",
    val objetivoProductivo: String = "",
    val potreroId: Long? = null,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = LoteEntity(
        id = recordId,
        nombre = nombre,
        criterio = criterio,
        objetivoProductivo = objetivoProductivo,
        potreroId = potreroId,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun LoteEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "nombre" to nombre.take(120),
    "criterio" to criterio.take(80),
    "objetivoProductivo" to objetivoProductivo.take(80),
    "potreroId" to potreroId,
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>

@Keep
@IgnoreExtraProperties
data class CloudDesteteDto(
    @DocumentId val docId: String = "",
    val recordId: Long = 0L,
    val memberUids: List<String> = emptyList(),
    val corderoId: Long = 0L,
    val madreId: Long? = null,
    val fecha: Long = 0L,
    val pesoKg: Double = 0.0,
    val tipoDestete: String = "Tradicional",
    val loteDestinoId: Long? = null,
    val observaciones: String = "",
    val registroActivo: Boolean = true,
    val eliminadoAt: Long? = null,
    val eliminadoPor: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toEntity() = DesteteEntity(
        id = recordId,
        corderoId = corderoId,
        madreId = madreId,
        fecha = fecha,
        pesoKg = pesoKg,
        tipoDestete = tipoDestete,
        loteDestinoId = loteDestinoId,
        observaciones = observaciones
    )
}

@Suppress("UNCHECKED_CAST")
fun DesteteEntity.toCloudCreateMap(memberUids: List<String>): Map<String, Any> = mapOf(
    "recordId" to id,
    "memberUids" to memberUids,
    "corderoId" to corderoId,
    "madreId" to madreId,
    "fecha" to fecha,
    "pesoKg" to pesoKg,
    "tipoDestete" to tipoDestete.take(60),
    "loteDestinoId" to loteDestinoId,
    "observaciones" to observaciones.take(500),
    "registroActivo" to true,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
).filterValues { it != null } as Map<String, Any>
