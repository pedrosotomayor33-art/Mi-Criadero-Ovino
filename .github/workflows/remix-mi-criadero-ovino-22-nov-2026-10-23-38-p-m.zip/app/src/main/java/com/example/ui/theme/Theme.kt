package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = ForestGreen,
    onPrimary = Color.White,
    primaryContainer = SoftMint,
    onPrimaryContainer = ForestGreenDark,
    secondary = MeadowGreen,
    onSecondary = Color.White,
    secondaryContainer = PalePasture,
    onSecondaryContainer = ForestGreen,
    tertiary = EarthTerracotta,
    onTertiary = Color.White,
    tertiaryContainer = TerracottaSoft,
    onTertiaryContainer = SaddleBrown,
    background = WoolCream,
    onBackground = SlateInk,
    surface = WoolCream,
    onSurface = SlateInk,
    surfaceVariant = WarmLinen,
    onSurfaceVariant = MutedMoss,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = WoolCream,
    surfaceContainer = WarmLinen,
    surfaceContainerHigh = SoftStone,
    outline = Color(0xFFB5BEB8),
    outlineVariant = Color(0xFFDCE2DE),
    error = CrimsonAlert,
    onError = Color.White,
    errorContainer = CrimsonSoft,
    onErrorContainer = Color(0xFF7F1D1D)
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkFreshLeaf,
    onPrimary = ForestGreenDark,
    primaryContainer = MeadowGreen,
    onPrimaryContainer = SoftMint,
    secondary = FreshGrass,
    onSecondary = ForestGreenDark,
    secondaryContainer = DarkForestSurfaceHigh,
    onSecondaryContainer = DarkCreamText,
    tertiary = DarkWarmSand,
    onTertiary = SaddleBrown,
    tertiaryContainer = Color(0xFF4A2E14),
    onTertiaryContainer = TerracottaSoft,
    background = DarkForestBg,
    onBackground = DarkCreamText,
    surface = DarkForestBg,
    onSurface = DarkCreamText,
    surfaceVariant = DarkForestSurface,
    onSurfaceVariant = Color(0xFFA7BDB0),
    surfaceContainerLowest = Color(0xFF0A120E),
    surfaceContainerLow = DarkForestSurface,
    surfaceContainer = DarkForestSurface,
    surfaceContainerHigh = DarkForestSurfaceHigh,
    outline = Color(0xFF3E5649),
    outlineVariant = Color(0xFF283C31),
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = CrimsonSoft
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MiCriaderoOvinoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
