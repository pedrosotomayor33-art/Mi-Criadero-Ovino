package com.example.data

import kotlinx.coroutines.flow.first

object DatabaseSeeder {
    private const val DAY_MS = 86_400_000L

    suspend fun seedIfEmpty(dao: CriaderoDao) {
        if (dao.observeUsuarios().first().isEmpty()) {
            dao.insertUsuario(
                UserAccountEntity(
                    nombre = "Administrador Principal",
                    rol = "Administrador",
                    etiqueta = "Administrador"
                )
            )
            dao.insertUsuario(
                UserAccountEntity(
                    nombre = "Socio 1 (Consulta)",
                    rol = "Consulta",
                    etiqueta = "Socio 1"
                )
            )
            dao.insertUsuario(
                UserAccountEntity(
                    nombre = "Socio 2 (Consulta)",
                    rol = "Consulta",
                    etiqueta = "Socio 2"
                )
            )
        }

        if (dao.observeAnimales().first().isNotEmpty()) return

        val now = System.currentTimeMillis()

        // Potreros
        val potreroNorteId = dao.insertPotrero(
            PotreroEntity(
                nombre = "Potrero 1 - Vega Norte",
                superficieHa = 4.5,
                tipoPradera = "Ballica + Trébol blanco",
                disponibilidadForrajeKgMsHa = 2450.0,
                estadoPasto = "En uso",
                fechaEntrada = now - 14 * DAY_MS,
                diasDescansoObjetivo = 30,
                posicionX = 0.08f,
                posicionY = 0.12f,
                observaciones = "Pradera irrigada con bebedero automático"
            )
        )
        val potreroSurId = dao.insertPotrero(
            PotreroEntity(
                nombre = "Potrero 2 - Loma Sur",
                superficieHa = 6.0,
                tipoPradera = "Festuca + Trébol subterráneo",
                disponibilidadForrajeKgMsHa = 1950.0,
                estadoPasto = "En uso",
                fechaEntrada = now - 8 * DAY_MS,
                diasDescansoObjetivo = 35,
                posicionX = 0.54f,
                posicionY = 0.12f,
                observaciones = "Sector de corderos en engorda y reemplazo"
            )
        )
        val potreroDescansoId = dao.insertPotrero(
            PotreroEntity(
                nombre = "Potrero 3 - El Roble",
                superficieHa = 3.8,
                tipoPradera = "Alfalfa + Avena forrajera",
                disponibilidadForrajeKgMsHa = 2900.0,
                estadoPasto = "En descanso",
                fechaSalida = now - 29 * DAY_MS,
                diasDescansoObjetivo = 30,
                posicionX = 0.08f,
                posicionY = 0.56f,
                observaciones = "Casi listo para pastoreo (1 día para cumplir descanso)"
            )
        )
        dao.insertPotrero(
            PotreroEntity(
                nombre = "Potrero 4 - Maternidad",
                superficieHa = 2.2,
                tipoPradera = "Ballica perenne protegida",
                disponibilidadForrajeKgMsHa = 2700.0,
                estadoPasto = "Óptimo",
                fechaSalida = now - 38 * DAY_MS,
                diasDescansoObjetivo = 28,
                posicionX = 0.54f,
                posicionY = 0.56f,
                observaciones = "Cercado con malla ovejera para parición"
            )
        )

        // Lotes
        val loteMadresId = dao.insertLote(
            LoteEntity(
                nombre = "Lote Reproductoras",
                criterio = "Objetivo productivo",
                objetivoProductivo = "Reproducción",
                potreroId = potreroNorteId,
                observaciones = "Ovejas adultas encastadas temporada actual"
            )
        )
        val loteEngordaId = dao.insertLote(
            LoteEntity(
                nombre = "Lote Engorda Primavera",
                criterio = "Objetivo productivo",
                objetivoProductivo = "Engorda",
                potreroId = potreroSurId,
                observaciones = "Corderos destetados objetivo 42 kg"
            )
        )

        // Animales base (Reproductores y madres)
        val carnero1Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-001",
                nombre = "Araucano",
                sexo = "Macho",
                raza = "Suffolk Down",
                fechaNacimiento = now - 1100 * DAY_MS,
                pesoNacimientoKg = 4.9,
                pesoActualKg = 94.5,
                tipoNacimiento = "Único",
                predioOrigen = "Criadero Los Robles (Temuco)",
                fechaIngreso = now - 730 * DAY_MS,
                estado = "Activo",
                proposito = "Reproducción",
                potreroId = potreroNorteId,
                loteId = loteMadresId,
                destetado = true,
                observaciones = "Carnero jefe de plantel, excelente conformación cárnica"
            )
        )
        val carnero2Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-002",
                nombre = "Lonquimay",
                sexo = "Macho",
                raza = "Texel",
                fechaNacimiento = now - 920 * DAY_MS,
                pesoNacimientoKg = 4.6,
                pesoActualKg = 88.0,
                tipoNacimiento = "Mellizo",
                predioOrigen = "Fundo Las Vertientes",
                fechaIngreso = now - 540 * DAY_MS,
                estado = "Activo",
                proposito = "Reproducción",
                potreroId = potreroSurId,
                destetado = true,
                observaciones = "Carnero Texel para cruce terminal"
            )
        )
        val oveja1Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-101",
                nombre = "Estrella",
                sexo = "Hembra",
                raza = "Suffolk Down",
                fechaNacimiento = now - 1250 * DAY_MS,
                pesoNacimientoKg = 4.2,
                pesoActualKg = 72.4,
                tipoNacimiento = "Mellizo",
                predioOrigen = "Propio",
                fechaIngreso = now - 1250 * DAY_MS,
                estado = "Activo",
                proposito = "Reproducción",
                potreroId = potreroNorteId,
                loteId = loteMadresId,
                prenada = true,
                fechaProbableParto = now + 10 * DAY_MS,
                destetado = true,
                observaciones = "Excelente habilidad materna, mellicera"
            )
        )
        val oveja2Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-102",
                nombre = "Canela",
                sexo = "Hembra",
                raza = "Corriedale",
                fechaNacimiento = now - 1020 * DAY_MS,
                pesoNacimientoKg = 4.0,
                pesoActualKg = 68.0,
                tipoNacimiento = "Único",
                predioOrigen = "Propio",
                fechaIngreso = now - 1020 * DAY_MS,
                estado = "Activo",
                proposito = "Reproducción",
                potreroId = potreroNorteId,
                loteId = loteMadresId,
                prenada = true,
                fechaProbableParto = now + 24 * DAY_MS,
                destetado = true,
                observaciones = "Vellón parejo, gestación simple confirmada"
            )
        )
        val oveja3Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-103",
                nombre = "Niebla",
                sexo = "Hembra",
                raza = "Suffolk Down",
                fechaNacimiento = now - 820 * DAY_MS,
                pesoNacimientoKg = 4.1,
                pesoActualKg = 66.2,
                madreId = oveja1Id,
                tipoNacimiento = "Único",
                predioOrigen = "Propio",
                fechaIngreso = now - 820 * DAY_MS,
                estado = "Activo",
                proposito = "Reproducción",
                potreroId = potreroNorteId,
                loteId = loteMadresId,
                prenada = false,
                destetado = true,
                observaciones = "Hija de Estrella (CL-101), borrega primeriza"
            )
        )
        val oveja4Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-104",
                nombre = "Brisa",
                sexo = "Hembra",
                raza = "Chilota",
                fechaNacimiento = now - 980 * DAY_MS,
                pesoNacimientoKg = 3.6,
                pesoActualKg = 59.5,
                tipoNacimiento = "Mellizo",
                predioOrigen = "Chiloé",
                fechaIngreso = now - 600 * DAY_MS,
                estado = "Activo",
                proposito = "Reproducción",
                potreroId = potreroNorteId,
                loteId = loteMadresId,
                prenada = false,
                destetado = true,
                observaciones = "Rústica, gran resistencia podal"
            )
        )

        // Corderos / Engorda / Reemplazo
        val cordero1Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-201",
                nombre = "Relámpago",
                sexo = "Macho",
                raza = "Suffolk Down",
                fechaNacimiento = now - 110 * DAY_MS,
                pesoNacimientoKg = 4.4,
                pesoActualKg = 34.8,
                madreId = oveja1Id,
                padreId = carnero1Id,
                tipoNacimiento = "Mellizo",
                predioOrigen = "Propio",
                fechaIngreso = now - 110 * DAY_MS,
                estado = "Activo",
                proposito = "Engorda",
                potreroId = potreroSurId,
                loteId = loteEngordaId,
                destetado = true,
                observaciones = "Muy buena ganancia diaria en pradera"
            )
        )
        val cordero2Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-202",
                nombre = "Alba",
                sexo = "Hembra",
                raza = "Suffolk Down",
                fechaNacimiento = now - 110 * DAY_MS,
                pesoNacimientoKg = 4.0,
                pesoActualKg = 31.6,
                madreId = oveja1Id,
                padreId = carnero1Id,
                tipoNacimiento = "Mellizo",
                predioOrigen = "Propio",
                fechaIngreso = now - 110 * DAY_MS,
                estado = "Activo",
                proposito = "Reemplazo",
                potreroId = potreroSurId,
                loteId = loteEngordaId,
                destetado = true,
                observaciones = "Preseleccionada para reposición del plantel"
            )
        )
        val cordero3Id = dao.insertAnimal(
            AnimalEntity(
                arete = "CL-203",
                nombre = "Copihue",
                sexo = "Macho",
                raza = "Texel x Corriedale",
                fechaNacimiento = now - 75 * DAY_MS,
                pesoNacimientoKg = 4.5,
                pesoActualKg = 24.5,
                madreId = oveja2Id,
                padreId = carnero2Id,
                tipoNacimiento = "Único",
                predioOrigen = "Propio",
                fechaIngreso = now - 75 * DAY_MS,
                estado = "Activo",
                proposito = "Engorda",
                potreroId = potreroSurId,
                loteId = loteEngordaId,
                destetado = false,
                observaciones = "Cordero al pie próximo a destete"
            )
        )

        // Pesajes históricos para gráficos y GMD real
        listOf(
            PesajeEntity(animalId = cordero1Id, fecha = now - 110 * DAY_MS, pesoKg = 4.4, edadDias = 0, observaciones = "Peso al nacer"),
            PesajeEntity(animalId = cordero1Id, fecha = now - 80 * DAY_MS, pesoKg = 12.6, edadDias = 30, observaciones = "Control 30 días"),
            PesajeEntity(animalId = cordero1Id, fecha = now - 50 * DAY_MS, pesoKg = 21.4, edadDias = 60, observaciones = "Pre-destete"),
            PesajeEntity(animalId = cordero1Id, fecha = now - 20 * DAY_MS, pesoKg = 29.5, edadDias = 90, observaciones = "Control destete"),
            PesajeEntity(animalId = cordero1Id, fecha = now - 2 * DAY_MS, pesoKg = 34.8, edadDias = 108, observaciones = "Control engorda"),

            PesajeEntity(animalId = cordero2Id, fecha = now - 110 * DAY_MS, pesoKg = 4.0, edadDias = 0, observaciones = "Peso al nacer"),
            PesajeEntity(animalId = cordero2Id, fecha = now - 80 * DAY_MS, pesoKg = 11.4, edadDias = 30, observaciones = "Control 30 días"),
            PesajeEntity(animalId = cordero2Id, fecha = now - 50 * DAY_MS, pesoKg = 19.2, edadDias = 60, observaciones = "Pre-destete"),
            PesajeEntity(animalId = cordero2Id, fecha = now - 20 * DAY_MS, pesoKg = 26.8, edadDias = 90, observaciones = "Control destete"),
            PesajeEntity(animalId = cordero2Id, fecha = now - 2 * DAY_MS, pesoKg = 31.6, edadDias = 108, observaciones = "Control reemplazo"),

            PesajeEntity(animalId = cordero3Id, fecha = now - 75 * DAY_MS, pesoKg = 4.5, edadDias = 0, observaciones = "Peso al nacer"),
            PesajeEntity(animalId = cordero3Id, fecha = now - 45 * DAY_MS, pesoKg = 13.8, edadDias = 30, observaciones = "Control mensual"),
            PesajeEntity(animalId = cordero3Id, fecha = now - 10 * DAY_MS, pesoKg = 22.1, edadDias = 65, observaciones = "Control desarrollo"),
            PesajeEntity(animalId = cordero3Id, fecha = now - 1 * DAY_MS, pesoKg = 24.5, edadDias = 74, observaciones = "Último control"),

            PesajeEntity(animalId = oveja1Id, fecha = now - 60 * DAY_MS, pesoKg = 67.0, edadDias = 1190, observaciones = "Inicio último tercio"),
            PesajeEntity(animalId = oveja1Id, fecha = now - 5 * DAY_MS, pesoKg = 72.4, edadDias = 1245, observaciones = "Control preparto")
        ).forEach { dao.insertPesaje(it) }

        // Encaste y Gestaciones
        val encasteId = dao.insertEncaste(
            EncasteEntity(
                fechaInicio = now - 140 * DAY_MS,
                fechaTermino = now - 105 * DAY_MS,
                carneroId = carnero1Id,
                ovejaIdsCsv = "$oveja1Id,$oveja2Id",
                metodo = "Monta natural",
                observaciones = "Encaste otoño con flushing previo"
            )
        )

        dao.insertGestacion(
            GestacionEntity(
                ovejaId = oveja1Id,
                carneroId = carnero1Id,
                encasteId = encasteId,
                fechaEncaste = now - 137 * DAY_MS,
                fechaDiagnostico = now - 85 * DAY_MS,
                estadoGestacion = "Preñada",
                numeroFetos = 2,
                fechaProbableParto = now + 10 * DAY_MS,
                observaciones = "Ecografía confirma gestación gemelar"
            )
        )
        dao.insertGestacion(
            GestacionEntity(
                ovejaId = oveja2Id,
                carneroId = carnero2Id,
                encasteId = encasteId,
                fechaEncaste = now - 123 * DAY_MS,
                fechaDiagnostico = now - 72 * DAY_MS,
                estadoGestacion = "Preñada",
                numeroFetos = 1,
                fechaProbableParto = now + 24 * DAY_MS,
                observaciones = "Gestación simple de buen desarrollo"
            )
        )

        // Partos del año
        dao.insertParto(
            PartoEntity(
                madreId = oveja1Id,
                padreId = carnero1Id,
                fechaParto = now - 110 * DAY_MS,
                cantidadCrias = 2,
                criasVivas = 2,
                criasMuertas = 0,
                tipoParto = "Mellizo",
                asistencia = "Normal",
                detalleCrias = "CL-201 Macho 4,4 kg (Vivo); CL-202 Hembra 4,0 kg (Viva)",
                observaciones = "Parto sin complicaciones, buen calostro"
            )
        )
        dao.insertParto(
            PartoEntity(
                madreId = oveja2Id,
                padreId = carnero2Id,
                fechaParto = now - 75 * DAY_MS,
                cantidadCrias = 1,
                criasVivas = 1,
                criasMuertas = 0,
                tipoParto = "Único",
                asistencia = "Normal",
                detalleCrias = "CL-203 Macho 4,5 kg (Vivo)",
                observaciones = "Cordero vigoroso"
            )
        )

        // Destetes
        dao.insertDestete(
            DesteteEntity(
                corderoId = cordero1Id,
                madreId = oveja1Id,
                fecha = now - 20 * DAY_MS,
                pesoKg = 29.5,
                tipoDestete = "Tradicional",
                loteDestinoId = loteEngordaId,
                observaciones = "Destete a los 90 días con excelente peso"
            )
        )
        dao.insertDestete(
            DesteteEntity(
                corderoId = cordero2Id,
                madreId = oveja1Id,
                fecha = now - 20 * DAY_MS,
                pesoKg = 26.8,
                tipoDestete = "Tradicional",
                loteDestinoId = loteEngordaId,
                observaciones = "Destetada junto a su mellizo"
            )
        )

        // Sanidad y calendario
        dao.insertSanidad(
            SanidadEntity(
                animalId = oveja4Id,
                tipoManejo = "Tratamiento",
                diagnostico = "Pododermatitis leve (Pietín)",
                fecha = now - 3 * DAY_MS,
                sintomas = "Claudicación leve en extremidad posterior derecha",
                medicamento = "Oxitetraciclina LA 20%",
                principioActivo = "Oxitetraciclina",
                dosis = 6.0,
                unidadDosis = "ml",
                viaAdministracion = "Intramuscular",
                duracionDias = 5,
                fechaProximaDosis = now, // Hoy!
                veterinario = "Dr. Rodrigo Fuentes",
                evolucion = "En tratamiento",
                observaciones = "Aplicar refuerzo y baño podal con sulfato de zinc"
            )
        )
        dao.insertSanidad(
            SanidadEntity(
                loteNombre = "Lote Reproductoras",
                tipoManejo = "Vacunación",
                diagnostico = "Prevención Clostridiosis preparto",
                fecha = now - 15 * DAY_MS,
                medicamento = "Vacuna Polivalente 8 Cepas",
                principioActivo = "Toxoide clostridial",
                dosis = 2.0,
                unidadDosis = "ml",
                viaAdministracion = "Subcutánea",
                duracionDias = 1,
                fechaProximaDosis = now + 3 * DAY_MS,
                veterinario = "Dr. Rodrigo Fuentes",
                evolucion = "Programado",
                observaciones = "Refuerzo preparto ovejas en gestación avanzada"
            )
        )
        dao.insertSanidad(
            SanidadEntity(
                loteNombre = "Lote Engorda Primavera",
                tipoManejo = "Desparasitación",
                diagnostico = "Control parasitosis gastrointestinal",
                fecha = now - 25 * DAY_MS,
                medicamento = "Ivermectina + Triclabendazol",
                principioActivo = "Ivermectina 0,2% / Triclabendazol",
                dosis = 5.0,
                unidadDosis = "ml",
                viaAdministracion = "Oral",
                duracionDias = 1,
                fechaProximaDosis = now + 5 * DAY_MS,
                veterinario = "Dr. Rodrigo Fuentes",
                evolucion = "Programado",
                observaciones = "Rotación de antiparasitario primavera"
            )
        )

        // Alimentación y Raciones
        dao.insertRacion(
            AlimentoRacionEntity(
                nombre = "Ración Preparto Melliceras",
                tipoAlimento = "Avena",
                ingrediente = "Avena chancada + Heno de alfalfa",
                cantidadKg = 350.0,
                porcentajeInclusion = 65.0,
                costoPorKgClp = 280.0,
                cantidadDiariaAnimalKg = 0.65,
                grupoDestinatario = "Ovejas preñadas",
                cantidadAnimales = 2,
                stockDisponibleKg = 320.0,
                observaciones = "Suplementación energética último tercio de gestación"
            )
        )
        dao.insertRacion(
            AlimentoRacionEntity(
                nombre = "Ración Terminación Corderos",
                tipoAlimento = "Concentrado",
                ingrediente = "Maíz molido + Afrecho de raps + Sales minerales",
                cantidadKg = 500.0,
                porcentajeInclusion = 40.0,
                costoPorKgClp = 360.0,
                cantidadDiariaAnimalKg = 0.45,
                grupoDestinatario = "Corderos engorda",
                cantidadAnimales = 3,
                stockDisponibleKg = 440.0,
                observaciones = "Apoyo para alcanzar 42 kg de peso vivo"
            )
        )

        // Inventario
        dao.insertInventarioItem(
            InventarioItemEntity(
                nombre = "Vacuna Clostridial 8 Cepas (250 ml)",
                categoria = "Vacunas",
                unidad = "dosis",
                cantidadDisponible = 45.0,
                stockMinimo = 20.0,
                fechaVencimiento = now + 180 * DAY_MS,
                ultimoCostoUnitarioClp = 850.0,
                observaciones = "Conservar refrigerada entre 2°C y 8°C"
            )
        )
        dao.insertInventarioItem(
            InventarioItemEntity(
                nombre = "Ivermectina Oral Ovina 1 L",
                categoria = "Antiparasitarios",
                unidad = "ml",
                cantidadDisponible = 180.0,
                stockMinimo = 250.0, // Stock bajo para alerta!
                fechaVencimiento = now + 120 * DAY_MS,
                ultimoCostoUnitarioClp = 35.0,
                observaciones = "Stock bajo: reponer antes de desparasitación de lote"
            )
        )
        dao.insertInventarioItem(
            InventarioItemEntity(
                nombre = "Fardos Heno de Alfalfa 22 kg",
                categoria = "Fardos",
                unidad = "fardos",
                cantidadDisponible = 68.0,
                stockMinimo = 20.0,
                ultimoCostoUnitarioClp = 6500.0,
                observaciones = "Galpón sector sur"
            )
        )
        dao.insertInventarioItem(
            InventarioItemEntity(
                nombre = "Sales Minerales Ovinas Bloque",
                categoria = "Minerales",
                unidad = "kg",
                cantidadDisponible = 50.0,
                stockMinimo = 15.0,
                ultimoCostoUnitarioClp = 1400.0,
                observaciones = "Con selenio y zinc"
            )
        )

        // Movimientos de potrero
        dao.insertMovimientoPotrero(
            MovimientoPotreroEntity(
                potreroOrigenId = potreroDescansoId,
                potreroDestinoId = potreroNorteId,
                cantidadAnimales = 5,
                animalIdsCsv = "$carnero1Id,$oveja1Id,$oveja2Id,$oveja3Id,$oveja4Id",
                fechaMovimiento = now - 14 * DAY_MS,
                motivo = "Rotación por disponibilidad de forraje",
                observaciones = "Salida de Potrero 3 para iniciar descanso de 30 días"
            )
        )

        // Economía (CLP)
        listOf(
            TransaccionEconomicaEntity(
                tipo = "Ingreso",
                categoria = "Venta de corderos",
                montoClp = 1_480_000.0,
                fecha = now - 45 * DAY_MS,
                cantidadKg = 420.0,
                descripcion = "Venta 10 corderos gordos 42 kg promedio (feria Los Ángeles)"
            ),
            TransaccionEconomicaEntity(
                tipo = "Ingreso",
                categoria = "Venta de lana",
                montoClp = 320_000.0,
                fecha = now - 20 * DAY_MS,
                cantidadKg = 145.0,
                descripcion = "Esquila temporada - 145 kg vellón Corriedale/Suffolk"
            ),
            TransaccionEconomicaEntity(
                tipo = "Gasto",
                categoria = "Alimentación",
                montoClp = 442_000.0,
                fecha = now - 35 * DAY_MS,
                descripcion = "Compra de 68 fardos alfalfa y avena forrajera"
            ),
            TransaccionEconomicaEntity(
                tipo = "Gasto",
                categoria = "Medicamentos",
                montoClp = 115_000.0,
                fecha = now - 18 * DAY_MS,
                descripcion = "Antiparasitarios, antibiótico LA y minerales"
            ),
            TransaccionEconomicaEntity(
                tipo = "Gasto",
                categoria = "Mantención",
                montoClp = 95_000.0,
                fecha = now - 10 * DAY_MS,
                descripcion = "Reparación cerco eléctrico y bebedero Potrero 1"
            )
        ).forEach { dao.insertTransaccion(it) }
    }
}
