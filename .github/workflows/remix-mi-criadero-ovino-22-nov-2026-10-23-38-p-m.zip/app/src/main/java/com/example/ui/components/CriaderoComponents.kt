package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.AnimalEntity
import com.example.data.PartoEntity
import com.example.data.PesajeEntity
import com.example.data.PotreroEntity
import com.example.data.UserAccountEntity
import com.example.ui.theme.*
import com.example.util.ChileanFormatters
import java.io.File
import java.util.Calendar
import kotlin.math.max

@Composable
fun BrandTopBar(
    predioNombre: String,
    activeUser: UserAccountEntity?,
    alertCount: Int,
    onSwitchUserClick: () -> Unit,
    onAlertsClick: () -> Unit,
    isOnline: Boolean = true,
    isSyncPendingWrites: Boolean = false
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(
                        WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)
                    )
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_sheep_logo),
                    contentDescription = "Logotipo de Mi Criadero Ovino",
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "MI CRIADERO OVINO",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    val syncLabel = when {
                        !isOnline -> "$predioNombre · Sin señal (caché)"
                        isSyncPendingWrites -> "$predioNombre · Sincronizando..."
                        else -> "$predioNombre · En vivo"
                    }
                    Text(
                        text = syncLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (!isOnline) EarthTerracotta else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Alertas badge button
                IconButton(
                    onClick = onAlertsClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("top_alerts_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (alertCount > 0) {
                                Badge(containerColor = EarthTerracotta, contentColor = Color.White) {
                                    Text("$alertCount")
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.NotificationsActive,
                            contentDescription = "Ver alertas y calendario",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Role chip
                val isAdmin = activeUser?.rol == "Administrador"
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isAdmin) MaterialTheme.colorScheme.primaryContainer else AmberSoft,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onSwitchUserClick() }
                        .testTag("role_switcher_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isAdmin) Icons.Filled.AdminPanelSettings else Icons.Filled.Visibility,
                            contentDescription = "Cuenta y estado de sesión",
                            modifier = Modifier.size(16.dp),
                            tint = if (isAdmin) MaterialTheme.colorScheme.onPrimaryContainer else SaddleBrown
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = activeUser?.etiqueta ?: "Admin",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isAdmin) MaterialTheme.colorScheme.onPrimaryContainer else SaddleBrown,
                            maxLines = 1
                        )
                    }
                }
            }

            if (activeUser != null && activeUser.rol != "Administrador") {
                Surface(
                    color = AmberSoft,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Lock,
                            contentDescription = null,
                            tint = SaddleBrown,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${activeUser.etiqueta}: acceso solo lectura (consulta sin edición)",
                            style = MaterialTheme.typography.labelSmall,
                            color = SaddleBrown,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KpiMetricCard(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: ImageVector,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
        ),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = accentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun QuickActionCardButton(
    label: String,
    icon: ImageVector,
    tint: Color,
    enabled: Boolean = true,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(MaterialTheme.shapes.medium)
            .clickable(enabled = enabled, onClick = onClick)
            .testTag(testTag),
        shape = MaterialTheme.shapes.medium,
        color = if (enabled) tint.copy(alpha = 0.11f) else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, if (enabled) tint.copy(alpha = 0.28f) else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (enabled) tint else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun AnimalAvatar(
    animal: AnimalEntity,
    sizeDp: Int = 48
) {
    val photoFile = animal.photoUri?.let { File(it) }?.takeIf { it.exists() }
    val bgTint = if (animal.sexo == "Macho") SkySoft else TerracottaSoft
    val fgTint = if (animal.sexo == "Macho") SkyInfo else EarthTerracotta

    if (photoFile != null) {
        AsyncImage(
            model = photoFile,
            contentDescription = "Foto de ${animal.arete}",
            modifier = Modifier
                .size(sizeDp.dp)
                .clip(CircleShape)
                .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), CircleShape),
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            modifier = Modifier
                .size(sizeDp.dp)
                .clip(CircleShape)
                .background(bgTint)
                .border(1.dp, fgTint.copy(alpha = 0.35f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = animal.arete.takeLast(3).ifBlank { "OV" },
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = fgTint
            )
        }
    }
}

@Composable
fun WeightEvolutionChart(
    series: List<Pair<String, List<PesajeEntity>>>,
    modifier: Modifier = Modifier
) {
    val palette = listOf(ForestGreen, EarthTerracotta, SkyInfo, HarvestAmber, PastureGreen)
    val nonEmpty = series.filter { it.second.isNotEmpty() }

    Column(modifier = modifier) {
        if (nonEmpty.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Registre al menos un pesaje para visualizar la curva de crecimiento.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            return
        }

        val allWeights = nonEmpty.flatMap { it.second }.map { it.pesoKg }
        val allDates = nonEmpty.flatMap { it.second }.map { it.fecha }
        val minW = ((allWeights.minOrNull() ?: 0.0) - 2.0).coerceAtLeast(0.0)
        val maxW = (allWeights.maxOrNull() ?: 50.0) + 2.0
        val wRange = max(1.0, maxW - minW)
        val minD = allDates.minOrNull() ?: 0L
        val maxD = allDates.maxOrNull() ?: 1L
        val dRange = max(1L, maxD - minD).toDouble()

        val gridColor = MaterialTheme.colorScheme.outlineVariant

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            val padLeft = 14f
            val padBottom = 14f
            val chartW = size.width - padLeft * 2
            val chartH = size.height - padBottom * 2

            // Líneas de referencia horizontal
            for (i in 0..3) {
                val y = padBottom + chartH * (i / 3f)
                drawLine(
                    color = gridColor,
                    start = Offset(padLeft, y),
                    end = Offset(size.width - padLeft, y),
                    strokeWidth = 1.5f
                )
            }

            nonEmpty.forEachIndexed { idx, (_, points) ->
                val color = palette[idx % palette.size]
                val sorted = points.sortedBy { it.fecha }
                val path = Path()
                val offsets = sorted.map { p ->
                    val xRatio = if (sorted.size == 1 && dRange <= 1.0) 0.5f
                    else ((p.fecha - minD) / dRange).toFloat()
                    val yRatio = ((p.pesoKg - minW) / wRange).toFloat()
                    Offset(
                        x = padLeft + xRatio * chartW,
                        y = padBottom + chartH - (yRatio * chartH)
                    )
                }
                offsets.forEachIndexed { i, pt ->
                    if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
                }
                if (offsets.size >= 2) {
                    drawPath(
                        path = path,
                        color = color,
                        style = Stroke(width = 5f, cap = StrokeCap.Round)
                    )
                }
                offsets.forEach { pt ->
                    drawCircle(color = Color.White, radius = 8f, center = pt)
                    drawCircle(color = color, radius = 5.5f, center = pt)
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Mín: ${ChileanFormatters.formatKg(allWeights.minOrNull() ?: 0.0)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Máx: ${ChileanFormatters.formatKg(allWeights.maxOrNull() ?: 0.0)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Leyenda
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            nonEmpty.take(4).forEachIndexed { idx, (label, _) ->
                val color = palette[idx % palette.size]
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(color)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun BirthsMortalityChart(
    partos: List<PartoEntity>,
    animales: List<AnimalEntity>,
    modifier: Modifier = Modifier
) {
    val months = remember(partos, animales) {
        val cal = Calendar.getInstance()
        val labels = listOf("Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic")
        val currentMonth = cal.get(Calendar.MONTH)
        val result = mutableListOf<Triple<String, Int, Int>>()
        for (offset in 5 downTo 0) {
            val c = Calendar.getInstance().apply { add(Calendar.MONTH, -offset) }
            val m = c.get(Calendar.MONTH)
            val y = c.get(Calendar.YEAR)
            val births = partos.filter {
                val pc = Calendar.getInstance().apply { timeInMillis = it.fechaParto }
                pc.get(Calendar.MONTH) == m && pc.get(Calendar.YEAR) == y
            }.sumOf { it.criasVivas }
            val deaths = partos.filter {
                val pc = Calendar.getInstance().apply { timeInMillis = it.fechaParto }
                pc.get(Calendar.MONTH) == m && pc.get(Calendar.YEAR) == y
            }.sumOf { it.criasMuertas } + animales.count {
                if (it.estado != "Muerte") false else {
                    val ac = Calendar.getInstance().apply { timeInMillis = it.fechaIngreso }
                    ac.get(Calendar.MONTH) == m && ac.get(Calendar.YEAR) == y
                }
            }
            result += Triple(labels[m], births, deaths)
        }
        if (currentMonth >= 0) result else emptyList()
    }

    val maxVal = max(1, months.maxOfOrNull { max(it.second, it.third) } ?: 1)

    Column(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            val groupW = size.width / months.size.coerceAtLeast(1)
            val barW = (groupW * 0.26f).coerceAtMost(24f)
            val h = size.height - 10f

            months.forEachIndexed { idx, (_, births, deaths) ->
                val center = idx * groupW + groupW / 2f
                val bHeight = (births.toFloat() / maxVal) * h
                val dHeight = (deaths.toFloat() / maxVal) * h

                drawRoundRect(
                    color = FreshGrass,
                    topLeft = Offset(center - barW - 3f, h - bHeight),
                    size = Size(barW, max(4f, bHeight)),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = CrimsonAlert,
                    topLeft = Offset(center + 3f, h - dHeight),
                    size = Size(barW, max(4f, dHeight)),
                    cornerRadius = CornerRadius(6f, 6f)
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            months.forEach { (label, b, d) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(label, style = MaterialTheme.typography.labelSmall)
                    Text(
                        text = "$b/$d",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(FreshGrass))
                Spacer(Modifier.width(4.dp))
                Text("Nacimientos vivos", style = MaterialTheme.typography.labelSmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(CrimsonAlert))
                Spacer(Modifier.width(4.dp))
                Text("Mortalidad", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun PastureSchematicMap(
    potreros: List<PotreroEntity>,
    animalesPorPotrero: Map<Long, Int>,
    selectedPotreroId: Long?,
    onSelectPotrero: (PotreroEntity) -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(MaterialTheme.shapes.large)
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFE2F0E5), Color(0xFFD0E6D5))
                )
            )
            .border(1.5.dp, PastureGreen.copy(alpha = 0.4f), MaterialTheme.shapes.large)
    ) {
        // Líneas topográficas decorativas de plano de campo
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stepX = size.width / 6f
            val stepY = size.height / 4f
            for (i in 1..5) {
                drawLine(
                    color = Color(0xFF9EC5AA).copy(alpha = 0.45f),
                    start = Offset(i * stepX, 0f),
                    end = Offset(i * stepX, size.height),
                    strokeWidth = 1f
                )
            }
            for (j in 1..3) {
                drawLine(
                    color = Color(0xFF9EC5AA).copy(alpha = 0.45f),
                    start = Offset(0f, j * stepY),
                    end = Offset(size.width, j * stepY),
                    strokeWidth = 1f
                )
            }
        }

        val maxW = maxWidth
        val maxH = maxHeight
        potreros.forEach { p ->
            val count = animalesPorPotrero[p.id] ?: 0
            val isSelected = p.id == selectedPotreroId
            val cardColor = when (p.estadoPasto) {
                "En uso" -> ForestGreen
                "Óptimo" -> MeadowGreen
                "En descanso" -> EarthTerracotta
                else -> CrimsonAlert
            }
            val xOff = (p.posicionX.coerceIn(0.03f, 0.58f)) * maxW.value
            val yOff = (p.posicionY.coerceIn(0.05f, 0.58f)) * maxH.value

            Surface(
                modifier = Modifier
                    .offset(x = xOff.dp, y = yOff.dp)
                    .width((maxW * 0.39f).coerceAtLeast(124.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectPotrero(p) },
                shape = RoundedCornerShape(14.dp),
                color = if (isSelected) cardColor else cardColor.copy(alpha = 0.88f),
                border = BorderStroke(if (isSelected) 2.5.dp else 1.dp, Color.White)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = p.nombre,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${ChileanFormatters.formatNumber(p.superficieHa)} ha · $count ovinos",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Text(
                        text = p.estadoPasto,
                        style = MaterialTheme.typography.labelSmall,
                        color = SoftMint,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownField(
    label: String,
    selectedText: String,
    options: List<String>,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = selectedText,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth(),
            singleLine = true
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEachIndexed { idx, option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelect(idx)
                        expanded = false
                    }
                )
            }
        }
    }
}
