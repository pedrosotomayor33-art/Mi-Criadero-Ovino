package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.CriaderoRepository
import com.example.ui.CriaderoUiState
import com.example.ui.CriaderoViewModel
import com.example.ui.components.DropdownField
import com.example.ui.components.QuickEncasteDialog
import com.example.ui.components.QuickPartoDialog
import com.example.ui.theme.*
import com.example.util.ChileanFormatters
import java.util.concurrent.TimeUnit

@Composable
fun ReproductionScreen(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel
) {
    var activeTab by remember { mutableIntStateOf(0) }
    var showEncasteDialog by remember { mutableStateOf(false) }
    var showGestacionDialog by remember { mutableStateOf(false) }
    var showPartoDialog by remember { mutableStateOf(false) }

    val animalById = remember(state.animales) { state.animales.associateBy { it.id } }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            if (state.canEdit && activeTab in 0..2) {
                FloatingActionButton(
                    onClick = {
                        when (activeTab) {
                            0 -> showEncasteDialog = true
                            1 -> showGestacionDialog = true
                            2 -> showPartoDialog = true
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "Agregar registro reproductivo")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            TabRow(selectedTabIndex = activeTab) {
                listOf("Encaste", "Gestación", "Partos", "Genética").forEachIndexed { idx, title ->
                    Tab(
                        selected = activeTab == idx,
                        onClick = { activeTab = idx },
                        text = { Text(title, maxLines = 1) }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                when (activeTab) {
                    0 -> { // ENCASTE
                        if (state.encastes.isEmpty()) {
                            item { Text("No hay encastes registrados.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        } else {
                            items(state.encastes, key = { it.id }) { e ->
                                val carnero = animalById[e.carneroId]
                                val ovejasAretes = e.ovejaIdsCsv.split(",")
                                    .mapNotNull { it.toLongOrNull() }
                                    .mapNotNull { animalById[it]?.arete }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(
                                                text = "Carnero: ${carnero?.arete ?: "#${e.carneroId}"} ${carnero?.nombre?.let { "($it)" } ?: ""}",
                                                fontWeight = FontWeight.Bold,
                                                color = ForestGreen
                                            )
                                            Surface(color = SoftMint, shape = RoundedCornerShape(6.dp)) {
                                                Text(e.metodo, style = MaterialTheme.typography.labelSmall, color = ForestGreen, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                            }
                                        }
                                        Text(
                                            "Período: ${ChileanFormatters.formatDate(e.fechaInicio)} al ${ChileanFormatters.formatDate(e.fechaTermino)}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            "Ovejas (${ovejasAretes.size}): ${ovejasAretes.joinToString(", ")}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (e.observaciones.isNotBlank()) {
                                            Text(e.observaciones, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> { // GESTACIÓN
                        if (state.gestaciones.isEmpty()) {
                            item { Text("No hay diagnósticos de gestación registrados.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        } else {
                            items(state.gestaciones, key = { it.id }) { g ->
                                val oveja = animalById[g.ovejaId]
                                val carnero = g.carneroId?.let { animalById[it] }
                                val diasRestantes = TimeUnit.MILLISECONDS.toDays(g.fechaProbableParto - System.currentTimeMillis())
                                val isSoon = g.estadoGestacion == "Preñada" && diasRestantes in -3..14
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, if (isSoon) EarthTerracotta else MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Oveja: ${oveja?.arete ?: "#${g.ovejaId}"} ${oveja?.nombre?.let { "· $it" } ?: ""}",
                                                fontWeight = FontWeight.Bold
                                            )
                                            Surface(
                                                color = if (g.estadoGestacion == "Preñada") TerracottaSoft else MaterialTheme.colorScheme.surfaceVariant,
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = "${g.estadoGestacion} (${g.numeroFetos} feto${if (g.numeroFetos > 1) "s" else ""})",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (g.estadoGestacion == "Preñada") SaddleBrown else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            "Diagnóstico: ${ChileanFormatters.formatDate(g.fechaDiagnostico)} · Padre: ${carnero?.arete ?: "No reg."}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Parto probable: ${ChileanFormatters.formatDate(g.fechaProbableParto)} " +
                                                if (g.estadoGestacion == "Preñada") "(en $diasRestantes días)" else "",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isSoon) EarthTerracotta else ForestGreen
                                        )
                                        if (g.observaciones.isNotBlank()) Text(g.observaciones, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }

                    2 -> { // PARTOS
                        if (state.partos.isEmpty()) {
                            item { Text("No hay partos registrados aún.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        } else {
                            items(state.partos, key = { it.id }) { p ->
                                val madre = animalById[p.madreId]
                                val padre = p.padreId?.let { animalById[it] }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(
                                                "Madre: ${madre?.arete ?: "#${p.madreId}"} · ${p.tipoParto}",
                                                fontWeight = FontWeight.Bold,
                                                color = ForestGreen
                                            )
                                            Text(ChileanFormatters.formatDate(p.fechaParto), style = MaterialTheme.typography.labelMedium)
                                        }
                                        Text(
                                            "Padre: ${padre?.arete ?: "No reg."} · Asistencia: ${p.asistencia}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            "Supervivencia: ${p.criasVivas} viva(s), ${p.criasMuertas} mortinato(s)",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        if (p.detalleCrias.isNotBlank()) {
                                            Text(p.detalleCrias, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    3 -> { // GENÉTICA Y CONSANGUINIDAD
                        item {
                            ConsanguinitySimulatorCard(state = state, viewModel = viewModel)
                        }
                        item {
                            Text("Productividad por reproductor", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        val reproductores = state.animales.filter { a ->
                            state.animales.any { it.madreId == a.id || it.padreId == a.id }
                        }.sortedByDescending { a ->
                            state.animales.count { it.madreId == a.id || it.padreId == a.id }
                        }
                        items(reproductores, key = { it.id }) { rep ->
                            val criasCount = state.animales.count { it.madreId == rep.id || it.padreId == rep.id }
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.AccountTree,
                                        contentDescription = null,
                                        tint = if (rep.sexo == "Macho") SkyInfo else EarthTerracotta
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${rep.arete} · ${rep.nombre.ifBlank { rep.raza }}", fontWeight = FontWeight.Bold)
                                        Text("${rep.sexo} · ${rep.raza}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Surface(color = SoftMint, shape = RoundedCornerShape(8.dp)) {
                                        Text(
                                            text = "$criasCount crías",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = ForestGreen,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEncasteDialog) QuickEncasteDialog(state = state, viewModel = viewModel) { showEncasteDialog = false }
    if (showPartoDialog) QuickPartoDialog(state = state, viewModel = viewModel) { showPartoDialog = false }
    if (showGestacionDialog) {
        GestacionDialog(state = state, viewModel = viewModel) { showGestacionDialog = false }
    }
}

@Composable
private fun ConsanguinitySimulatorCard(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel
) {
    val hembras = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Hembra" } }
    val machos = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Macho" } }
    var madreId by remember { mutableStateOf(hembras.firstOrNull()?.id) }
    var padreId by remember { mutableStateOf(machos.firstOrNull()?.id) }

    val result = remember(madreId, padreId, state.animales) {
        viewModel.repo.checkConsanguinity(madreId, padreId, state.animales)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Verificador de Consanguinidad", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Seleccione madre y carnero para validar parentesco antes de encastar.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            if (hembras.isNotEmpty() && machos.isNotEmpty()) {
                val h = hembras.firstOrNull { it.id == madreId } ?: hembras.first()
                val m = machos.firstOrNull { it.id == padreId } ?: machos.first()
                DropdownField(
                    label = "Hembra",
                    selectedText = "${h.arete} · ${h.nombre.ifBlank { h.raza }}",
                    options = hembras.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" },
                    onSelect = { madreId = hembras[it].id }
                )
                DropdownField(
                    label = "Carnero",
                    selectedText = "${m.arete} · ${m.nombre.ifBlank { m.raza }}",
                    options = machos.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" },
                    onSelect = { padreId = machos[it].id }
                )

                val bg = if (result.hayParentesco) CrimsonSoft else SoftMint
                val fg = if (result.hayParentesco) CrimsonAlert else ForestGreen
                Surface(color = bg, shape = MaterialTheme.shapes.small, border = BorderStroke(1.dp, fg.copy(alpha = 0.5f))) {
                    Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (result.hayParentesco) Icons.Filled.Warning else Icons.Filled.VerifiedUser,
                            contentDescription = null,
                            tint = fg
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(result.nivelRiesgo, fontWeight = FontWeight.Bold, color = fg)
                            Text(result.detalle, style = MaterialTheme.typography.bodySmall, color = fg)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GestacionDialog(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onDismiss: () -> Unit
) {
    val hembras = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Hembra" } }
    val machos = remember(state.animales) { state.animales.filter { it.estado == "Activo" && it.sexo == "Macho" } }
    var ovejaId by remember { mutableStateOf(hembras.firstOrNull()?.id) }
    var carneroId by remember { mutableStateOf(machos.firstOrNull()?.id) }
    var diasDesdeEncasteStr by remember { mutableStateOf("45") }
    var estado by remember { mutableStateOf("Preñada") }
    var fetosStr by remember { mutableStateOf("1") }
    var obs by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Diagnóstico de Gestación") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (hembras.isEmpty()) {
                    Text("No hay hembras activas.")
                } else {
                    val h = hembras.firstOrNull { it.id == ovejaId } ?: hembras.first()
                    DropdownField(
                        label = "Oveja",
                        selectedText = "${h.arete} · ${h.nombre.ifBlank { h.raza }}",
                        options = hembras.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" },
                        onSelect = { ovejaId = hembras[it].id }
                    )
                    if (machos.isNotEmpty()) {
                        val pOpts = listOf("Desconocido") + machos.map { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" }
                        val pTxt = machos.firstOrNull { it.id == carneroId }?.let { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" } ?: "Desconocido"
                        DropdownField(
                            label = "Carnero padre",
                            selectedText = pTxt,
                            options = pOpts,
                            onSelect = { idx -> carneroId = if (idx == 0) null else machos[idx - 1].id }
                        )
                    }
                    DropdownField(
                        label = "Estado de gestación",
                        selectedText = estado,
                        options = listOf("Preñada", "Vacía", "Dudosa", "Aborto"),
                        onSelect = { estado = listOf("Preñada", "Vacía", "Dudosa", "Aborto")[it] }
                    )
                    OutlinedTextField(
                        value = diasDesdeEncasteStr,
                        onValueChange = { diasDesdeEncasteStr = it },
                        label = { Text("Días desde el encaste (calcula FPP +147d)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = fetosStr,
                        onValueChange = { fetosStr = it },
                        label = { Text("N° de fetos estimados") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(value = obs, onValueChange = { obs = it }, label = { Text("Observaciones") })

                    val diasEnc = diasDesdeEncasteStr.toLongOrNull() ?: 45L
                    val fpp = (System.currentTimeMillis() - diasEnc * CriaderoRepository.DAY_MS) + CriaderoRepository.GESTATION_DAYS * CriaderoRepository.DAY_MS
                    Text(
                        text = "Parto probable estimado: ${ChileanFormatters.formatDate(fpp)}",
                        style = MaterialTheme.typography.labelLarge,
                        color = ForestGreen
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = hembras.isNotEmpty(),
                onClick = {
                    val now = System.currentTimeMillis()
                    val diasEnc = diasDesdeEncasteStr.toLongOrNull() ?: 45L
                    ovejaId?.let { oid ->
                        viewModel.registrarGestacion(
                            ovejaId = oid,
                            carneroId = carneroId,
                            fechaEncaste = now - diasEnc * CriaderoRepository.DAY_MS,
                            fechaDiagnostico = now,
                            estadoGestacion = estado,
                            numeroFetos = fetosStr.toIntOrNull() ?: 1,
                            observaciones = obs,
                            onSuccess = onDismiss
                        )
                    }
                }
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
