package com.example.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlin.math.max

data class LambBirthInput(
    val arete: String,
    val nombre: String,
    val sexo: String,
    val pesoNacimientoKg: Double,
    val vivo: Boolean
)

data class ConsanguinityResult(
    val hayParentesco: Boolean,
    val nivelRiesgo: String, // "Sin parentesco", "Alerta Moderada", "Alto Riesgo"
    val detalle: String
)

data class AlertaCriadero(
    val id: String,
    val titulo: String,
    val detalle: String,
    val modulo: String, // "Parto", "Sanidad", "Potrero", "Inventario", "Destete"
    val prioridad: String, // "Atrasada", "Hoy", "Próxima"
    val fechaObjetivo: Long
)

data class WeightStats(
    val pesoActualKg: Double,
    val gananciaUltimoPesajeKg: Double?,
    val gmdGramsPerDay: Double?,
    val gananciaTotalNacimientoKg: Double,
    val proyeccion30DiasKg: Double?
)

class CriaderoRepository(
    private val db: CriaderoDatabase,
    private val dao: CriaderoDao = db.criaderoDao()
) {
    companion object {
        const val DAY_MS = 86_400_000L
        const val GESTATION_DAYS = 147L
    }

    val animales: Flow<List<AnimalEntity>> = dao.observeAnimales()
    val pesajes: Flow<List<PesajeEntity>> = dao.observePesajes()
    val encastes: Flow<List<EncasteEntity>> = dao.observeEncastes()
    val gestaciones: Flow<List<GestacionEntity>> = dao.observeGestaciones()
    val partos: Flow<List<PartoEntity>> = dao.observePartos()
    val sanidad: Flow<List<SanidadEntity>> = dao.observeSanidad()
    val potreros: Flow<List<PotreroEntity>> = dao.observePotreros()
    val movimientosPotrero: Flow<List<MovimientoPotreroEntity>> = dao.observeMovimientosPotrero()
    val raciones: Flow<List<AlimentoRacionEntity>> = dao.observeRaciones()
    val inventario: Flow<List<InventarioItemEntity>> = dao.observeInventario()
    val movimientosInventario: Flow<List<MovimientoInventarioEntity>> = dao.observeMovimientosInventario()
    val transacciones: Flow<List<TransaccionEconomicaEntity>> = dao.observeTransacciones()
    val lotes: Flow<List<LoteEntity>> = dao.observeLotes()
    val destetes: Flow<List<DesteteEntity>> = dao.observeDestetes()
    val usuarios: Flow<List<UserAccountEntity>> = dao.observeUsuarios()

    // --- Animales ---
    suspend fun saveAnimal(animal: AnimalEntity): Result<Long> = runCatching {
        val cleanArete = animal.arete.trim()
        require(cleanArete.isNotEmpty()) { "El número de arete es obligatorio." }
        require(animal.pesoNacimientoKg >= 0.0 && animal.pesoActualKg >= 0.0) {
            "Los pesos deben ser valores positivos en kg."
        }
        val existing = dao.getAnimalByArete(cleanArete)
        if (existing != null && existing.id != animal.id) {
            throw IllegalArgumentException("Ya existe un ovino registrado con el arete '$cleanArete'.")
        }
        val normalized = animal.copy(arete = cleanArete)
        if (animal.id == 0L) {
            db.withTransaction {
                val newId = dao.insertAnimal(normalized)
                if (normalized.pesoActualKg > 0) {
                    val ageDays = max(0, ((System.currentTimeMillis() - normalized.fechaNacimiento) / DAY_MS).toInt())
                    dao.insertPesaje(
                        PesajeEntity(
                            animalId = newId,
                            fecha = normalized.fechaIngreso,
                            pesoKg = normalized.pesoActualKg,
                            edadDias = ageDays,
                            observaciones = "Peso inicial al registrar ficha"
                        )
                    )
                }
                newId
            }
        } else {
            dao.updateAnimal(normalized)
            animal.id
        }
    }

    suspend fun deleteAnimal(animal: AnimalEntity): Result<Unit> = runCatching {
        dao.deleteAnimal(animal)
    }

    suspend fun darDeBajaAnimal(
        animal: AnimalEntity,
        nuevoEstado: String,
        motivo: String
    ): Result<Unit> = runCatching {
        val updatedObs = if (motivo.isBlank()) animal.observaciones else {
            listOf(animal.observaciones, "Baja ($nuevoEstado): $motivo")
                .filter { it.isNotBlank() }
                .joinToString("\n")
        }
        dao.updateAnimal(animal.copy(estado = nuevoEstado, prenada = false, observaciones = updatedObs))
    }

    // --- Pesajes ---
    suspend fun registrarPesaje(
        animalId: Long,
        pesoKg: Double,
        fecha: Long,
        observaciones: String
    ): Result<Unit> = runCatching {
        require(pesoKg > 0.0) { "El peso debe ser mayor a 0 kg." }
        val animal = dao.getAnimalById(animalId)
            ?: throw IllegalStateException("Animal no encontrado.")
        val edadDias = max(0, ((fecha - animal.fechaNacimiento) / DAY_MS).toInt())
        db.withTransaction {
            dao.insertPesaje(
                PesajeEntity(
                    animalId = animalId,
                    fecha = fecha,
                    pesoKg = pesoKg,
                    edadDias = edadDias,
                    observaciones = observaciones.trim()
                )
            )
            dao.updateAnimal(animal.copy(pesoActualKg = pesoKg))
        }
    }

    suspend fun deletePesaje(pesaje: PesajeEntity): Result<Unit> = runCatching {
        dao.deletePesaje(pesaje)
    }

    fun calculateWeightStats(animal: AnimalEntity, animalPesajes: List<PesajeEntity>): WeightStats {
        val sorted = animalPesajes.sortedBy { it.fecha }
        val last = sorted.lastOrNull()
        val prev = if (sorted.size >= 2) sorted[sorted.size - 2] else null
        val currentWeight = last?.pesoKg ?: animal.pesoActualKg
        val gainLast = if (last != null && prev != null) last.pesoKg - prev.pesoKg else null

        val gmdGrams: Double? = when {
            sorted.size >= 2 -> {
                val first = sorted.first()
                val days = max(1L, (last!!.fecha - first.fecha) / DAY_MS)
                ((last.pesoKg - first.pesoKg) * 1000.0) / days
            }
            animal.pesoNacimientoKg > 0 && currentWeight > animal.pesoNacimientoKg -> {
                val days = max(1L, ((last?.fecha ?: System.currentTimeMillis()) - animal.fechaNacimiento) / DAY_MS)
                ((currentWeight - animal.pesoNacimientoKg) * 1000.0) / days
            }
            else -> null
        }

        val totalGain = currentWeight - animal.pesoNacimientoKg
        val proj30 = gmdGrams?.let { currentWeight + (it / 1000.0) * 30.0 }

        return WeightStats(
            pesoActualKg = currentWeight,
            gananciaUltimoPesajeKg = gainLast,
            gmdGramsPerDay = gmdGrams,
            gananciaTotalNacimientoKg = totalGain,
            proyeccion30DiasKg = proj30
        )
    }

    // --- Reproducción & Genética ---
    fun checkConsanguinity(
        madreId: Long?,
        padreId: Long?,
        allAnimales: List<AnimalEntity>
    ): ConsanguinityResult {
        if (madreId == null || padreId == null) {
            return ConsanguinityResult(false, "Sin parentesco", "Sin datos suficientes de parentesco.")
        }
        if (madreId == padreId) {
            return ConsanguinityResult(true, "Alto Riesgo", "Mismo animal seleccionado.")
        }
        val byId = allAnimales.associateBy { it.id }
        val madre = byId[madreId] ?: return ConsanguinityResult(false, "Sin parentesco", "")
        val padre = byId[padreId] ?: return ConsanguinityResult(false, "Sin parentesco", "")

        // Padre-Hija o Madre-Hijo
        if (madre.padreId == padre.id || padre.madreId == madre.id) {
            return ConsanguinityResult(
                true,
                "Alto Riesgo",
                "Cruzamiento directo progenitor-descendiente (${madre.arete} y ${padre.arete})."
            )
        }
        // Hermanos completos o medios hermanos
        val mismaMadre = madre.madreId != null && madre.madreId == padre.madreId
        val mismoPadre = madre.padreId != null && madre.padreId == padre.padreId
        if (mismaMadre && mismoPadre) {
            return ConsanguinityResult(
                true,
                "Alto Riesgo",
                "Son hermanos completos (comparten madre y padre)."
            )
        }
        if (mismaMadre || mismoPadre) {
            return ConsanguinityResult(
                true,
                "Alto Riesgo",
                "Son medios hermanos (comparten ${if (mismaMadre) "la misma madre" else "el mismo padre"})."
            )
        }
        // Abuelos en común
        val abuelosMadre = setOfNotNull(
            byId[madre.madreId]?.madreId,
            byId[madre.madreId]?.padreId,
            byId[madre.padreId]?.madreId,
            byId[madre.padreId]?.padreId
        )
        val abuelosPadre = setOfNotNull(
            byId[padre.madreId]?.madreId,
            byId[padre.madreId]?.padreId,
            byId[padre.padreId]?.madreId,
            byId[padre.padreId]?.padreId
        )
        val abuelosComunes = abuelosMadre.intersect(abuelosPadre)
        if (abuelosComunes.isNotEmpty()) {
            return ConsanguinityResult(
                true,
                "Alerta Moderada",
                "Comparten ancestros (abuelos en común). Considere cambiar el reproductor."
            )
        }
        return ConsanguinityResult(false, "Sin parentesco", "Cruce genéticamente seguro.")
    }

    suspend fun registrarEncaste(
        fechaInicio: Long,
        fechaTermino: Long,
        carneroId: Long,
        ovejaIds: List<Long>,
        metodo: String,
        observaciones: String,
        crearGestacionesTentativas: Boolean = true
    ): Result<Unit> = runCatching {
        require(ovejaIds.isNotEmpty()) { "Seleccione al menos una oveja para el encaste." }
        db.withTransaction {
            val encasteId = dao.insertEncaste(
                EncasteEntity(
                    fechaInicio = fechaInicio,
                    fechaTermino = fechaTermino,
                    carneroId = carneroId,
                    ovejaIdsCsv = ovejaIds.joinToString(","),
                    metodo = metodo,
                    observaciones = observaciones
                )
            )
            if (crearGestacionesTentativas) {
                val fpp = fechaInicio + GESTATION_DAYS * DAY_MS
                ovejaIds.forEach { ovejaId ->
                    dao.insertGestacion(
                        GestacionEntity(
                            ovejaId = ovejaId,
                            carneroId = carneroId,
                            encasteId = encasteId,
                            fechaEncaste = fechaInicio,
                            fechaDiagnostico = fechaInicio,
                            estadoGestacion = "Dudosa",
                            numeroFetos = 1,
                            fechaProbableParto = fpp,
                            observaciones = "Generada automáticamente desde encaste ($metodo)"
                        )
                    )
                }
            }
        }
    }

    suspend fun registrarGestacion(
        ovejaId: Long,
        carneroId: Long?,
        fechaEncaste: Long,
        fechaDiagnostico: Long,
        estadoGestacion: String,
        numeroFetos: Int,
        observaciones: String
    ): Result<Unit> = runCatching {
        val fpp = fechaEncaste + GESTATION_DAYS * DAY_MS
        db.withTransaction {
            dao.insertGestacion(
                GestacionEntity(
                    ovejaId = ovejaId,
                    carneroId = carneroId,
                    fechaEncaste = fechaEncaste,
                    fechaDiagnostico = fechaDiagnostico,
                    estadoGestacion = estadoGestacion,
                    numeroFetos = numeroFetos,
                    fechaProbableParto = fpp,
                    observaciones = observaciones
                )
            )
            dao.getAnimalById(ovejaId)?.let { oveja ->
                val isPregnant = estadoGestacion == "Preñada"
                dao.updateAnimal(
                    oveja.copy(
                        prenada = isPregnant,
                        fechaProbableParto = if (isPregnant) fpp else null
                    )
                )
            }
        }
    }

    suspend fun registrarPartoYCrearCorderos(
        madreId: Long,
        padreId: Long?,
        fechaParto: Long,
        asistencia: String,
        observaciones: String,
        crias: List<LambBirthInput>
    ): Result<Int> = runCatching {
        require(crias.isNotEmpty()) { "Debe ingresar al menos una cría." }
        val madre = dao.getAnimalById(madreId)
            ?: throw IllegalStateException("Madre no encontrada.")
        val padre = padreId?.let { dao.getAnimalById(it) }

        val liveAretes = crias.filter { it.vivo }.map { it.arete.trim() }
        require(liveAretes.all { it.isNotEmpty() }) {
            "Cada cría viva requiere un número de arete único."
        }
        require(liveAretes.distinctBy { it.lowercase() }.size == liveAretes.size) {
            "Los aretes de las crías no pueden repetirse."
        }
        for (arete in liveAretes) {
            if (dao.getAnimalByArete(arete) != null) {
                throw IllegalArgumentException("El arete '$arete' ya está registrado en el criadero.")
            }
        }

        val tipoParto = when (crias.size) {
            1 -> "Único"
            2 -> "Mellizo"
            else -> "Trillizo"
        }
        val detalle = crias.joinToString("; ") {
            val estadoStr = if (it.vivo) "Vivo - ${it.arete}" else "Mortinato"
            "${it.sexo} ${"%.1f".format(it.pesoNacimientoKg)} kg ($estadoStr)"
        }
        val razaCordero = when {
            padre == null || padre.raza == madre.raza -> madre.raza
            else -> "${padre.raza} x ${madre.raza}"
        }

        db.withTransaction {
            dao.insertParto(
                PartoEntity(
                    madreId = madreId,
                    padreId = padreId,
                    fechaParto = fechaParto,
                    cantidadCrias = crias.size,
                    criasVivas = crias.count { it.vivo },
                    criasMuertas = crias.count { !it.vivo },
                    tipoParto = tipoParto,
                    asistencia = asistencia,
                    detalleCrias = detalle,
                    observaciones = observaciones
                )
            )
            dao.updateAnimal(madre.copy(prenada = false, fechaProbableParto = null))

            var createdCount = 0
            crias.filter { it.vivo }.forEach { cria ->
                val newId = dao.insertAnimal(
                    AnimalEntity(
                        arete = cria.arete.trim(),
                        nombre = cria.nombre.trim(),
                        sexo = cria.sexo,
                        raza = razaCordero,
                        fechaNacimiento = fechaParto,
                        pesoNacimientoKg = cria.pesoNacimientoKg,
                        pesoActualKg = cria.pesoNacimientoKg,
                        madreId = madreId,
                        padreId = padreId,
                        tipoNacimiento = tipoParto,
                        predioOrigen = "Propio",
                        fechaIngreso = fechaParto,
                        estado = "Activo",
                        proposito = "Engorda",
                        potreroId = madre.potreroId,
                        loteId = null,
                        destetado = false,
                        observaciones = "Nacido de madre ${madre.arete}"
                    )
                )
                dao.insertPesaje(
                    PesajeEntity(
                        animalId = newId,
                        fecha = fechaParto,
                        pesoKg = cria.pesoNacimientoKg,
                        edadDias = 0,
                        observaciones = "Peso al nacimiento (Parto $tipoParto)"
                    )
                )
                createdCount++
            }
            createdCount
        }
    }

    // --- Sanidad ---
    suspend fun saveSanidad(sanidad: SanidadEntity): Result<Long> = runCatching {
        require(sanidad.diagnostico.isNotBlank()) { "El diagnóstico o manejo es obligatorio." }
        dao.insertSanidad(sanidad)
    }

    suspend fun updateSanidad(sanidad: SanidadEntity): Result<Unit> = runCatching {
        dao.updateSanidad(sanidad)
    }

    suspend fun deleteSanidad(sanidad: SanidadEntity): Result<Unit> = runCatching {
        dao.deleteSanidad(sanidad)
    }

    // --- Potreros & Movimientos ---
    suspend fun savePotrero(potrero: PotreroEntity): Result<Long> = runCatching {
        require(potrero.nombre.isNotBlank()) { "El nombre del potrero es obligatorio." }
        require(potrero.superficieHa > 0.0) { "La superficie en hectáreas debe ser mayor a 0." }
        dao.insertPotrero(potrero)
    }

    suspend fun moverAnimalesDePotrero(
        animalIds: List<Long>,
        potreroOrigenId: Long?,
        potreroDestinoId: Long,
        motivo: String,
        observaciones: String
    ): Result<Unit> = runCatching {
        require(animalIds.isNotEmpty()) { "Seleccione al menos un animal para mover." }
        val now = System.currentTimeMillis()
        db.withTransaction {
            dao.updateAnimalesPotrero(animalIds, potreroDestinoId)
            dao.insertMovimientoPotrero(
                MovimientoPotreroEntity(
                    potreroOrigenId = potreroOrigenId,
                    potreroDestinoId = potreroDestinoId,
                    cantidadAnimales = animalIds.size,
                    animalIdsCsv = animalIds.joinToString(","),
                    fechaMovimiento = now,
                    motivo = motivo.ifBlank { "Rotación de pradera" },
                    observaciones = observaciones
                )
            )
            dao.getPotreroById(potreroDestinoId)?.let { dest ->
                dao.updatePotrero(dest.copy(estadoPasto = "En uso", fechaEntrada = now, fechaSalida = null))
            }
            if (potreroOrigenId != null && potreroOrigenId != potreroDestinoId) {
                dao.getPotreroById(potreroOrigenId)?.let { orig ->
                    dao.updatePotrero(orig.copy(estadoPasto = "En descanso", fechaSalida = now))
                }
            }
        }
    }

    // --- Alimentación ---
    suspend fun saveRacion(racion: AlimentoRacionEntity): Result<Long> = runCatching {
        require(racion.nombre.isNotBlank()) { "El nombre de la ración es obligatorio." }
        dao.insertRacion(racion)
    }

    suspend fun deleteRacion(racion: AlimentoRacionEntity): Result<Unit> = runCatching {
        dao.deleteRacion(racion)
    }

    // --- Inventario ---
    suspend fun saveInventarioItem(item: InventarioItemEntity): Result<Long> = runCatching {
        require(item.nombre.isNotBlank()) { "El nombre del insumo es obligatorio." }
        dao.insertInventarioItem(item)
    }

    suspend fun registrarMovimientoInventario(
        itemId: Long,
        tipo: String, // "Entrada / Compra" or "Salida / Consumo"
        cantidad: Double,
        costoTotalClp: Double,
        nota: String
    ): Result<Unit> = runCatching {
        require(cantidad > 0.0) { "La cantidad debe ser mayor a 0." }
        val item = dao.getInventarioItemById(itemId)
            ?: throw IllegalStateException("Ítem de inventario no encontrado.")
        val nuevaCantidad = if (tipo.startsWith("Entrada")) {
            item.cantidadDisponible + cantidad
        } else {
            max(0.0, item.cantidadDisponible - cantidad)
        }
        db.withTransaction {
            dao.updateInventarioItem(
                item.copy(
                    cantidadDisponible = nuevaCantidad,
                    ultimoCostoUnitarioClp = if (tipo.startsWith("Entrada") && costoTotalClp > 0) {
                        costoTotalClp / cantidad
                    } else item.ultimoCostoUnitarioClp
                )
            )
            dao.insertMovimientoInventario(
                MovimientoInventarioEntity(
                    itemId = itemId,
                    tipo = tipo,
                    cantidad = cantidad,
                    fecha = System.currentTimeMillis(),
                    costoTotalClp = costoTotalClp,
                    nota = nota
                )
            )
        }
    }

    suspend fun deleteInventarioItem(item: InventarioItemEntity): Result<Unit> = runCatching {
        dao.deleteInventarioItem(item)
    }

    // --- Economía ---
    suspend fun saveTransaccion(tx: TransaccionEconomicaEntity): Result<Long> = runCatching {
        require(tx.montoClp > 0.0) { "El monto en CLP debe ser mayor a 0." }
        dao.insertTransaccion(tx)
    }

    suspend fun deleteTransaccion(tx: TransaccionEconomicaEntity): Result<Unit> = runCatching {
        dao.deleteTransaccion(tx)
    }

    // --- Lotes & Destete ---
    suspend fun saveLote(lote: LoteEntity, animalIds: List<Long>): Result<Long> = runCatching {
        require(lote.nombre.isNotBlank()) { "El nombre del lote es obligatorio." }
        db.withTransaction {
            val id = dao.insertLote(lote)
            if (animalIds.isNotEmpty()) {
                dao.updateAnimalesLote(animalIds, id)
            }
            id
        }
    }

    suspend fun registrarDestete(
        corderoId: Long,
        fecha: Long,
        pesoKg: Double,
        tipoDestete: String,
        loteDestinoId: Long?,
        observaciones: String
    ): Result<Unit> = runCatching {
        require(pesoKg > 0.0) { "El peso al destete debe ser mayor a 0 kg." }
        val cordero = dao.getAnimalById(corderoId)
            ?: throw IllegalStateException("Cordero no encontrado.")
        val edadDias = max(0, ((fecha - cordero.fechaNacimiento) / DAY_MS).toInt())
        db.withTransaction {
            dao.insertDestete(
                DesteteEntity(
                    corderoId = corderoId,
                    madreId = cordero.madreId,
                    fecha = fecha,
                    pesoKg = pesoKg,
                    tipoDestete = tipoDestete,
                    loteDestinoId = loteDestinoId,
                    observaciones = observaciones
                )
            )
            dao.insertPesaje(
                PesajeEntity(
                    animalId = corderoId,
                    fecha = fecha,
                    pesoKg = pesoKg,
                    edadDias = edadDias,
                    observaciones = "Pesaje de destete ($tipoDestete)"
                )
            )
            dao.updateAnimal(
                cordero.copy(
                    destetado = true,
                    pesoActualKg = pesoKg,
                    loteId = loteDestinoId ?: cordero.loteId
                )
            )
        }
    }

    // --- Usuarios ---
    suspend fun addUsuario(nombre: String, rol: String, etiqueta: String): Result<Long> = runCatching {
        require(nombre.isNotBlank() && etiqueta.isNotBlank()) {
            "Complete nombre y etiqueta del usuario."
        }
        dao.insertUsuario(UserAccountEntity(nombre = nombre.trim(), rol = rol, etiqueta = etiqueta.trim()))
    }

    suspend fun deleteUsuario(user: UserAccountEntity): Result<Unit> = runCatching {
        require(user.id != 1L) { "No se puede eliminar al Administrador Principal." }
        dao.deleteUsuario(user)
    }

    // --- Motor de Alertas ---
    fun generarAlertas(
        animales: List<AnimalEntity>,
        sanidad: List<SanidadEntity>,
        potreros: List<PotreroEntity>,
        inventario: List<InventarioItemEntity>
    ): List<AlertaCriadero> {
        val now = System.currentTimeMillis()
        val startOfToday = startOfDay(now)
        val endOfToday = startOfToday + DAY_MS - 1
        val next14Days = now + 14 * DAY_MS

        val alerts = mutableListOf<AlertaCriadero>()
        val animalById = animales.associateBy { it.id }

        // 1. Partos próximos
        animales.filter { it.estado == "Activo" && it.prenada && it.fechaProbableParto != null }.forEach { oveja ->
            val fpp = oveja.fechaProbableParto!!
            if (fpp <= next14Days) {
                val prioridad = when {
                    fpp < startOfToday -> "Atrasada"
                    fpp <= endOfToday -> "Hoy"
                    else -> "Próxima"
                }
                val dias = TimeUnit.MILLISECONDS.toDays(fpp - startOfToday)
                val msg = when {
                    dias < 0 -> "Parto probable vencido hace ${-dias} d"
                    dias == 0L -> "Fecha probable de parto HOY"
                    else -> "Parto estimado en $dias días"
                }
                alerts += AlertaCriadero(
                    id = "parto_${oveja.id}",
                    titulo = "Parto: ${oveja.arete} (${oveja.nombre.ifBlank { oveja.raza }})",
                    detalle = msg,
                    modulo = "Parto",
                    prioridad = prioridad,
                    fechaObjetivo = fpp
                )
            }
        }

        // 2. Sanidad y tratamientos pendientes
        sanidad.filter {
            it.evolucion != "Recuperado" && it.fechaProximaDosis != null
        }.forEach { reg ->
            val target = reg.fechaProximaDosis!!
            if (target <= next14Days) {
                val prioridad = when {
                    target < startOfToday -> "Atrasada"
                    target <= endOfToday -> "Hoy"
                    else -> "Próxima"
                }
                val sujeto = reg.animalId?.let { animalById[it]?.arete } ?: reg.loteNombre ?: "Rebaño"
                alerts += AlertaCriadero(
                    id = "sanidad_${reg.id}",
                    titulo = "${reg.tipoManejo}: $sujeto",
                    detalle = "${reg.medicamento.ifBlank { reg.diagnostico }}",
                    modulo = "Sanidad",
                    prioridad = prioridad,
                    fechaObjetivo = target
                )
            }
        }

        // 3. Potreros próximos a cumplir descanso
        potreros.filter { it.estadoPasto == "En descanso" && it.fechaSalida != null }.forEach { p ->
            val finDescanso = p.fechaSalida!! + p.diasDescansoObjetivo * DAY_MS
            if (finDescanso <= now + 5 * DAY_MS) {
                val prioridad = when {
                    finDescanso <= endOfToday -> "Hoy"
                    else -> "Próxima"
                }
                val dias = TimeUnit.MILLISECONDS.toDays(finDescanso - startOfToday)
                alerts += AlertaCriadero(
                    id = "potrero_${p.id}",
                    titulo = "Potrero listo: ${p.nombre}",
                    detalle = if (dias <= 0) "Cumplió sus ${p.diasDescansoObjetivo} días de descanso"
                    else "Cumple descanso en $dias días",
                    modulo = "Potrero",
                    prioridad = prioridad,
                    fechaObjetivo = finDescanso
                )
            }
        }

        // 4. Stock bajo / vencimiento inventario
        inventario.forEach { item ->
            if (item.cantidadDisponible <= item.stockMinimo) {
                alerts += AlertaCriadero(
                    id = "stock_${item.id}",
                    titulo = "Stock bajo: ${item.nombre}",
                    detalle = "Disponible: ${"%.1f".format(item.cantidadDisponible)} ${item.unidad} (Mín: ${"%.1f".format(item.stockMinimo)})",
                    modulo = "Inventario",
                    prioridad = "Hoy",
                    fechaObjetivo = now
                )
            }
            item.fechaVencimiento?.let { vto ->
                if (vto <= now + 30 * DAY_MS) {
                    alerts += AlertaCriadero(
                        id = "vto_${item.id}",
                        titulo = "Vencimiento: ${item.nombre}",
                        detalle = if (vto < startOfToday) "Producto vencido" else "Próximo a vencer",
                        modulo = "Inventario",
                        prioridad = if (vto < startOfToday) "Atrasada" else "Próxima",
                        fechaObjetivo = vto
                    )
                }
            }
        }

        // 5. Corderos listos para destete (>= 85 días sin destetar)
        animales.filter {
            it.estado == "Activo" && !it.destetado && ((now - it.fechaNacimiento) / DAY_MS) >= 85
        }.forEach { cordero ->
            val dias = (now - cordero.fechaNacimiento) / DAY_MS
            alerts += AlertaCriadero(
                id = "destete_${cordero.id}",
                titulo = "Destete sugerido: ${cordero.arete}",
                detalle = "Edad $dias días · Peso ${"%.1f".format(cordero.pesoActualKg)} kg",
                modulo = "Destete",
                prioridad = "Próxima",
                fechaObjetivo = now
            )
        }

        return alerts.sortedBy { it.fechaObjetivo }
    }

    private fun startOfDay(millis: Long): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    // --- Respaldo JSON completo (v2 con los 14 módulos + compatibilidad v1) ---
    suspend fun readLocalSnapshot(predioNombre: String): FullCriaderoBackupPayload = db.withTransaction {
        FullCriaderoBackupPayload(
            version = 2,
            exportedAt = System.currentTimeMillis(),
            predioNombre = predioNombre,
            animales = dao.observeAnimales().first(),
            pesajes = dao.observePesajes().first(),
            encastes = dao.observeEncastes().first(),
            gestaciones = dao.observeGestaciones().first(),
            partos = dao.observePartos().first(),
            sanidad = dao.observeSanidad().first(),
            potreros = dao.observePotreros().first(),
            movimientosPotrero = dao.observeMovimientosPotrero().first(),
            raciones = dao.observeRaciones().first(),
            inventario = dao.observeInventario().first(),
            movimientosInventario = dao.observeMovimientosInventario().first(),
            transacciones = dao.observeTransacciones().first(),
            lotes = dao.observeLotes().first(),
            destetes = dao.observeDestetes().first()
        )
    }

    suspend fun exportBackupJson(
        animales: List<AnimalEntity>,
        pesajes: List<PesajeEntity>,
        potreros: List<PotreroEntity>,
        sanidad: List<SanidadEntity>,
        inventario: List<InventarioItemEntity>,
        transacciones: List<TransaccionEconomicaEntity>
    ): String {
        val payload = FullCriaderoBackupPayload(
            version = 2,
            exportedAt = System.currentTimeMillis(),
            predioNombre = "Mi Criadero Ovino",
            animales = animales,
            pesajes = pesajes,
            potreros = potreros,
            sanidad = sanidad,
            inventario = inventario,
            transacciones = transacciones
        )
        return BackupJsonSerializer.serializeFullBackup(payload, pretty = true)
    }

    suspend fun resetAndReseedDatabase() {
        db.withTransaction {
            dao.clearPesajes()
            dao.clearEncastes()
            dao.clearGestaciones()
            dao.clearPartos()
            dao.clearSanidad()
            dao.clearMovimientosPotrero()
            dao.clearPotreros()
            dao.clearRaciones()
            dao.clearMovimientosInventario()
            dao.clearInventario()
            dao.clearTransacciones()
            dao.clearDestetes()
            dao.clearLotes()
            dao.clearAnimales()
        }
        DatabaseSeeder.seedIfEmpty(dao)
    }
}

data class FullCriaderoBackupPayload(
    val version: Int = 2,
    val exportedAt: Long = System.currentTimeMillis(),
    val predioNombre: String = "Mi Criadero Ovino",
    val animales: List<AnimalEntity> = emptyList(),
    val pesajes: List<PesajeEntity> = emptyList(),
    val encastes: List<EncasteEntity> = emptyList(),
    val gestaciones: List<GestacionEntity> = emptyList(),
    val partos: List<PartoEntity> = emptyList(),
    val sanidad: List<SanidadEntity> = emptyList(),
    val potreros: List<PotreroEntity> = emptyList(),
    val movimientosPotrero: List<MovimientoPotreroEntity> = emptyList(),
    val raciones: List<AlimentoRacionEntity> = emptyList(),
    val inventario: List<InventarioItemEntity> = emptyList(),
    val movimientosInventario: List<MovimientoInventarioEntity> = emptyList(),
    val transacciones: List<TransaccionEconomicaEntity> = emptyList(),
    val lotes: List<LoteEntity> = emptyList(),
    val destetes: List<DesteteEntity> = emptyList()
) {
    fun totalRecords(): Int = animales.size + pesajes.size + encastes.size + gestaciones.size +
        partos.size + sanidad.size + potreros.size + movimientosPotrero.size + raciones.size +
        inventario.size + movimientosInventario.size + transacciones.size + lotes.size + destetes.size
}

object BackupJsonSerializer {
    fun serializeFullBackup(payload: FullCriaderoBackupPayload, pretty: Boolean = true): String {
        val root = JSONObject().apply {
            put("app", "Mi Criadero Ovino")
            put("version", payload.version)
            put("exportedAt", payload.exportedAt)
            put("predioNombre", payload.predioNombre)
            put("totalRegistros", payload.totalRecords())

            put("animales", JSONArray().apply {
                payload.animales.forEach { a ->
                    put(JSONObject().apply {
                        put("id", a.id)
                        put("arete", a.arete)
                        put("nombre", a.nombre)
                        a.photoUri?.let { put("photoUri", it) }
                        put("sexo", a.sexo)
                        put("raza", a.raza)
                        put("fechaNacimiento", a.fechaNacimiento)
                        put("pesoNacimientoKg", a.pesoNacimientoKg)
                        put("pesoActualKg", a.pesoActualKg)
                        a.madreId?.let { put("madreId", it) }
                        a.padreId?.let { put("padreId", it) }
                        put("tipoNacimiento", a.tipoNacimiento)
                        put("predioOrigen", a.predioOrigen)
                        put("fechaIngreso", a.fechaIngreso)
                        put("estado", a.estado)
                        put("proposito", a.proposito)
                        a.potreroId?.let { put("potreroId", it) }
                        a.loteId?.let { put("loteId", it) }
                        put("prenada", a.prenada)
                        a.fechaProbableParto?.let { put("fechaProbableParto", it) }
                        put("destetado", a.destetado)
                        put("observaciones", a.observaciones)
                    })
                }
            })

            put("pesajes", JSONArray().apply {
                payload.pesajes.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id)
                        put("animalId", p.animalId)
                        put("fecha", p.fecha)
                        put("pesoKg", p.pesoKg)
                        put("edadDias", p.edadDias)
                        put("observaciones", p.observaciones)
                    })
                }
            })

            put("encastes", JSONArray().apply {
                payload.encastes.forEach { e ->
                    put(JSONObject().apply {
                        put("id", e.id)
                        put("fechaInicio", e.fechaInicio)
                        put("fechaTermino", e.fechaTermino)
                        put("carneroId", e.carneroId)
                        put("ovejaIdsCsv", e.ovejaIdsCsv)
                        put("metodo", e.metodo)
                        put("observaciones", e.observaciones)
                    })
                }
            })

            put("gestaciones", JSONArray().apply {
                payload.gestaciones.forEach { g ->
                    put(JSONObject().apply {
                        put("id", g.id)
                        put("ovejaId", g.ovejaId)
                        g.carneroId?.let { put("carneroId", it) }
                        g.encasteId?.let { put("encasteId", it) }
                        put("fechaEncaste", g.fechaEncaste)
                        put("fechaDiagnostico", g.fechaDiagnostico)
                        put("estadoGestacion", g.estadoGestacion)
                        put("numeroFetos", g.numeroFetos)
                        put("fechaProbableParto", g.fechaProbableParto)
                        put("observaciones", g.observaciones)
                    })
                }
            })

            put("partos", JSONArray().apply {
                payload.partos.forEach { pa ->
                    put(JSONObject().apply {
                        put("id", pa.id)
                        put("madreId", pa.madreId)
                        pa.padreId?.let { put("padreId", it) }
                        put("fechaParto", pa.fechaParto)
                        put("cantidadCrias", pa.cantidadCrias)
                        put("criasVivas", pa.criasVivas)
                        put("criasMuertas", pa.criasMuertas)
                        put("tipoParto", pa.tipoParto)
                        put("asistencia", pa.asistencia)
                        put("detalleCrias", pa.detalleCrias)
                        put("observaciones", pa.observaciones)
                    })
                }
            })

            put("sanidad", JSONArray().apply {
                payload.sanidad.forEach { s ->
                    put(JSONObject().apply {
                        put("id", s.id)
                        s.animalId?.let { put("animalId", it) }
                        s.loteNombre?.let { put("loteNombre", it) }
                        put("tipoManejo", s.tipoManejo)
                        put("diagnostico", s.diagnostico)
                        put("fecha", s.fecha)
                        put("sintomas", s.sintomas)
                        put("medicamento", s.medicamento)
                        put("principioActivo", s.principioActivo)
                        put("dosis", s.dosis)
                        put("unidadDosis", s.unidadDosis)
                        put("viaAdministracion", s.viaAdministracion)
                        put("duracionDias", s.duracionDias)
                        s.fechaProximaDosis?.let { put("fechaProximaDosis", it) }
                        put("veterinario", s.veterinario)
                        put("evolucion", s.evolucion)
                        put("observaciones", s.observaciones)
                    })
                }
            })

            put("potreros", JSONArray().apply {
                payload.potreros.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id)
                        put("nombre", p.nombre)
                        put("superficieHa", p.superficieHa)
                        put("tipoPradera", p.tipoPradera)
                        put("disponibilidadForrajeKgMsHa", p.disponibilidadForrajeKgMsHa)
                        put("estadoPasto", p.estadoPasto)
                        p.fechaEntrada?.let { put("fechaEntrada", it) }
                        p.fechaSalida?.let { put("fechaSalida", it) }
                        put("diasDescansoObjetivo", p.diasDescansoObjetivo)
                        put("posicionX", p.posicionX.toDouble())
                        put("posicionY", p.posicionY.toDouble())
                        put("observaciones", p.observaciones)
                    })
                }
            })

            put("movimientosPotrero", JSONArray().apply {
                payload.movimientosPotrero.forEach { m ->
                    put(JSONObject().apply {
                        put("id", m.id)
                        m.potreroOrigenId?.let { put("potreroOrigenId", it) }
                        put("potreroDestinoId", m.potreroDestinoId)
                        put("cantidadAnimales", m.cantidadAnimales)
                        put("animalIdsCsv", m.animalIdsCsv)
                        put("fechaMovimiento", m.fechaMovimiento)
                        put("motivo", m.motivo)
                        put("observaciones", m.observaciones)
                    })
                }
            })

            put("raciones", JSONArray().apply {
                payload.raciones.forEach { r ->
                    put(JSONObject().apply {
                        put("id", r.id)
                        put("nombre", r.nombre)
                        put("tipoAlimento", r.tipoAlimento)
                        put("ingrediente", r.ingrediente)
                        put("cantidadKg", r.cantidadKg)
                        put("porcentajeInclusion", r.porcentajeInclusion)
                        put("costoPorKgClp", r.costoPorKgClp)
                        put("cantidadDiariaAnimalKg", r.cantidadDiariaAnimalKg)
                        put("grupoDestinatario", r.grupoDestinatario)
                        put("cantidadAnimales", r.cantidadAnimales)
                        put("stockDisponibleKg", r.stockDisponibleKg)
                        put("observaciones", r.observaciones)
                    })
                }
            })

            put("inventario", JSONArray().apply {
                payload.inventario.forEach { item ->
                    put(JSONObject().apply {
                        put("id", item.id)
                        put("nombre", item.nombre)
                        put("categoria", item.categoria)
                        put("unidad", item.unidad)
                        put("cantidadDisponible", item.cantidadDisponible)
                        put("stockMinimo", item.stockMinimo)
                        item.fechaVencimiento?.let { put("fechaVencimiento", it) }
                        put("ultimoCostoUnitarioClp", item.ultimoCostoUnitarioClp)
                        put("observaciones", item.observaciones)
                    })
                }
            })

            put("movimientosInventario", JSONArray().apply {
                payload.movimientosInventario.forEach { mi ->
                    put(JSONObject().apply {
                        put("id", mi.id)
                        put("itemId", mi.itemId)
                        put("tipo", mi.tipo)
                        put("cantidad", mi.cantidad)
                        put("fecha", mi.fecha)
                        put("costoTotalClp", mi.costoTotalClp)
                        put("nota", mi.nota)
                    })
                }
            })

            put("transacciones", JSONArray().apply {
                payload.transacciones.forEach { tx ->
                    put(JSONObject().apply {
                        put("id", tx.id)
                        put("tipo", tx.tipo)
                        put("categoria", tx.categoria)
                        put("montoClp", tx.montoClp)
                        put("fecha", tx.fecha)
                        tx.cantidadKg?.let { put("cantidadKg", it) }
                        tx.animalId?.let { put("animalId", it) }
                        tx.loteId?.let { put("loteId", it) }
                        put("descripcion", tx.descripcion)
                    })
                }
            })

            put("lotes", JSONArray().apply {
                payload.lotes.forEach { l ->
                    put(JSONObject().apply {
                        put("id", l.id)
                        put("nombre", l.nombre)
                        put("criterio", l.criterio)
                        put("objetivoProductivo", l.objetivoProductivo)
                        l.potreroId?.let { put("potreroId", it) }
                        put("observaciones", l.observaciones)
                    })
                }
            })

            put("destetes", JSONArray().apply {
                payload.destetes.forEach { d ->
                    put(JSONObject().apply {
                        put("id", d.id)
                        put("corderoId", d.corderoId)
                        d.madreId?.let { put("madreId", it) }
                        put("fecha", d.fecha)
                        put("pesoKg", d.pesoKg)
                        put("tipoDestete", d.tipoDestete)
                        d.loteDestinoId?.let { put("loteDestinoId", it) }
                        put("observaciones", d.observaciones)
                    })
                }
            })
        }
        return if (pretty) root.toString(2) else root.toString()
    }

    fun parseFullBackup(jsonString: String): Result<FullCriaderoBackupPayload> = runCatching {
        val root = JSONObject(jsonString)
        val app = root.optString("app", "")
        require(app.contains("Criadero", ignoreCase = true) || root.has("animales")) {
            "El archivo JSON no corresponde a un respaldo válido de Mi Criadero Ovino."
        }
        val animales = parseArray(root.optJSONArray("animales")) { o, idx ->
            AnimalEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                arete = o.getString("arete"),
                nombre = o.optString("nombre", ""),
                photoUri = if (o.has("photoUri") && !o.isNull("photoUri")) o.optString("photoUri") else null,
                sexo = o.optString("sexo", "Hembra"),
                raza = o.optString("raza", "Suffolk Down"),
                fechaNacimiento = o.optLong("fechaNacimiento", System.currentTimeMillis()),
                pesoNacimientoKg = o.optDouble("pesoNacimientoKg", 4.0),
                pesoActualKg = o.optDouble("pesoActualKg", 40.0),
                madreId = o.optNullableLong("madreId"),
                padreId = o.optNullableLong("padreId"),
                tipoNacimiento = o.optString("tipoNacimiento", "Único"),
                predioOrigen = o.optString("predioOrigen", "Propio"),
                fechaIngreso = o.optLong("fechaIngreso", System.currentTimeMillis()),
                estado = o.optString("estado", "Activo"),
                proposito = o.optString("proposito", "Reproducción"),
                potreroId = o.optNullableLong("potreroId"),
                loteId = o.optNullableLong("loteId"),
                prenada = o.optBoolean("prenada", false),
                fechaProbableParto = o.optNullableLong("fechaProbableParto"),
                destetado = o.optBoolean("destetado", false),
                observaciones = o.optString("observaciones", "")
            )
        }
        val pesajes = parseArray(root.optJSONArray("pesajes")) { o, idx ->
            PesajeEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                animalId = o.getLong("animalId"),
                fecha = o.optLong("fecha", System.currentTimeMillis()),
                pesoKg = o.getDouble("pesoKg"),
                edadDias = o.optInt("edadDias", 0),
                observaciones = o.optString("observaciones", "")
            )
        }
        val encastes = parseArray(root.optJSONArray("encastes")) { o, idx ->
            EncasteEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                fechaInicio = o.optLong("fechaInicio", System.currentTimeMillis()),
                fechaTermino = o.optLong("fechaTermino", System.currentTimeMillis()),
                carneroId = o.getLong("carneroId"),
                ovejaIdsCsv = o.getString("ovejaIdsCsv"),
                metodo = o.optString("metodo", "Monta natural"),
                observaciones = o.optString("observaciones", "")
            )
        }
        val gestaciones = parseArray(root.optJSONArray("gestaciones")) { o, idx ->
            GestacionEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                ovejaId = o.getLong("ovejaId"),
                carneroId = o.optNullableLong("carneroId"),
                encasteId = o.optNullableLong("encasteId"),
                fechaEncaste = o.optLong("fechaEncaste", System.currentTimeMillis()),
                fechaDiagnostico = o.optLong("fechaDiagnostico", System.currentTimeMillis()),
                estadoGestacion = o.optString("estadoGestacion", "Preñada"),
                numeroFetos = o.optInt("numeroFetos", 1),
                fechaProbableParto = o.optLong("fechaProbableParto", System.currentTimeMillis()),
                observaciones = o.optString("observaciones", "")
            )
        }
        val partos = parseArray(root.optJSONArray("partos")) { o, idx ->
            PartoEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                madreId = o.getLong("madreId"),
                padreId = o.optNullableLong("padreId"),
                fechaParto = o.optLong("fechaParto", System.currentTimeMillis()),
                cantidadCrias = o.optInt("cantidadCrias", 1),
                criasVivas = o.optInt("criasVivas", 1),
                criasMuertas = o.optInt("criasMuertas", 0),
                tipoParto = o.optString("tipoParto", "Único"),
                asistencia = o.optString("asistencia", "Normal"),
                detalleCrias = o.optString("detalleCrias", ""),
                observaciones = o.optString("observaciones", "")
            )
        }
        val sanidad = parseArray(root.optJSONArray("sanidad")) { o, idx ->
            SanidadEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                animalId = o.optNullableLong("animalId"),
                loteNombre = if (o.has("loteNombre") && !o.isNull("loteNombre")) o.optString("loteNombre") else null,
                tipoManejo = o.optString("tipoManejo", "Tratamiento"),
                diagnostico = o.getString("diagnostico"),
                fecha = o.optLong("fecha", System.currentTimeMillis()),
                sintomas = o.optString("sintomas", ""),
                medicamento = o.optString("medicamento", ""),
                principioActivo = o.optString("principioActivo", ""),
                dosis = o.optDouble("dosis", 0.0),
                unidadDosis = o.optString("unidadDosis", "ml"),
                viaAdministracion = o.optString("viaAdministracion", "Subcutánea"),
                duracionDias = o.optInt("duracionDias", 1),
                fechaProximaDosis = o.optNullableLong("fechaProximaDosis"),
                veterinario = o.optString("veterinario", ""),
                evolucion = o.optString("evolucion", "En tratamiento"),
                observaciones = o.optString("observaciones", "")
            )
        }
        val potreros = parseArray(root.optJSONArray("potreros")) { o, idx ->
            PotreroEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                nombre = o.getString("nombre"),
                superficieHa = o.optDouble("superficieHa", 1.0),
                tipoPradera = o.optString("tipoPradera", ""),
                disponibilidadForrajeKgMsHa = o.optDouble("disponibilidadForrajeKgMsHa", 0.0),
                estadoPasto = o.optString("estadoPasto", "Óptimo"),
                fechaEntrada = o.optNullableLong("fechaEntrada"),
                fechaSalida = o.optNullableLong("fechaSalida"),
                diasDescansoObjetivo = o.optInt("diasDescansoObjetivo", 30),
                posicionX = o.optDouble("posicionX", 0.1).toFloat(),
                posicionY = o.optDouble("posicionY", 0.1).toFloat(),
                observaciones = o.optString("observaciones", "")
            )
        }
        val movimientosPotrero = parseArray(root.optJSONArray("movimientosPotrero")) { o, idx ->
            MovimientoPotreroEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                potreroOrigenId = o.optNullableLong("potreroOrigenId"),
                potreroDestinoId = o.getLong("potreroDestinoId"),
                cantidadAnimales = o.optInt("cantidadAnimales", 0),
                animalIdsCsv = o.optString("animalIdsCsv", ""),
                fechaMovimiento = o.optLong("fechaMovimiento", System.currentTimeMillis()),
                motivo = o.optString("motivo", "Rotación de pradera"),
                observaciones = o.optString("observaciones", "")
            )
        }
        val raciones = parseArray(root.optJSONArray("raciones")) { o, idx ->
            AlimentoRacionEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                nombre = o.getString("nombre"),
                tipoAlimento = o.optString("tipoAlimento", "Avena"),
                ingrediente = o.optString("ingrediente", ""),
                cantidadKg = o.optDouble("cantidadKg", 0.0),
                porcentajeInclusion = o.optDouble("porcentajeInclusion", 0.0),
                costoPorKgClp = o.optDouble("costoPorKgClp", 0.0),
                cantidadDiariaAnimalKg = o.optDouble("cantidadDiariaAnimalKg", 0.0),
                grupoDestinatario = o.optString("grupoDestinatario", ""),
                cantidadAnimales = o.optInt("cantidadAnimales", 0),
                stockDisponibleKg = o.optDouble("stockDisponibleKg", 0.0),
                observaciones = o.optString("observaciones", "")
            )
        }
        val inventario = parseArray(root.optJSONArray("inventario")) { o, idx ->
            InventarioItemEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                nombre = o.getString("nombre"),
                categoria = o.optString("categoria", ""),
                unidad = o.optString("unidad", "ml"),
                cantidadDisponible = o.optDouble("cantidadDisponible", 0.0),
                stockMinimo = o.optDouble("stockMinimo", 0.0),
                fechaVencimiento = o.optNullableLong("fechaVencimiento"),
                ultimoCostoUnitarioClp = o.optDouble("ultimoCostoUnitarioClp", 0.0),
                observaciones = o.optString("observaciones", "")
            )
        }
        val movimientosInventario = parseArray(root.optJSONArray("movimientosInventario")) { o, idx ->
            MovimientoInventarioEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                itemId = o.getLong("itemId"),
                tipo = o.optString("tipo", "Entrada / Compra"),
                cantidad = o.optDouble("cantidad", 1.0),
                fecha = o.optLong("fecha", System.currentTimeMillis()),
                costoTotalClp = o.optDouble("costoTotalClp", 0.0),
                nota = o.optString("nota", "")
            )
        }
        val transacciones = parseArray(root.optJSONArray("transacciones")) { o, idx ->
            TransaccionEconomicaEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                tipo = o.optString("tipo", "Ingreso"),
                categoria = o.optString("categoria", "Otros"),
                montoClp = o.optDouble("montoClp", 1.0),
                fecha = o.optLong("fecha", System.currentTimeMillis()),
                cantidadKg = if (o.has("cantidadKg") && !o.isNull("cantidadKg")) o.optDouble("cantidadKg") else null,
                animalId = o.optNullableLong("animalId"),
                loteId = o.optNullableLong("loteId"),
                descripcion = o.optString("descripcion", "")
            )
        }
        val lotes = parseArray(root.optJSONArray("lotes")) { o, idx ->
            LoteEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                nombre = o.getString("nombre"),
                criterio = o.optString("criterio", ""),
                objetivoProductivo = o.optString("objetivoProductivo", ""),
                potreroId = o.optNullableLong("potreroId"),
                observaciones = o.optString("observaciones", "")
            )
        }
        val destetes = parseArray(root.optJSONArray("destetes")) { o, idx ->
            DesteteEntity(
                id = o.optLong("id", (idx + 1).toLong()),
                corderoId = o.getLong("corderoId"),
                madreId = o.optNullableLong("madreId"),
                fecha = o.optLong("fecha", System.currentTimeMillis()),
                pesoKg = o.optDouble("pesoKg", 20.0),
                tipoDestete = o.optString("tipoDestete", "Tradicional"),
                loteDestinoId = o.optNullableLong("loteDestinoId"),
                observaciones = o.optString("observaciones", "")
            )
        }

        FullCriaderoBackupPayload(
            version = root.optInt("version", 1),
            exportedAt = root.optLong("exportedAt", System.currentTimeMillis()),
            predioNombre = root.optString("predioNombre", "Mi Criadero Ovino"),
            animales = animales,
            pesajes = pesajes,
            encastes = encastes,
            gestaciones = gestaciones,
            partos = partos,
            sanidad = sanidad,
            potreros = potreros,
            movimientosPotrero = movimientosPotrero,
            raciones = raciones,
            inventario = inventario,
            movimientosInventario = movimientosInventario,
            transacciones = transacciones,
            lotes = lotes,
            destetes = destetes
        )
    }

    private inline fun <T> parseArray(arr: JSONArray?, mapper: (JSONObject, Int) -> T): List<T> {
        if (arr == null) return emptyList()
        val list = ArrayList<T>(arr.length())
        for (i in 0 until arr.length()) {
            list.add(mapper(arr.getJSONObject(i), i))
        }
        return list
    }

    private fun JSONObject.optNullableLong(key: String): Long? =
        if (has(key) && !isNull(key)) optLong(key) else null
}
