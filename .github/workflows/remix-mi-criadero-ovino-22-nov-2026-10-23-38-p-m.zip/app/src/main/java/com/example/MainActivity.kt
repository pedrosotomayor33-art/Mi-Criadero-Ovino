package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.auth.authStateFlow
import com.example.auth.configureAppCheck
import com.example.auth.signOutUser
import com.example.data.CloudSchema
import com.example.data.CriaderoDatabase
import com.example.data.NetworkMonitor
import com.example.data.SessionPreferences
import com.example.ui.CriaderoViewModel
import com.example.ui.components.BrandTopBar
import com.example.ui.screens.*
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.MiCriaderoOvinoTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.firestoreSettings

private enum class AppDestination(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
) {
    INVENTARIO("Inventario", Icons.Filled.Pets, Icons.Outlined.Pets, "nav_rebano"),
    INICIO("Resumen", Icons.Filled.Home, Icons.Outlined.Home, "nav_inicio"),
    REPRODUCCION("Reprod.", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, "nav_reproduccion"),
    CAMPO("Campo", Icons.Filled.Grass, Icons.Outlined.Grass, "nav_campo"),
    GESTION("Gestión", Icons.Filled.Assessment, Icons.Outlined.Assessment, "nav_gestion")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appContext = applicationContext
        configureAppCheck(appContext, intent)
        val firestoreDatabaseId = getString(R.string.firestore_database_id)
        val firestore = FirebaseFirestore.getInstance(firestoreDatabaseId).apply {
            firestoreSettings = firestoreSettings {
                setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
            }
        }
        val credentialManager = CredentialManager.create(appContext)
        val roomDb = CriaderoDatabase.getInstance(appContext)
        val prefs = SessionPreferences(appContext)
        val networkMonitor = NetworkMonitor(appContext)

        setContent {
            val authUser by Firebase.auth.authStateFlow()
                .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)
            val themeMode by prefs.themeModeFlow.collectAsStateWithLifecycle(initialValue = "SYSTEM")
            val criaderoId by prefs.criaderoIdFlow.collectAsStateWithLifecycle(initialValue = CloudSchema.DEFAULT_CRIADERO_ID)

            val darkTheme = when (themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            MiCriaderoOvinoTheme(darkTheme = darkTheme) {
                if (authUser == null) {
                    AuthScreen(credentialManager = credentialManager)
                } else {
                    val user = authUser!!
                    key(user.uid, criaderoId) {
                        AuthenticatedAppShell(
                            firebaseUser = user,
                            criaderoId = criaderoId,
                            credentialManager = credentialManager,
                            firestore = firestore,
                            roomDb = roomDb,
                            prefs = prefs,
                            networkMonitor = networkMonitor
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthenticatedAppShell(
    firebaseUser: FirebaseUser,
    criaderoId: String,
    credentialManager: CredentialManager,
    firestore: FirebaseFirestore,
    roomDb: CriaderoDatabase,
    prefs: SessionPreferences,
    networkMonitor: NetworkMonitor
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val viewModel: CriaderoViewModel = viewModel(
        key = "${firebaseUser.uid}_$criaderoId",
        factory = CriaderoViewModel.provideFactory(
            appContext = context.applicationContext,
            firestore = firestore,
            roomDb = roomDb,
            prefs = prefs,
            networkMonitor = networkMonitor,
            firebaseUser = firebaseUser,
            criaderoId = criaderoId
        )
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    if (state.cloudSession.isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(color = ForestGreen)
                Text(
                    text = "Verificando credenciales y sincronizando criadero...",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        return
    }

    if (!state.cloudSession.isAuthorized) {
        when {
            state.cloudSession.hasPendingAdminTransfer -> {
                PendingAdminTransferScreen(
                    userEmail = firebaseUser.email.orEmpty(),
                    predioNombre = state.cloudSession.workspace?.nombrePredio ?: criaderoId,
                    currentAdminEmail = state.cloudSession.workspace?.adminEmail.orEmpty(),
                    statusMessage = state.cloudSession.statusMessage,
                    isLoading = state.cloudSession.isLoading,
                    onAcceptTransfer = { viewModel.acceptAdminTransfer() },
                    onRetry = { viewModel.retryAccessResolution() },
                    onSignOut = { signOutUser(credentialManager, scope) }
                )
            }
            state.cloudSession.needsInitialSetup -> {
                InitialCriaderoSetupScreen(
                    userEmail = firebaseUser.email.orEmpty(),
                    criaderoId = criaderoId,
                    configuredInitialAdminEmail = BuildConfig.CRIADERO_ADMIN_EMAIL.trim().lowercase(),
                    statusMessage = state.cloudSession.statusMessage,
                    isLoading = state.cloudSession.isLoading,
                    onCreateWorkspace = { nombrePredio, s1, s2 ->
                        viewModel.initializeWorkspaceAsAdmin(nombrePredio, s1, s2)
                    },
                    onSwitchCriaderoId = { newId -> viewModel.switchCriaderoId(newId) },
                    onRetry = { viewModel.retryAccessResolution() },
                    onSignOut = { signOutUser(credentialManager, scope) }
                )
            }
            else -> {
                PendingAccessScreen(
                    userEmail = firebaseUser.email.orEmpty(),
                    criaderoId = criaderoId,
                    statusMessage = state.cloudSession.statusMessage,
                    isLoading = state.cloudSession.isLoading,
                    onSwitchCriaderoId = { newId -> viewModel.switchCriaderoId(newId) },
                    onRetry = { viewModel.retryAccessResolution() },
                    onSignOut = { signOutUser(credentialManager, scope) }
                )
            }
        }
        return
    }

    var currentDest by remember { mutableStateOf(AppDestination.INVENTARIO) }
    var selectedAnimalId by remember { mutableStateOf<Long?>(null) }
    var managementInitialTab by remember { mutableIntStateOf(0) }
    var showAccountDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) {
        viewModel.snackbarMessage.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                BrandTopBar(
                    predioNombre = state.predioNombre,
                    activeUser = state.activeUser,
                    alertCount = state.alertas.size,
                    onSwitchUserClick = { showAccountDialog = true },
                    onAlertsClick = {
                        managementInitialTab = 3
                        currentDest = AppDestination.GESTION
                    },
                    isOnline = state.isOnline,
                    isSyncPendingWrites = state.isSyncPendingWrites
                )
            },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        windowInsets = WindowInsets.safeDrawing.only(
                            WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal
                        )
                    ) {
                        AppDestination.entries.forEach { dest ->
                            val selected = currentDest == dest
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    if (dest != AppDestination.INVENTARIO) selectedAnimalId = null
                                    currentDest = dest
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label, maxLines = 1) },
                                modifier = Modifier.testTag(dest.tag)
                            )
                        }
                    }
                }
            },
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .consumeWindowInsets(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(
                        windowInsets = WindowInsets.safeDrawing.only(
                            WindowInsetsSides.Vertical + WindowInsetsSides.Start
                        )
                    ) {
                        Spacer(Modifier.height(8.dp))
                        AppDestination.entries.forEach { dest ->
                            val selected = currentDest == dest
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    if (dest != AppDestination.INVENTARIO) selectedAnimalId = null
                                    currentDest = dest
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label, maxLines = 1) },
                                modifier = Modifier.testTag(dest.tag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when (currentDest) {
                        AppDestination.INVENTARIO -> AnimalsScreen(
                            state = state,
                            viewModel = viewModel,
                            selectedAnimalId = selectedAnimalId,
                            onSelectAnimal = { selectedAnimalId = it }
                        )
                        AppDestination.INICIO -> DashboardScreen(
                            state = state,
                            viewModel = viewModel,
                            onOpenAnimalDetail = { id ->
                                selectedAnimalId = id
                                currentDest = AppDestination.INVENTARIO
                            },
                            onNavigateToAlerts = {
                                managementInitialTab = 3
                                currentDest = AppDestination.GESTION
                            },
                            onNavigateToAnimals = {
                                selectedAnimalId = null
                                currentDest = AppDestination.INVENTARIO
                            },
                            onNavigateToCloudMigration = {
                                managementInitialTab = 5
                                currentDest = AppDestination.GESTION
                            }
                        )
                        AppDestination.REPRODUCCION -> ReproductionScreen(
                            state = state,
                            viewModel = viewModel
                        )
                        AppDestination.CAMPO -> FieldOperationsScreen(
                            state = state,
                            viewModel = viewModel
                        )
                        AppDestination.GESTION -> ManagementScreen(
                            state = state,
                            viewModel = viewModel,
                            initialTab = managementInitialTab
                        )
                    }
                }
            }
        }
    }

    if (showAccountDialog) {
        AlertDialog(
            onDismissRequest = { showAccountDialog = false },
            title = { Text("Cuenta y Sesión Activa") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = state.activeUser?.etiqueta ?: "Usuario",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Correo: ${firebaseUser.email.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "Permiso verificado en servidor: ${state.activeUser?.rol ?: "Consulta"}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = ForestGreen
                    )
                    Text(
                        text = when {
                            !state.isOnline -> "Conexión: Sin señal (usando caché local persistente)."
                            state.isSyncPendingWrites -> "Conexión: Cambios pendientes por subir."
                            else -> "Conexión: En línea y sincronizado en tiempo real."
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (state.canEdit) {
                        TextButton(onClick = {
                            showAccountDialog = false
                            managementInitialTab = 5
                            currentDest = AppDestination.GESTION
                        }) {
                            Text("Administrar socios, migración y respaldos")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showAccountDialog = false
                        signOutUser(credentialManager, scope)
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Cerrar sesión")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAccountDialog = false }) { Text("Cerrar") }
            }
        )
    }
}
