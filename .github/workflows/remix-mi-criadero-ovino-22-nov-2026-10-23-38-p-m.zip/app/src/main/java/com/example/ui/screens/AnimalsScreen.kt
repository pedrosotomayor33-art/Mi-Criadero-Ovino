package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.AnimalEntity
import com.example.data.PesajeEntity
import com.example.ui.CriaderoUiState
import com.example.ui.CriaderoViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.ChileanFormatters

private enum class AnimalSortOrder(val label: String) {
    ARETE("Arete (A-Z)"),
    PESO_DESC("Mayor peso"),
    PESO_ASC("Menor peso"),
    RECIENTES("Más recientes")
}

@Composable
fun AnimalsScreen(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    selectedAnimalId: Long?,
    onSelectAnimal: (Long?) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterChip by remember { mutableStateOf("Activos") }
    var sortOrder by remember { mutableStateOf(AnimalSortOrder.ARETE) }
    var showSortMenu by remember { mutableStateOf(false) }
    var compareMode by remember { mutableStateOf(false) }
    val compareIds = remember { mutableStateListOf<Long>() }
    var showAddAnimal by remember { mutableStateOf(false) }
    var showQuickWeightFor by remember { mutableStateOf<Long?>(null) }

    val listState = rememberLazyListState()
    val fabExpanded by remember {
        derivedStateOf { listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset < 40 }
    }

    val selectedAnimal = remember(selectedAnimalId, state.animales) {
        state.animales.firstOrNull { it.id == selectedAnimalId }
    }

    if (selectedAnimal != null) {
        BackHandler { onSelectAnimal(null) }
        AnimalDetailView(
            animal = selectedAnimal,
            state = state,
            viewModel = viewModel,
            onBack = { onSelectAnimal(null) },
            onSelectRelatedAnimal = { onSelectAnimal(it) }
        )
        return
    }

    val potreroMap = remember(state.potreros) { state.potreros.associateBy { it.id } }
    val filteredAnimals = remember(state.animales, searchQuery, filterChip, sortOrder) {
        val q = searchQuery.trim().lowercase()
        val filtered = state.animales.filter { a ->
            val cat = ChileanFormatters.animalCategory(a)
            val age = ChileanFormatters.formatAge(a.fechaNacimiento)
            val matchesFilter = when (filterChip) {
                "Activos" -> a.estado == "Activo"
                "Preñadas" -> a.estado == "Activo" && a.prenada
                "Engorda" -> a.estado == "Activo" && a.proposito == "Engorda"
                "Reproductoras" -> a.estado == "Activo" && cat == "Oveja reproductora"
                "Corderos" -> a.estado == "Activo" && (cat == "Cordero" || cat == "Cordera")
                "Bajas" -> a.estado != "Activo"
                else -> true
            }
            val matchesQuery = q.isEmpty() ||
                a.arete.lowercase().contains(q) ||
                a.nombre.lowercase().contains(q) ||
                a.raza.lowercase().contains(q) ||
                a.sexo.lowercase().contains(q) ||
                a.estado.lowercase().contains(q) ||
                a.proposito.lowercase().contains(q) ||
                cat.lowercase().contains(q) ||
                age.lowercase().contains(q)
            matchesFilter && matchesQuery
        }
        when (sortOrder) {
            AnimalSortOrder.ARETE -> filtered.sortedBy { it.arete.lowercase() }
            AnimalSortOrder.PESO_DESC -> filtered.sortedByDescending { it.pesoActualKg }
            AnimalSortOrder.PESO_ASC -> filtered.sortedBy { it.pesoActualKg }
            AnimalSortOrder.RECIENTES -> filtered.sortedByDescending { it.fechaIngreso }
        }
    }

    val activeTotal = remember(state.animales) { state.animales.count { it.estado == "Activo" } }
    val filteredBiomassKg = remember(filteredAnimals) { filteredAnimals.sumOf { it.pesoActualKg } }
    val filteredHembras = remember(filteredAnimals) { filteredAnimals.count { it.sexo == "Hembra" } }
    val filteredMachos = remember(filteredAnimals) { filteredAnimals.count { it.sexo == "Macho" } }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (state.canEdit) {
                        showAddAnimal = true
                    } else {
                        viewModel.notifyMessage("Modo consulta: solo el Administrador puede añadir registros.")
                    }
                },
                expanded = fabExpanded,
                icon = {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Añadir nuevo registro"
                    )
                },
                text = {
                    Text("Nuevo animal", fontWeight = FontWeight.SemiBold)
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_animal")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Buscador rápido + selector de orden
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Limpiar búsqueda")
                            }
                        }
                    },
                    placeholder = { Text("Buscar arete, nombre, raza...") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_animals_input")
                )

                Box {
                    FilledTonalIconButton(
                        onClick = { showSortMenu = true },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("sort_animals_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Sort,
                            contentDescription = "Ordenar registros"
                        )
                    }
                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        AnimalSortOrder.entries.forEach { order ->
                            DropdownMenuItem(
                                text = { Text(order.label) },
                                leadingIcon = {
                                    if (sortOrder == order) {
                                        Icon(Icons.Filled.Check, contentDescription = null)
                                    }
                                },
                                onClick = {
                                    sortOrder = order
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                }
            }

            // Filtros + Modo Comparación de Curvas de Peso
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("Activos", "Preñadas", "Reproductoras", "Corderos", "Engorda", "Bajas", "Todos").forEach { chip ->
                    FilterChip(
                        selected = filterChip == chip,
                        onClick = { filterChip = chip },
                        label = { Text(chip) }
                    )
                }
                FilterChip(
                    selected = compareMode,
                    onClick = { compareMode = !compareMode },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.ShowChart,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = { Text("Comparar pesos") }
                )
            }

            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("animals_inventory_list")
            ) {
                // Tarjeta resumen de inventario
                item(key = "inventory_header") {
                    Surface(
                        shape = MaterialTheme.shapes.large,
                        color = Color.Transparent,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    brush = Brush.linearGradient(
                                        listOf(ForestGreen, MeadowGreen)
                                    ),
                                    shape = MaterialTheme.shapes.large
                                )
                                .padding(16.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Inventario de Animales",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "${filteredAnimals.size} registros mostrados · $activeTotal activos totales",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SoftMint
                                        )
                                    }
                                    Surface(
                                        color = Color.White.copy(alpha = 0.16f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = sortOrder.label,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    InventoryStatPill(
                                        label = "Biomasa",
                                        value = ChileanFormatters.formatKg(filteredBiomassKg),
                                        modifier = Modifier.weight(1f)
                                    )
                                    InventoryStatPill(
                                        label = "Hembras / Machos",
                                        value = "$filteredHembras H · $filteredMachos M",
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                if (compareMode) {
                    item(key = "compare_chart") {
                        val series = compareIds.mapNotNull { id ->
                            val a = state.animales.firstOrNull { it.id == id } ?: return@mapNotNull null
                            val pts = state.pesajes.filter { it.animalId == id }
                            "${a.arete} (${a.pesoActualKg}kg)" to pts
                        }
                        val avgWeight = if (filteredAnimals.isNotEmpty()) {
                            filteredAnimals.map { it.pesoActualKg }.average()
                        } else 0.0

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Comparativa de crecimiento (${compareIds.size} seleccionados) · Promedio: ${ChileanFormatters.formatKg(avgWeight)}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(6.dp))
                                WeightEvolutionChart(series = series)
                            }
                        }
                    }
                }

                if (state.isLoading) {
                    item(key = "loading_state") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                } else if (filteredAnimals.isEmpty()) {
                    item(key = "empty_state") {
                        Card(
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Pets,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                )
                                Text(
                                    text = if (state.animales.isEmpty()) {
                                        "Tu inventario está vacío"
                                    } else {
                                        "Sin coincidencias para este filtro"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (state.animales.isEmpty()) {
                                        "Presiona el botón + Nuevo animal para registrar tu primer ejemplar."
                                    } else {
                                        "Prueba limpiando la búsqueda o cambiando la categoría seleccionada."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (searchQuery.isNotEmpty() || filterChip != "Todos") {
                                    OutlinedButton(
                                        onClick = {
                                            searchQuery = ""
                                            filterChip = "Todos"
                                        }
                                    ) {
                                        Text("Mostrar todos")
                                    }
                                }
                            }
                        }
                    }
                } else {
                    items(filteredAnimals, key = { it.id }) { animal ->
                        val cat = ChileanFormatters.animalCategory(animal)
                        val potName = animal.potreroId?.let { potreroMap[it]?.nombre } ?: "Sin potrero"
                        val isSelectedForCompare = compareIds.contains(animal.id)

                        Card(
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            border = BorderStroke(
                                width = if (isSelectedForCompare) 1.5.dp else 1.dp,
                                color = if (isSelectedForCompare) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateItem()
                                .clickable {
                                    if (compareMode) {
                                        if (isSelectedForCompare) compareIds.remove(animal.id)
                                        else if (compareIds.size < 4) compareIds.add(animal.id)
                                    } else {
                                        onSelectAnimal(animal.id)
                                    }
                                }
                                .testTag("animal_card_${animal.arete}")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (compareMode) {
                                    Checkbox(
                                        checked = isSelectedForCompare,
                                        onCheckedChange = { checked ->
                                            if (checked && compareIds.size < 4) compareIds.add(animal.id)
                                            else compareIds.remove(animal.id)
                                        }
                                    )
                                }
                                AnimalAvatar(animal = animal, sizeDp = 52)
                                Spacer(Modifier.width(12.dp))
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = animal.arete,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        if (animal.nombre.isNotBlank()) {
                                            Text(
                                                text = "· ${animal.nombre}",
                                                style = MaterialTheme.typography.titleSmall,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                        }
                                        if (animal.prenada) {
                                            Surface(
                                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = "Preñada",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        } else if (animal.estado != "Activo") {
                                            Surface(
                                                color = MaterialTheme.colorScheme.errorContainer,
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = animal.estado,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = "$cat · ${animal.raza} · ${ChileanFormatters.formatAge(animal.fechaNacimiento)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "$potName · ${animal.proposito}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.secondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = ChileanFormatters.formatKg(animal.pesoActualKg),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (state.canEdit && animal.estado == "Activo" && !compareMode) {
                                        TextButton(
                                            onClick = { showQuickWeightFor = animal.id },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Text("Pesar", style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAnimal) {
        QuickAnimalDialog(state = state, viewModel = viewModel) { showAddAnimal = false }
    }
    showQuickWeightFor?.let { targetId ->
        QuickWeightDialog(preselectedAnimalId = targetId, state = state, viewModel = viewModel) {
            showQuickWeightFor = null
        }
    }
}

@Composable
private fun InventoryStatPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White.copy(alpha = 0.14f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = SoftMint,
                maxLines = 1
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun AnimalDetailView(
    animal: AnimalEntity,
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onBack: () -> Unit,
    onSelectRelatedAnimal: (Long) -> Unit
) {
    var activeTab by remember { mutableIntStateOf(0) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showWeightDialog by remember { mutableStateOf(false) }
    var showSanidadDialog by remember { mutableStateOf(false) }
    var showBajaDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var previewDiseasePhoto by remember { mutableStateOf<Pair<OvineDiseaseType, String>?>(null) }

    val animalById = remember(state.animales) { state.animales.associateBy { it.id } }
    val madre = animal.madreId?.let { animalById[it] }
    val padre = animal.padreId?.let { animalById[it] }
    val hijos = remember(state.animales, animal.id) {
        state.animales.filter { it.madreId == animal.id || it.padreId == animal.id }
    }
    val animalPesajes = remember(state.pesajes, animal.id) {
        state.pesajes.filter { it.animalId == animal.id }.sortedBy { it.fecha }
    }
    val weightStats = remember(animal, animalPesajes) {
        viewModel.repo.calculateWeightStats(animal, animalPesajes)
    }
    val animalSanidad = remember(state.sanidad, animal.id) {
        state.sanidad.filter { it.animalId == animal.id }
    }
    val potrero = animal.potreroId?.let { pid -> state.potreros.firstOrNull { it.id == pid } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Cabecera rápida con acciones de campo
        Surface(tonalElevation = 2.dp, color = MaterialTheme.colorScheme.surface) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver a la lista")
                    }
                    AnimalAvatar(animal = animal, sizeDp = 52)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${animal.arete} ${if (animal.nombre.isNotBlank()) "· ${animal.nombre}" else ""}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${ChileanFormatters.animalCategory(animal)} · ${animal.raza} · ${ChileanFormatters.formatAge(animal.fechaNacimiento)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (state.canEdit) {
                        IconButton(onClick = { showEditDialog = true }) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Editar ficha")
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    if (state.canEdit && animal.estado == "Activo") {
                        Button(
                            onClick = { showWeightDialog = true },
                            modifier = Modifier.weight(1f).testTag("detail_quick_weight")
                        ) {
                            Icon(Icons.Filled.MonitorWeight, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Pesar ahora")
                        }
                        OutlinedButton(
                            onClick = { showSanidadDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.MedicalServices, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Tratamiento")
                        }
                    }
                }
            }
        }

        TabRow(selectedTabIndex = activeTab) {
            listOf("Ficha", "Pesajes", "Genealogía", "Sanidad").forEachIndexed { idx, title ->
                Tab(
                    selected = activeTab == idx,
                    onClick = { activeTab = idx },
                    text = { Text(title, maxLines = 1) }
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            when (activeTab) {
                0 -> { // FICHA
                    item {
                        if (animal.prenada) {
                            Surface(
                                color = TerracottaSoft,
                                shape = MaterialTheme.shapes.medium,
                                border = BorderStroke(1.dp, EarthTerracotta)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.ChildFriendly, contentDescription = null, tint = EarthTerracotta)
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text("Hembra Preñada", fontWeight = FontWeight.Bold, color = SaddleBrown)
                                        Text(
                                            text = animal.fechaProbableParto?.let {
                                                "Fecha probable de parto: ${ChileanFormatters.formatDate(it)}"
                                            } ?: "Gestación confirmada",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SaddleBrown
                                        )
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                InfoRow("Estado", animal.estado)
                                InfoRow("Propósito", animal.proposito)
                                InfoRow("Potrero actual", potrero?.nombre ?: "Sin asignar")
                                InfoRow("Sexo / Nacimiento", "${animal.sexo} (${animal.tipoNacimiento})")
                                InfoRow("Fecha nacimiento", ChileanFormatters.formatDate(animal.fechaNacimiento))
                                InfoRow("Peso nacimiento", ChileanFormatters.formatKg(animal.pesoNacimientoKg))
                                InfoRow("Peso actual", ChileanFormatters.formatKg(animal.pesoActualKg))
                                InfoRow("Crías registradas", "${hijos.size}")
                                InfoRow("Destetado", if (animal.destetado) "Sí" else "Al pie / No")
                                InfoRow("Predio origen", animal.predioOrigen)
                                if (animal.observaciones.isNotBlank()) {
                                    HorizontalDivider()
                                    Text("Observaciones:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(animal.observaciones, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                    if (state.canEdit) {
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { showBajaDialog = true },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Dar de baja / Venta")
                                }
                                OutlinedButton(
                                    onClick = { showDeleteConfirm = true },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonAlert),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Eliminar")
                                }
                            }
                        }
                    }
                }
                1 -> { // PESAJES & CRECIMIENTO
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            KpiMetricCard(
                                title = "GMD",
                                value = weightStats.gmdGramsPerDay?.let { "${it.toInt()} g/d" } ?: "—",
                                subtitle = weightStats.gananciaUltimoPesajeKg?.let { "Último: +${ChileanFormatters.formatKg(it)}" },
                                icon = Icons.Outlined.Speed,
                                modifier = Modifier.weight(1f)
                            )
                            KpiMetricCard(
                                title = "Ganancia total",
                                value = ChileanFormatters.formatKg(weightStats.gananciaTotalNacimientoKg),
                                subtitle = weightStats.proyeccion30DiasKg?.let { "Proy. 30d: ${ChileanFormatters.formatKg(it)}" },
                                icon = Icons.Outlined.TrendingUp,
                                accentColor = MeadowGreen,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Curva de crecimiento individual", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                WeightEvolutionChart(series = listOf(animal.arete to animalPesajes))
                            }
                        }
                    }
                    items(animalPesajes.reversed(), key = { it.id }) { p ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ChileanFormatters.formatDate(p.fecha), fontWeight = FontWeight.SemiBold)
                                    Text("Edad: ${p.edadDias} días · ${p.observaciones.ifBlank { "Control" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(ChileanFormatters.formatKg(p.pesoKg), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestGreen)
                                if (state.canEdit) {
                                    IconButton(onClick = { viewModel.deletePesaje(p) }) {
                                        Icon(Icons.Outlined.Delete, contentDescription = "Eliminar pesaje", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> { // GENEALOGÍA
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Árbol Genealógico", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                ParentNodeCard("Madre", madre, onClick = { madre?.let { onSelectRelatedAnimal(it.id) } })
                                ParentNodeCard("Padre", padre, onClick = { padre?.let { onSelectRelatedAnimal(it.id) } })
                                HorizontalDivider()
                                Text("Descendencia directa (${hijos.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                if (hijos.isEmpty()) {
                                    Text("Sin crías registradas aún.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else {
                                    hijos.forEach { hijo ->
                                        ParentNodeCard("${hijo.sexo} · ${ChileanFormatters.formatKg(hijo.pesoActualKg)}", hijo) {
                                            onSelectRelatedAnimal(hijo.id)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> { // SANIDAD
                    if (animalSanidad.isEmpty()) {
                        item {
                            Text("Sin tratamientos o manejos sanitarios individuales registrados.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        items(animalSanidad, key = { it.id }) { s ->
                            val diseaseType = OvineDiseaseType.resolve(s)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    DiseaseThumbnail(
                                        diseaseType = diseaseType,
                                        size = 72.dp,
                                        onClick = { previewDiseasePhoto = diseaseType to s.diagnostico }
                                    )
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(
                                                text = "${s.tipoManejo}: ${s.diagnostico}",
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Text(s.evolucion, style = MaterialTheme.typography.labelSmall, color = MeadowGreen)
                                        }
                                        Surface(
                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = diseaseType.shortTitle,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Text("${ChileanFormatters.formatDate(s.fecha)} · ${s.medicamento} (${s.dosis} ${s.unidadDosis} ${s.viaAdministracion})", style = MaterialTheme.typography.bodySmall)
                                        if (s.observaciones.isNotBlank()) Text(s.observaciones, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditDialog) QuickAnimalDialog(initialAnimal = animal, state = state, viewModel = viewModel) { showEditDialog = false }
    if (showWeightDialog) QuickWeightDialog(preselectedAnimalId = animal.id, state = state, viewModel = viewModel) { showWeightDialog = false }
    if (showSanidadDialog) QuickSanidadDialog(preselectedAnimalId = animal.id, state = state, viewModel = viewModel) { showSanidadDialog = false }
    previewDiseasePhoto?.let { (type, diag) ->
        DiseasePhotoPreviewDialog(diseaseType = type, diagnostico = diag) {
            previewDiseasePhoto = null
        }
    }
    if (showBajaDialog) {
        var estadoSel by remember { mutableStateOf("Venta") }
        var motivo by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showBajaDialog = false },
            title = { Text("Dar de baja / Egreso") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DropdownField(
                        label = "Nuevo estado",
                        selectedText = estadoSel,
                        options = listOf("Venta", "Muerte", "Consumo", "Descarte"),
                        onSelect = { estadoSel = listOf("Venta", "Muerte", "Consumo", "Descarte")[it] }
                    )
                    OutlinedTextField(value = motivo, onValueChange = { motivo = it }, label = { Text("Motivo o detalle") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.darDeBajaAnimal(animal, estadoSel, motivo)
                    showBajaDialog = false
                }) { Text("Confirmar") }
            },
            dismissButton = { TextButton(onClick = { showBajaDialog = false }) { Text("Cancelar") } }
        )
    }
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("¿Eliminar ficha permanente?") },
            text = { Text("Se eliminará el registro de ${animal.arete}. Esta acción no se puede deshacer.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                    onClick = {
                        viewModel.deleteAnimal(animal) {
                            showDeleteConfirm = false
                            onBack()
                        }
                    }
                ) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ParentNodeCard(role: String, animal: AnimalEntity?, onClick: () -> Unit) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = animal != null, onClick = onClick)
    ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.AccountTree, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(role, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    text = animal?.let { "${it.arete} · ${it.nombre.ifBlank { it.raza }}" } ?: "No registrado",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (animal != null) {
                Icon(Icons.Filled.ChevronRight, contentDescription = "Ver ficha")
            }
        }
    }
}
