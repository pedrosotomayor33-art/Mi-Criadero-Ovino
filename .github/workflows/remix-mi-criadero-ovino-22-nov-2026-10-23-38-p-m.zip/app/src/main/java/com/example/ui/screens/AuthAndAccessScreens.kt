package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.auth.attemptAutoSignIn
import com.example.auth.onGoogleSignInClicked
import com.example.data.CloudSchema
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    credentialManager: CredentialManager,
    onAuthenticated: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isBusy by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isBusy = false
                onAuthenticated()
            },
            onUnauthenticated = {
                isBusy = false
            },
            scope = scope
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.background,
                        SoftMint.copy(alpha = 0.45f)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 24.dp)
                .widthIn(max = 520.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_sheep_logo),
                contentDescription = "Logotipo Mi Criadero Ovino",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(24.dp))
            )

            Spacer(Modifier.height(16.dp))

            Text(
                text = "Mi Criadero Ovino",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = ForestGreen,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Sistema multiusuario sincronizado en tiempo real",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(24.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AuthFeatureRow(
                        icon = Icons.Outlined.CloudSync,
                        title = "Sincronización en vivo en 3 teléfonos",
                        subtitle = "Cualquier cambio del Administrador se refleja automáticamente en los equipos de ambos socios."
                    )
                    AuthFeatureRow(
                        icon = Icons.Outlined.AdminPanelSettings,
                        title = "Seguridad real por cuenta Google",
                        subtitle = "Administrador verificado con control total del criadero y hasta 2 Socios en modo solo consulta validado en servidor."
                    )
                    AuthFeatureRow(
                        icon = Icons.Outlined.OfflinePin,
                        title = "Consulta sin conexión y respaldos",
                        subtitle = "Accede al rebaño sin señal en terreno, registra historial de auditoría y protege datos con Papelera y respaldos."
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            if (!errorMessage.isNullOrBlank()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CrimsonSoft),
                    border = BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = CrimsonAlert)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonAlert
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            Button(
                onClick = {
                    errorMessage = null
                    isBusy = true
                    onGoogleSignInClicked(
                        context = context,
                        credentialManager = credentialManager,
                        onAuthSuccess = {
                            isBusy = false
                            onAuthenticated()
                        },
                        onAuthError = { msg ->
                            isBusy = false
                            errorMessage = msg
                        },
                        scope = scope,
                        onAuthCancelled = {
                            isBusy = false
                        }
                    )
                },
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("google_sign_in_button")
            ) {
                if (isBusy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Verificando cuenta Google...")
                } else {
                    Icon(Icons.Filled.Login, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Text("Iniciar sesión con Google", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                text = "Cada usuario debe ingresar con su cuenta Google personal en su propio teléfono.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun AuthFeatureRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, contentDescription = null, tint = ForestGreen, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun InitialCriaderoSetupScreen(
    userEmail: String,
    criaderoId: String,
    configuredInitialAdminEmail: String,
    statusMessage: String,
    isLoading: Boolean,
    onCreateWorkspace: (nombrePredio: String, socio1Email: String, socio2Email: String) -> Unit,
    onSwitchCriaderoId: (String) -> Unit,
    onRetry: () -> Unit,
    onSignOut: () -> Unit
) {
    var nombrePredio by remember { mutableStateOf("Fundo Santa Elena · Biobío") }
    var socio1 by remember { mutableStateOf("") }
    var socio2 by remember { mutableStateOf("") }
    var customCriaderoId by remember(criaderoId) { mutableStateOf(criaderoId) }

    val cleanEmail = userEmail.trim().lowercase()
    val canInitializeAsAdmin = configuredInitialAdminEmail.isBlank() || configuredInitialAdminEmail == cleanEmail

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
                .widthIn(max = 540.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.AdminPanelSettings,
                contentDescription = "Configuración inicial",
                tint = ForestGreen,
                modifier = Modifier.size(56.dp)
            )
            Text(
                text = "Configuración Inicial del Criadero",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Cuenta conectada: $userEmail · Criadero: $criaderoId",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            if (statusMessage.isNotBlank()) {
                Text(
                    text = statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = EarthTerracotta,
                    textAlign = TextAlign.Center
                )
            }

            if (canInitializeAsAdmin) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "1. Si eres el Administrador principal",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = ForestGreen
                        )
                        Text(
                            text = "Quedarás registrado de forma exclusiva como Administrador con control total y podrás invitar o transferir la administración después.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedTextField(
                            value = nombrePredio,
                            onValueChange = { nombrePredio = it },
                            label = { Text("Nombre del predio / criadero") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = socio1,
                            onValueChange = { socio1 = it },
                            label = { Text("Correo Google Socio 1 (opcional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = socio2,
                            onValueChange = { socio2 = it },
                            label = { Text("Correo Google Socio 2 (opcional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = { onCreateWorkspace(nombrePredio, socio1, socio2) },
                            enabled = !isLoading && nombrePredio.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("initialize_admin_workspace_button")
                        ) {
                            Icon(Icons.Filled.VerifiedUser, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Crear criadero como Administrador")
                        }
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AmberSoft.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, EarthTerracotta.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Creación inicial reservada", fontWeight = FontWeight.Bold, color = SaddleBrown)
                        Text(
                            text = "Esta compilación exige que el Administrador inicial inicie sesión con la cuenta configurada ($configuredInitialAdminEmail).",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "2. Si eres Socio invitado",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Pide al Administrador que inicialice primero el criadero y agregue tu correo, o ingresa aquí otro código de criadero si usan uno personalizado.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = customCriaderoId,
                        onValueChange = { customCriaderoId = it },
                        label = { Text("Código de criadero") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { onSwitchCriaderoId(customCriaderoId) },
                            enabled = customCriaderoId.isNotBlank() && !isLoading,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Conectar código")
                        }
                        OutlinedButton(
                            onClick = onRetry,
                            enabled = !isLoading,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Reverificar")
                        }
                    }
                }
            }

            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión o cambiar de cuenta")
            }
        }
    }
}

@Composable
fun PendingAdminTransferScreen(
    userEmail: String,
    predioNombre: String,
    currentAdminEmail: String,
    statusMessage: String,
    isLoading: Boolean,
    onAcceptTransfer: () -> Unit,
    onRetry: () -> Unit,
    onSignOut: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .widthIn(max = 520.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.SwapHoriz,
                contentDescription = "Traspaso de Administrador",
                tint = ForestGreen,
                modifier = Modifier.size(64.dp)
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = "Traspaso de Administración Pendiente",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = statusMessage,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = SoftMint.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Criadero: $predioNombre", fontWeight = FontWeight.Bold)
                    Text("Administrador actual: $currentAdminEmail", style = MaterialTheme.typography.bodySmall)
                    Text("Nuevo Administrador: $userEmail", style = MaterialTheme.typography.bodySmall, color = ForestGreen)
                }
            }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onAcceptTransfer,
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("accept_admin_transfer_button")
            ) {
                Icon(Icons.Filled.VerifiedUser, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Aceptar rol de Administrador Principal")
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onRetry, enabled = !isLoading, modifier = Modifier.fillMaxWidth()) {
                Text("Verificar estado")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión")
            }
        }
    }
}

@Composable
fun PendingAccessScreen(
    userEmail: String,
    criaderoId: String,
    statusMessage: String,
    isLoading: Boolean,
    onSwitchCriaderoId: (String) -> Unit,
    onRetry: () -> Unit,
    onSignOut: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var targetCriaderoId by remember(criaderoId) { mutableStateOf(criaderoId) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
                .widthIn(max = 520.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.LockPerson,
                contentDescription = "Acceso pendiente",
                tint = EarthTerracotta,
                modifier = Modifier.size(64.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Acceso pendiente de autorización",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = statusMessage.ifBlank {
                    "Tu cuenta aún no está vinculada al criadero."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cuenta conectada:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(userEmail.ifBlank { "Sin correo" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestGreen)
                    Text(
                        text = "Pide al Administrador del criadero '$criaderoId' que registre exactamente este correo en Gestión → Equipo y Nube como Socio 1 o Socio 2.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = targetCriaderoId,
                        onValueChange = { targetCriaderoId = it },
                        label = { Text("Código de criadero") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (targetCriaderoId.trim() != criaderoId) {
                        OutlinedButton(
                            onClick = { onSwitchCriaderoId(targetCriaderoId) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Cambiar a criadero '${targetCriaderoId.trim()}'")
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { scope.launch { onRetry() } },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("retry_access_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                } else {
                    Icon(Icons.Filled.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Verificar acceso nuevamente")
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pending_sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión o cambiar de cuenta")
            }
        }
    }
}
