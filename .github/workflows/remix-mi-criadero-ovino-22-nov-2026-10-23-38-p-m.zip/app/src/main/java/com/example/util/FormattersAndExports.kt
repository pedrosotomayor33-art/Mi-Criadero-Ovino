package com.example.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.AnimalEntity
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

object ChileanFormatters {
    private val localeCl = Locale("es", "CL")
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", localeCl)
    private val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", localeCl)
    private val currencyFormat = NumberFormat.getCurrencyInstance(localeCl).apply {
        maximumFractionDigits = 0
    }

    fun formatDate(millis: Long): String = dateFormat.format(Date(millis))

    fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))

    fun formatClp(amount: Double): String = currencyFormat.format(amount)

    fun formatKg(kg: Double): String = String.format(localeCl, "%.1f kg", kg)

    fun formatNumber(num: Double, decimals: Int = 1): String =
        String.format(localeCl, "%.${decimals}f", num)

    fun formatAge(fechaNacimiento: Long, now: Long = System.currentTimeMillis()): String {
        val totalDays = max(0L, (now - fechaNacimiento) / 86_400_000L)
        return when {
            totalDays < 30 -> "$totalDays d"
            totalDays < 365 -> "${totalDays / 30} m"
            else -> {
                val years = totalDays / 365
                val months = (totalDays % 365) / 30
                if (months > 0) "${years}a ${months}m" else "${years} años"
            }
        }
    }

    fun animalCategory(animal: AnimalEntity, now: Long = System.currentTimeMillis()): String {
        val days = max(0L, (now - animal.fechaNacimiento) / 86_400_000L)
        return when {
            days < 180 -> if (animal.sexo == "Macho") "Cordero" else "Cordera"
            days < 365 -> if (animal.sexo == "Macho") "Borrego" else "Borrega"
            animal.sexo == "Macho" -> "Carnero"
            else -> "Oveja reproductora"
        }
    }
}

object ReportExporter {

    fun shareCsvReport(
        context: Context,
        title: String,
        headers: List<String>,
        rows: List<List<String>>
    ): Result<Unit> = runCatching {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = title.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')
        val file = File(dir, "${safeName}_${System.currentTimeMillis()}.csv")

        val sb = StringBuilder()
        // UTF-8 BOM para compatibilidad directa con Microsoft Excel en español
        sb.append('\uFEFF')
        sb.append(headers.joinToString(";") { escapeCsv(it) }).append("\n")
        rows.forEach { row ->
            sb.append(row.joinToString(";") { escapeCsv(it) }).append("\n")
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
        shareFile(context, file, "text/csv", "Exportar Excel / CSV: $title")
    }

    fun sharePdfReport(
        context: Context,
        predioNombre: String,
        title: String,
        summaryLines: List<String>,
        headers: List<String>,
        rows: List<List<String>>
    ): Result<Unit> = runCatching {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = title.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')
        val file = File(dir, "${safeName}_${System.currentTimeMillis()}.pdf")

        val pdf = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.parseColor("#1B4332")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint().apply {
            color = Color.parseColor("#4A5D52")
            textSize = 10f
        }
        val headerPaint = Paint().apply {
            color = Color.parseColor("#1B4332")
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#1A241E")
            textSize = 9.5f
        }
        val linePaint = Paint().apply {
            color = Color.parseColor("#D8F3DC")
            strokeWidth = 1.5f
        }

        var y = 44f
        canvas.drawText("MI CRIADERO OVINO · $predioNombre", 36f, y, subPaint)
        y += 22f
        canvas.drawText(title, 36f, y, titlePaint)
        y += 14f
        canvas.drawText("Generado: ${ChileanFormatters.formatDateTime(System.currentTimeMillis())}", 36f, y, subPaint)
        y += 12f
        canvas.drawLine(36f, y, pageWidth - 36f, y, linePaint)
        y += 18f

        summaryLines.forEach { line ->
            canvas.drawText("• $line", 36f, y, bodyPaint)
            y += 15f
        }
        y += 10f

        val colCount = max(1, headers.size)
        val colWidth = (pageWidth - 72f) / colCount

        fun drawTableHeaders() {
            headers.forEachIndexed { idx, h ->
                canvas.drawText(h.take(18), 36f + idx * colWidth, y, headerPaint)
            }
            y += 8f
            canvas.drawLine(36f, y, pageWidth - 36f, y, linePaint)
            y += 14f
        }

        drawTableHeaders()

        rows.forEach { row ->
            if (y > pageHeight - 48f) {
                pdf.finishPage(page)
                pageNum++
                page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                canvas = page.canvas
                y = 44f
                drawTableHeaders()
            }
            row.forEachIndexed { idx, cell ->
                canvas.drawText(cell.take(20), 36f + idx * colWidth, y, bodyPaint)
            }
            y += 15f
        }

        pdf.finishPage(page)
        FileOutputStream(file).use { out -> pdf.writeTo(out) }
        pdf.close()

        shareFile(context, file, "application/pdf", "Exportar PDF: $title")
    }

    fun shareJsonBackup(context: Context, jsonContent: String): Result<Unit> = runCatching {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "respaldo_criadero_${System.currentTimeMillis()}.json")
        file.writeText(jsonContent, Charsets.UTF_8)
        shareFile(context, file, "application/json", "Respaldo completo Mi Criadero Ovino")
    }

    fun shareEncryptedBackup(context: Context, encryptedContent: String): Result<Unit> = runCatching {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "respaldo_cifrado_${System.currentTimeMillis()}.mco.json")
        file.writeText(encryptedContent, Charsets.UTF_8)
        shareFile(context, file, "application/json", "Respaldo cifrado (AES-256-GCM) Mi Criadero Ovino")
    }

    private fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newUri(context.contentResolver, chooserTitle, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, chooserTitle).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(chooser)
    }

    private fun escapeCsv(value: String): String {
        val cleaned = value.replace("\"", "\"\"").replace("\n", " ")
        return "\"$cleaned\""
    }
}
