package com.example.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.util.ChileanFormatters
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

data class DashboardKpis(
    val totalOvinos: Int = 0,
    val ovejasReproductoras: Int = 0,
    val carneros: Int = 0,
    val corderos: Int = 0,
    val enEngorda: Int = 0,
    val hembrasPrenadas: Int = 0,
    val hembrasVacias: Int = 0,
    val nacimientosAnio: Int = 0,
    val mortalidadAnual: Int = 0,
    val enTratamiento: Int = 0,
    val proximosPartosCount: Int = 0,
    val proximosManejosCount: Int = 0,
    val kilosTotalesRebano: Double = 0.0,
    val kilosProducidosMes: Double = 0.0
)

data class CriaderoUiState(
    val isLoading: Boolean = true,
    val predioNombre: String = "Fundo Santa Elena · Biobío",
    val themeMode: String = "SYSTEM",
    val cloudSession: CloudAccessSession = CloudAccessSession(),
    val isOnline: Boolean = true,
    val isSyncPendingWrites: Boolean = false,
    val isFromCache: Boolean = false,
    val syncErrorMessage: String? = null,
    val members: List<CriaderoMember> = emptyList(),
    val activeUser: UserAccountEntity? = null,
    val canEdit: Boolean = false,
    val localPendingMigrationCount: Int = 0,
    val isMigrating: Boolean = false,
    val isBackingUp: Boolean = false,
    val animales: List<AnimalEntity> = emptyList(),
    val pesajes: List<PesajeEntity> = emptyList(),
    val encastes: List<EncasteEntity> = emptyList(),
    val gestaciones: List<GestacionEntity> = emptyList(),
    val partos: List<PartoEntity> = emptyList(),
    val sanidad: List<SanidadEntity> = emptyList(),
    val potreros: List<PotreroEntity> = emptyList(),
    val movimientosPotrero: List<MovimientoPotreroEntity> = emptyList(),
    val raciones: List<AlimentoRacionEntity> = emptyList(),
    val inventario: List<InventarioItemEntity> = emptyList(),
    val movimientosInventario: List<MovimientoInventarioEntity> = emptyList(),
    val transacciones: List<TransaccionEconomicaEntity> = emptyList(),
    val lotes: List<LoteEntity> = emptyList(),
    val destetes: List<DesteteEntity> = emptyList(),
    val auditLogs: List<AuditLogEntry> = emptyList(),
    val backups: List<CloudBackupSnapshot> = emptyList(),
    val deletedRecords: List<DeletedRecordItem> = emptyList(),
    val alertas: List<AlertaCriadero> = emptyList(),
    val kpis: DashboardKpis = DashboardKpis()
)

@OptIn(ExperimentalCoroutinesApi::class)
class CriaderoViewModel(
    appContext: Context,
    firestore: FirebaseFirestore,
    private val roomDb: CriaderoDatabase,
    private val prefs: SessionPreferences,
    networkMonitor: NetworkMonitor,
    private val firebaseUser: FirebaseUser,
    val criaderoId: String = CloudSchema.DEFAULT_CRIADERO_ID
) : ViewModel() {

    private val context = appContext.applicationContext
    val repo = CriaderoRepository(roomDb)
    private val cloudRepo = CloudCriaderoRepository(firestore, firebaseUser, criaderoId)
    private val migrationService = CloudMigrationAndBackupService(cloudRepo)

    private val _snackbarMessage = MutableSharedFlow<String>(extraBufferCapacity = 12)
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    private val _accessState = MutableStateFlow(CloudAccessSession(isLoading = true, criaderoId = criaderoId))
    private val _syncError = MutableStateFlow<String?>(null)
    private val _isMigrating = MutableStateFlow(false)
    private val _isBackingUp = MutableStateFlow(false)
    private var lastSyncedMemberUids: Set<String> = emptySet()

    init {
        retryAccessResolution()
    }

    private fun formatSyncErrorMessage(error: Throwable): String {
        val fsError = unwrapFirestoreException(error)
        return when (fsError?.code) {
            FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                "Sin permisos suficientes para acceder a los datos del criadero en la nube."
            FirebaseFirestoreException.Code.UNAVAILABLE ->
                "Sin conexión con el servidor en la nube. Mostrando datos en caché local."
            else -> fsError?.localizedMessage
                ?: error.localizedMessage
                ?: "Error al sincronizar con la nube."
        }
    }

    fun retryAccessResolution() {
        viewModelScope.launch {
            _accessState.update { it.copy(isLoading = true) }
            cloudRepo.resolveAndInitializeAccess()
                .onSuccess { session ->
                    _accessState.value = session
                    _syncError.value = null
                }
                .onFailure { err ->
                    val message = formatSyncErrorMessage(err)
                    _syncError.value = message
                    _accessState.value = CloudAccessSession(
                        isLoading = false,
                        isAuthorized = false,
                        isAdmin = false,
                        criaderoId = criaderoId,
                        statusMessage = message
                    )
                }
        }
    }

    fun initializeWorkspaceAsAdmin(
        nombrePredio: String,
        socio1Email: String,
        socio2Email: String
    ) {
        viewModelScope.launch {
            _accessState.update { it.copy(isLoading = true) }
            cloudRepo.initializeWorkspaceAsAdmin(nombrePredio, socio1Email, socio2Email)
                .onSuccess { session ->
                    _accessState.value = session
                    _syncError.value = null
                    prefs.setPredioNombre(nombrePredio)
                }
                .onFailure { err ->
                    val msg = err.message ?: formatSyncErrorMessage(err)
                    _accessState.update { it.copy(isLoading = false, statusMessage = msg) }
                }
        }
    }

    fun acceptAdminTransfer() {
        viewModelScope.launch {
            _accessState.update { it.copy(isLoading = true) }
            cloudRepo.acceptAdminTransfer()
                .onSuccess { session ->
                    _accessState.value = session
                    _syncError.value = null
                }
                .onFailure { err ->
                    val msg = err.message ?: formatSyncErrorMessage(err)
                    _accessState.update { it.copy(isLoading = false, statusMessage = msg) }
                }
        }
    }

    fun switchCriaderoId(newCriaderoId: String) {
        viewModelScope.launch {
            prefs.setCriaderoId(newCriaderoId)
        }
    }

    private fun <T> authorizedFlow(defaultValue: T, flowFactory: () -> Flow<T>): Flow<T> =
        _accessState
            .map { it.isAuthorized }
            .distinctUntilChanged()
            .flatMapLatest { authorized ->
                if (!authorized) flowOf(defaultValue)
                else flowFactory().catch { e ->
                    val fsError = unwrapFirestoreException(e)
                    if (fsError == null && e is CancellationException) throw e
                    handleFirestoreError(fsError ?: e, OperationType.LIST, "${CloudSchema.COL_CRIADEROS}/${cloudRepo.criaderoId}")
                    _syncError.value = formatSyncErrorMessage(e)
                    emit(defaultValue)
                }
            }

    private val workspaceBundleFlow = authorizedFlow(CloudSnapshotBundle()) {
        cloudRepo.observeWorkspace()
    }

    private val animalesSyncMetaFlow = authorizedFlow(SyncMetadataSnapshot()) {
        cloudRepo.observeAnimalesPendingWrites()
    }

    private val currentMemberFlow = authorizedFlow<CriaderoMember?>(null) {
        cloudRepo.observeCurrentMember()
    }

    private val membersFlow = _accessState
        .map { it.isAuthorized && it.isAdmin }
        .distinctUntilChanged()
        .flatMapLatest { isAdmin ->
            if (!isAdmin) flowOf(emptyList())
            else cloudRepo.observeMembersForAdmin(cloudRepo.currentUid).catch { e ->
                val fsError = unwrapFirestoreException(e)
                if (fsError == null && e is CancellationException) throw e
                handleFirestoreError(fsError ?: e, OperationType.LIST, "${CloudSchema.COL_CRIADEROS}/${cloudRepo.criaderoId}/${CloudSchema.SUB_MEMBERS}")
                _syncError.value = formatSyncErrorMessage(e)
                emit(emptyList())
            }
        }

    private val animalesDtoFlow = authorizedFlow(emptyList<CloudAnimalDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_ANIMALES)
    }
    private val pesajesDtoFlow = authorizedFlow(emptyList<CloudPesajeDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_PESAJES)
    }
    private val encastesDtoFlow = authorizedFlow(emptyList<CloudEncasteDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_ENCASTES)
    }
    private val gestacionesDtoFlow = authorizedFlow(emptyList<CloudGestacionDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_GESTACIONES)
    }
    private val partosDtoFlow = authorizedFlow(emptyList<CloudPartoDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_PARTOS)
    }
    private val sanidadDtoFlow = authorizedFlow(emptyList<CloudSanidadDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_SANIDAD)
    }
    private val potrerosDtoFlow = authorizedFlow(emptyList<CloudPotreroDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_POTREROS)
    }
    private val movPotreroDtoFlow = authorizedFlow(emptyList<CloudMovimientoPotreroDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_MOV_POTRERO)
    }
    private val racionesDtoFlow = authorizedFlow(emptyList<CloudRacionDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_RACIONES)
    }
    private val inventarioDtoFlow = authorizedFlow(emptyList<CloudInventarioItemDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_INVENTARIO)
    }
    private val movInvDtoFlow = authorizedFlow(emptyList<CloudMovimientoInventarioDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_MOV_INVENTARIO)
    }
    private val txDtoFlow = authorizedFlow(emptyList<CloudTransaccionDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_TRANSACCIONES)
    }
    private val lotesDtoFlow = authorizedFlow(emptyList<CloudLoteDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_LOTES)
    }
    private val destetesDtoFlow = authorizedFlow(emptyList<CloudDesteteDto>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_DESTETES)
    }
    private val auditLogsFlow = authorizedFlow(emptyList<AuditLogEntry>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_AUDIT_LOGS)
    }
    private val backupsFlow = authorizedFlow(emptyList<CloudBackupSnapshot>()) {
        cloudRepo.observeSubcollection(CloudSchema.SUB_BACKUPS)
    }

    private val localCountFlow = repo.animales.map { it.size }.catch { emit(0) }

    // Trigger automatic propagation of memberUids when Admin observes a newly joined partner
    init {
        viewModelScope.launch {
            workspaceBundleFlow.collect { bundle ->
                val ws = bundle.workspace ?: return@collect
                if (ws.adminUid == cloudRepo.currentUid) {
                    val uidSet = ws.memberUids.toSet()
                    if (uidSet.size > 1 && uidSet != lastSyncedMemberUids) {
                        lastSyncedMemberUids = uidSet
                        cloudRepo.syncMemberUidsAcrossFarm(ws.memberUids)
                    }
                }
            }
        }
    }

    private val coreBundleFlow = combine(
        animalesDtoFlow, pesajesDtoFlow, encastesDtoFlow, gestacionesDtoFlow, partosDtoFlow
    ) { a, p, e, g, pa -> CoreCloudBundle(a, p, e, g, pa) }

    private val farmBundleFlow = combine(
        sanidadDtoFlow, potrerosDtoFlow, movPotreroDtoFlow, racionesDtoFlow, inventarioDtoFlow
    ) { s, po, mp, r, inv -> FarmCloudBundle(s, po, mp, r, inv) }

    private val financeBundleFlow = combine(
        movInvDtoFlow, txDtoFlow, lotesDtoFlow, destetesDtoFlow, auditLogsFlow
    ) { mi, tx, l, d, au -> FinanceCloudBundle(mi, tx, l, d, au) }

    private val sessionMetaFlow = combine(
        _accessState,
        workspaceBundleFlow,
        currentMemberFlow,
        membersFlow,
        backupsFlow
    ) { acc, wsBundle, curMember, mems, bkps ->
        SessionMetaBundle(acc, wsBundle, curMember, mems, bkps)
    }

    private val systemStatusFlow = combine(
        combine(prefs.themeModeFlow, networkMonitor.isOnlineFlow, _syncError) { theme, online, err ->
            Triple(theme, online, err)
        },
        combine(localCountFlow, _isMigrating, _isBackingUp) { localCount, migrating, backingUp ->
            Triple(localCount, migrating, backingUp)
        },
        animalesSyncMetaFlow
    ) { (theme, online, err), (localCount, migrating, backingUp), animalesMeta ->
        SystemStatusBundle(
            themeMode = theme,
            isOnline = online,
            syncError = err,
            localCount = localCount,
            isMigrating = migrating,
            isBackingUp = backingUp,
            animalesPendingWrites = animalesMeta.hasPendingWrites,
            animalesFromCache = animalesMeta.isFromCache
        )
    }

    val uiState: StateFlow<CriaderoUiState> = combine(
        coreBundleFlow,
        farmBundleFlow,
        financeBundleFlow,
        sessionMetaFlow,
        systemStatusFlow
    ) { core, farm, fin, meta, sys ->
        val ws = meta.wsBundle.workspace ?: meta.access.workspace
        val member = meta.currentMember ?: meta.access.currentMember
        val isVerifiedWorkspaceAdmin = ws?.adminUid == cloudRepo.currentUid
        val isAdmin = meta.access.isAuthorized && isVerifiedWorkspaceAdmin && (member?.rol != "Consulta")
        val canEdit = isAdmin && (member?.activo != false)

        val animales = core.animales.filter { it.registroActivo }.map { it.toEntity() }.sortedBy { it.arete.lowercase() }
        val pesajes = core.pesajes.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fecha }
        val encastes = core.encastes.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fechaInicio }
        val gestaciones = core.gestaciones.filter { it.registroActivo }.map { it.toEntity() }.sortedBy { it.fechaProbableParto }
        val partos = core.partos.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fechaParto }
        val sanidad = farm.sanidad.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fecha }
        val potreros = farm.potreros.filter { it.registroActivo }.map { it.toEntity() }.sortedBy { it.nombre.lowercase() }
        val movPotrero = farm.movimientosPotrero.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fechaMovimiento }
        val raciones = farm.raciones.filter { it.registroActivo }.map { it.toEntity() }.sortedBy { it.nombre.lowercase() }
        val inventario = farm.inventario.filter { it.registroActivo }.map { it.toEntity() }.sortedBy { it.nombre.lowercase() }
        val movInv = fin.movimientosInventario.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fecha }
        val transacciones = fin.transacciones.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fecha }
        val lotes = fin.lotes.filter { it.registroActivo }.map { it.toEntity() }.sortedBy { it.nombre.lowercase() }
        val destetes = fin.destetes.filter { it.registroActivo }.map { it.toEntity() }.sortedByDescending { it.fecha }

        val deletedRecords = buildDeletedRecords(core, farm, fin)
        val alertas = repo.generarAlertas(animales, sanidad, potreros, inventario)
        val kpis = computeKpis(animales, pesajes, partos, sanidad, alertas)

        val activeUserAccount = UserAccountEntity(
            id = 1L,
            nombre = member?.displayName ?: cloudRepo.currentDisplayName,
            rol = if (canEdit) "Administrador" else "Consulta",
            etiqueta = member?.etiqueta ?: if (isAdmin) "Administrador" else "Socio",
            activo = member?.activo ?: true
        )

        val pendingWrites = meta.wsBundle.syncMeta.hasPendingWrites || sys.animalesPendingWrites
        val fromCache = meta.wsBundle.syncMeta.isFromCache || sys.animalesFromCache

        val updatedSession = meta.access.copy(
            isAdmin = isAdmin,
            workspace = ws,
            currentMember = member,
            isSyncPendingWrites = pendingWrites,
            isFromCache = fromCache
        )

        CriaderoUiState(
            isLoading = meta.access.isLoading,
            predioNombre = ws?.nombrePredio ?: "Fundo Santa Elena · Biobío",
            themeMode = sys.themeMode,
            cloudSession = updatedSession,
            isOnline = sys.isOnline,
            isSyncPendingWrites = pendingWrites,
            isFromCache = fromCache,
            syncErrorMessage = sys.syncError,
            members = meta.members,
            activeUser = activeUserAccount,
            canEdit = canEdit,
            localPendingMigrationCount = if (ws?.migratedFromLocal == true) 0 else sys.localCount,
            isMigrating = sys.isMigrating,
            isBackingUp = sys.isBackingUp,
            animales = animales,
            pesajes = pesajes,
            encastes = encastes,
            gestaciones = gestaciones,
            partos = partos,
            sanidad = sanidad,
            potreros = potreros,
            movimientosPotrero = movPotrero,
            raciones = raciones,
            inventario = inventario,
            movimientosInventario = movInv,
            transacciones = transacciones,
            lotes = lotes,
            destetes = destetes,
            auditLogs = fin.auditLogs.sortedByDescending { it.createdAt?.toDate()?.time ?: it.fechaClienteMs },
            backups = meta.backups.sortedByDescending { it.fechaMs },
            deletedRecords = deletedRecords,
            alertas = alertas,
            kpis = kpis
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CriaderoUiState()
    )

    private fun buildDeletedRecords(
        core: CoreCloudBundle,
        farm: FarmCloudBundle,
        fin: FinanceCloudBundle
    ): List<DeletedRecordItem> {
        val list = mutableListOf<DeletedRecordItem>()
        core.animales.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_ANIMALES, "Animales", it.docId, it.recordId, "${it.arete} (${it.raza})", "${it.sexo} · ${it.pesoActualKg} kg", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        core.pesajes.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_PESAJES, "Pesajes", it.docId, it.recordId, "Pesaje ${it.pesoKg} kg", "Animal #${it.animalId} · ${ChileanFormatters.formatDate(it.fecha)}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        core.encastes.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_ENCASTES, "Reproducción", it.docId, it.recordId, "Encaste ${it.metodo}", "Carnero #${it.carneroId} · ${ChileanFormatters.formatDate(it.fechaInicio)}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        core.gestaciones.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_GESTACIONES, "Reproducción", it.docId, it.recordId, "Gestación ${it.estadoGestacion}", "Oveja #${it.ovejaId}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        core.partos.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_PARTOS, "Partos", it.docId, it.recordId, "Parto ${it.tipoParto}", "Madre #${it.madreId} · ${it.criasVivas} vivas", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        farm.sanidad.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_SANIDAD, "Sanidad", it.docId, it.recordId, "${it.tipoManejo}: ${it.diagnostico}", it.medicamento.ifBlank { it.evolucion }, it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        farm.potreros.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_POTREROS, "Potreros", it.docId, it.recordId, it.nombre, "${it.superficieHa} ha · ${it.tipoPradera}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        farm.movimientosPotrero.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_MOV_POTRERO, "Potreros", it.docId, it.recordId, "Traslado (${it.cantidadAnimales} ovinos)", it.motivo, it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        farm.raciones.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_RACIONES, "Alimentación", it.docId, it.recordId, it.nombre, "${it.tipoAlimento} · ${it.grupoDestinatario}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        farm.inventario.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_INVENTARIO, "Inventario", it.docId, it.recordId, it.nombre, "${it.cantidadDisponible} ${it.unidad}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        fin.movimientosInventario.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_MOV_INVENTARIO, "Inventario", it.docId, it.recordId, "${it.tipo} (${it.cantidad})", it.nota, it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        fin.transacciones.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_TRANSACCIONES, "Economía", it.docId, it.recordId, "${it.tipo}: ${it.categoria}", ChileanFormatters.formatClp(it.montoClp), it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        fin.lotes.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_LOTES, "Lotes", it.docId, it.recordId, it.nombre, "${it.criterio} · ${it.objetivoProductivo}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        fin.destetes.filter { !it.registroActivo }.forEach {
            list += DeletedRecordItem(CloudSchema.SUB_DESTETES, "Destetes", it.docId, it.recordId, "Destete ${it.pesoKg} kg", "Cordero #${it.corderoId} · ${it.tipoDestete}", it.eliminadoAt ?: 0L, it.eliminadoPor.orEmpty())
        }
        return list.sortedByDescending { it.eliminadoAt }
    }

    private fun computeKpis(
        animales: List<AnimalEntity>,
        pesajes: List<PesajeEntity>,
        partos: List<PartoEntity>,
        sanidad: List<SanidadEntity>,
        alertas: List<AlertaCriadero>
    ): DashboardKpis {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            set(Calendar.MONTH, Calendar.JANUARY)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val yearStart = cal.timeInMillis
        val activos = animales.filter { it.estado == "Activo" }

        val ovejasReprod = activos.count {
            it.sexo == "Hembra" && ChileanFormatters.animalCategory(it, now) == "Oveja reproductora"
        }
        val carneros = activos.count {
            it.sexo == "Macho" && ChileanFormatters.animalCategory(it, now) == "Carnero"
        }
        val corderos = activos.count {
            val cat = ChileanFormatters.animalCategory(it, now)
            cat == "Cordero" || cat == "Cordera"
        }
        val enEngorda = activos.count { it.proposito == "Engorda" }
        val prenadas = activos.count { it.sexo == "Hembra" && it.prenada }
        val vacias = activos.count {
            it.sexo == "Hembra" && !it.prenada &&
                ChileanFormatters.animalCategory(it, now) == "Oveja reproductora"
        }
        val nacimientosAnio = partos.filter { it.fechaParto >= yearStart }.sumOf { it.criasVivas }
        val mortalidadAnual = animales.count { it.estado == "Muerte" && it.fechaIngreso >= yearStart } +
            partos.filter { it.fechaParto >= yearStart }.sumOf { it.criasMuertas }
        val enTratamiento = sanidad.count { it.evolucion == "En tratamiento" }
        val kilosTotales = activos.sumOf { it.pesoActualKg }

        val hace30d = now - 30 * CriaderoRepository.DAY_MS
        val kilosMes = pesajes.groupBy { it.animalId }.values.sumOf { list ->
            val sorted = list.sortedBy { it.fecha }
            val recent = sorted.lastOrNull { it.fecha >= hace30d }
            val before = sorted.lastOrNull { it.fecha < hace30d } ?: sorted.firstOrNull()
            if (recent != null && before != null && recent.id != before.id) {
                (recent.pesoKg - before.pesoKg).coerceAtLeast(0.0)
            } else 0.0
        }

        return DashboardKpis(
            totalOvinos = activos.size,
            ovejasReproductoras = ovejasReprod,
            carneros = carneros,
            corderos = corderos,
            enEngorda = enEngorda,
            hembrasPrenadas = prenadas,
            hembrasVacias = vacias,
            nacimientosAnio = nacimientosAnio,
            mortalidadAnual = mortalidadAnual,
            enTratamiento = enTratamiento,
            proximosPartosCount = alertas.count { it.modulo == "Parto" },
            proximosManejosCount = alertas.count { it.modulo == "Sanidad" },
            kilosTotalesRebano = kilosTotales,
            kilosProducidosMes = kilosMes
        )
    }

    private fun currentMemberUids(): List<String> =
        uiState.value.cloudSession.workspace?.memberUids.orEmpty()

    private inline fun requireAdmin(action: () -> Unit) {
        if (!uiState.value.canEdit) {
            _snackbarMessage.tryEmit("Modo consulta: solo el Administrador puede modificar datos.")
            return
        }
        action()
    }

    // --- Foto local persistente desde Photo Picker ---
    suspend fun persistPhotoFromPicker(uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.filesDir, "photos").apply { mkdirs() }
            val dest = File(dir, "ovino_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
            dest.absolutePath
        }.getOrNull()
    }

    // --- Animales ---
    fun saveAnimal(animal: AnimalEntity, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            val existingList = uiState.value.animales
            val prev = existingList.firstOrNull { it.id == animal.id }
            cloudRepo.saveAnimal(animal, prev, existingList, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Ficha guardada y sincronizada: ${animal.arete.trim()}")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al guardar el animal")
            }
        }
    }

    fun deleteAnimal(animal: AnimalEntity, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.softDeleteRecord(
                collection = CloudSchema.SUB_ANIMALES,
                docId = animal.id.toString(),
                modulo = "Animales",
                titulo = "${animal.arete} ${animal.nombre}".trim(),
                valorAnterior = "Raza=${animal.raza}, Peso=${animal.pesoActualKg}kg, Estado=${animal.estado}",
                memberUids = currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Animal ${animal.arete} enviado a Papelera (recuperable)")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al mover a Papelera")
            }
        }
    }

    fun darDeBajaAnimal(animal: AnimalEntity, estado: String, motivo: String) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.darDeBajaAnimal(animal, estado, motivo, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("${animal.arete} actualizado a $estado")
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al actualizar estado")
            }
        }
    }

    // --- Pesajes ---
    fun registrarPesaje(
        animalId: Long,
        pesoKg: Double,
        fecha: Long = System.currentTimeMillis(),
        observaciones: String = "",
        onSuccess: () -> Unit = {}
    ) = requireAdmin {
        viewModelScope.launch {
            val animal = uiState.value.animales.firstOrNull { it.id == animalId }
            if (animal == null) {
                _snackbarMessage.emit("Animal no encontrado.")
                return@launch
            }
            cloudRepo.registrarPesaje(animal, pesoKg, fecha, observaciones, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Pesaje sincronizado: ${ChileanFormatters.formatKg(pesoKg)}")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al registrar pesaje")
            }
        }
    }

    fun deletePesaje(pesaje: PesajeEntity) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.softDeleteRecord(
                collection = CloudSchema.SUB_PESAJES,
                docId = pesaje.id.toString(),
                modulo = "Pesajes",
                titulo = "Pesaje ${pesaje.pesoKg} kg",
                valorAnterior = "Animal #${pesaje.animalId} · ${ChileanFormatters.formatDate(pesaje.fecha)}",
                memberUids = currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Pesaje enviado a Papelera")
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al eliminar pesaje")
            }
        }
    }

    // --- Reproducción ---
    fun registrarEncaste(
        fechaInicio: Long,
        fechaTermino: Long,
        carneroId: Long,
        ovejaIds: List<Long>,
        metodo: String,
        observaciones: String,
        onSuccess: () -> Unit = {}
    ) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.registrarEncaste(
                fechaInicio, fechaTermino, carneroId, ovejaIds, metodo, observaciones, currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Encaste sincronizado con ${ovejaIds.size} oveja(s)")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al registrar encaste")
            }
        }
    }

    fun registrarGestacion(
        ovejaId: Long,
        carneroId: Long?,
        fechaEncaste: Long,
        fechaDiagnostico: Long,
        estadoGestacion: String,
        numeroFetos: Int,
        observaciones: String,
        onSuccess: () -> Unit = {}
    ) = requireAdmin {
        viewModelScope.launch {
            val oveja = uiState.value.animales.firstOrNull { it.id == ovejaId }
            if (oveja == null) {
                _snackbarMessage.emit("Oveja no encontrada.")
                return@launch
            }
            cloudRepo.registrarGestacion(
                oveja, carneroId, fechaEncaste, fechaDiagnostico, estadoGestacion, numeroFetos, observaciones, currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Diagnóstico de gestación sincronizado")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al guardar gestación")
            }
        }
    }

    fun registrarParto(
        madreId: Long,
        padreId: Long?,
        fechaParto: Long,
        asistencia: String,
        observaciones: String,
        crias: List<LambBirthInput>,
        onSuccess: () -> Unit = {}
    ) = requireAdmin {
        viewModelScope.launch {
            val all = uiState.value.animales
            val madre = all.firstOrNull { it.id == madreId }
            if (madre == null) {
                _snackbarMessage.emit("Madre no encontrada.")
                return@launch
            }
            val padre = padreId?.let { id -> all.firstOrNull { it.id == id } }
            cloudRepo.registrarPartoYCrearCorderos(
                madre, padre, all, fechaParto, asistencia, observaciones, crias, currentMemberUids()
            ).onSuccess { count ->
                _snackbarMessage.emit("Parto sincronizado · $count ficha(s) de cordero creadas")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al registrar parto")
            }
        }
    }

    // --- Sanidad ---
    fun saveSanidad(sanidad: SanidadEntity, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.saveSanidad(sanidad, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Manejo sanitario sincronizado")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al guardar sanidad")
            }
        }
    }

    fun marcarSanidadRecuperada(sanidad: SanidadEntity) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.marcarSanidadRecuperada(sanidad, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Estado sanitario actualizado a Recuperado")
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al actualizar sanidad")
            }
        }
    }

    fun deleteSanidad(sanidad: SanidadEntity) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.softDeleteRecord(
                collection = CloudSchema.SUB_SANIDAD,
                docId = sanidad.id.toString(),
                modulo = "Sanidad",
                titulo = "${sanidad.tipoManejo}: ${sanidad.diagnostico}",
                valorAnterior = "${sanidad.medicamento} (${sanidad.evolucion})",
                memberUids = currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Registro sanitario enviado a Papelera")
            }
        }
    }

    // --- Potreros ---
    fun savePotrero(potrero: PotreroEntity, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.savePotrero(potrero, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Potrero '${potrero.nombre}' guardado")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al guardar potrero")
            }
        }
    }

    fun moverAnimalesDePotrero(
        animalIds: List<Long>,
        origenId: Long?,
        destinoId: Long,
        motivo: String,
        observaciones: String,
        onSuccess: () -> Unit = {}
    ) = requireAdmin {
        viewModelScope.launch {
            val selected = uiState.value.animales.filter { it.id in animalIds }
            val orig = origenId?.let { id -> uiState.value.potreros.firstOrNull { it.id == id } }
            val dest = uiState.value.potreros.firstOrNull { it.id == destinoId }
            if (dest == null) {
                _snackbarMessage.emit("Potrero destino no encontrado.")
                return@launch
            }
            cloudRepo.moverAnimalesDePotrero(selected, orig, dest, motivo, observaciones, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("${selected.size} ovino(s) trasladados de potrero")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al mover animales")
            }
        }
    }

    // --- Alimentación ---
    fun saveRacion(racion: AlimentoRacionEntity, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.saveRacion(racion, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Ración guardada")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al guardar ración")
            }
        }
    }

    fun deleteRacion(racion: AlimentoRacionEntity) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.softDeleteRecord(
                collection = CloudSchema.SUB_RACIONES,
                docId = racion.id.toString(),
                modulo = "Alimentación",
                titulo = racion.nombre,
                valorAnterior = "${racion.tipoAlimento} · ${racion.grupoDestinatario}",
                memberUids = currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Ración enviada a Papelera")
            }
        }
    }

    // --- Inventario ---
    fun saveInventarioItem(item: InventarioItemEntity, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.saveInventarioItem(item, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Insumo guardado en bodega")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al guardar insumo")
            }
        }
    }

    fun registrarMovimientoInventario(
        itemId: Long,
        tipo: String,
        cantidad: Double,
        costoTotalClp: Double,
        nota: String,
        onSuccess: () -> Unit = {}
    ) = requireAdmin {
        viewModelScope.launch {
            val item = uiState.value.inventario.firstOrNull { it.id == itemId }
            if (item == null) {
                _snackbarMessage.emit("Ítem de inventario no encontrado.")
                return@launch
            }
            cloudRepo.registrarMovimientoInventario(item, tipo, cantidad, costoTotalClp, nota, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Stock actualizado ($tipo)")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error en movimiento de inventario")
            }
        }
    }

    fun deleteInventarioItem(item: InventarioItemEntity) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.softDeleteRecord(
                collection = CloudSchema.SUB_INVENTARIO,
                docId = item.id.toString(),
                modulo = "Inventario",
                titulo = item.nombre,
                valorAnterior = "${item.cantidadDisponible} ${item.unidad}",
                memberUids = currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Insumo enviado a Papelera")
            }
        }
    }

    // --- Economía ---
    fun saveTransaccion(tx: TransaccionEconomicaEntity, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.saveTransaccion(tx, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("${tx.tipo} sincronizado: ${ChileanFormatters.formatClp(tx.montoClp)}")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al registrar movimiento económico")
            }
        }
    }

    fun deleteTransaccion(tx: TransaccionEconomicaEntity) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.softDeleteRecord(
                collection = CloudSchema.SUB_TRANSACCIONES,
                docId = tx.id.toString(),
                modulo = "Economía",
                titulo = "${tx.tipo}: ${tx.categoria}",
                valorAnterior = ChileanFormatters.formatClp(tx.montoClp),
                memberUids = currentMemberUids()
            ).onSuccess {
                _snackbarMessage.emit("Movimiento económico enviado a Papelera")
            }
        }
    }

    // --- Lotes & Destete ---
    fun saveLote(lote: LoteEntity, animalIds: List<Long>, onSuccess: () -> Unit = {}) = requireAdmin {
        viewModelScope.launch {
            val selected = uiState.value.animales.filter { it.id in animalIds }
            cloudRepo.saveLote(lote, selected, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Lote '${lote.nombre}' guardado")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al guardar lote")
            }
        }
    }

    fun registrarDestete(
        corderoId: Long,
        fecha: Long,
        pesoKg: Double,
        tipoDestete: String,
        loteDestinoId: Long?,
        observaciones: String,
        onSuccess: () -> Unit = {}
    ) = requireAdmin {
        viewModelScope.launch {
            val cordero = uiState.value.animales.firstOrNull { it.id == corderoId }
            if (cordero == null) {
                _snackbarMessage.emit("Cordero no encontrado.")
                return@launch
            }
            cloudRepo.registrarDestete(cordero, fecha, pesoKg, tipoDestete, loteDestinoId, observaciones, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Destete registrado y sincronizado")
                onSuccess()
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al registrar destete")
            }
        }
    }

    // --- Papelera (Recuperación / Purga) ---
    fun restoreDeletedRecord(item: DeletedRecordItem) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.restoreRecord(item, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Registro restaurado: ${item.titulo}")
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al restaurar registro")
            }
        }
    }

    fun purgeDeletedRecord(item: DeletedRecordItem) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.permanentDeleteRecord(item, currentMemberUids()).onSuccess {
                _snackbarMessage.emit("Registro eliminado permanentemente")
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error al eliminar definitivamente")
            }
        }
    }

    // --- Equipo (3 cuentas), Migración y Copias de Seguridad ---
    fun updatePartnerEmails(socio1Email: String, socio2Email: String) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.updatePartnerEmails(socio1Email, socio2Email, uiState.value.cloudSession.workspace)
                .onSuccess {
                    _snackbarMessage.emit("Correos de socios actualizados en la nube")
                }.onFailure {
                    _snackbarMessage.emit(it.message ?: "Error al guardar socios")
                }
        }
    }

    fun syncAccessForMembers() = requireAdmin {
        viewModelScope.launch {
            cloudRepo.syncMemberUidsAcrossFarm(currentMemberUids())
                .onSuccess { count ->
                    _snackbarMessage.emit(
                        if (count == 0) "Todos los registros ya están sincronizados para el equipo."
                        else "Permisos de lectura sincronizados en $count documento(s)."
                    )
                }.onFailure {
                    _snackbarMessage.emit(it.message ?: "Error al sincronizar permisos")
                }
        }
    }

    fun migrateLocalToCloud() = requireAdmin {
        if (_isMigrating.value) return@requireAdmin
        viewModelScope.launch {
            _isMigrating.value = true
            migrationService.migrateLocalRoomToCloud(
                appContext = context,
                roomDb = roomDb,
                predioNombre = uiState.value.predioNombre,
                memberUids = currentMemberUids()
            ).onSuccess { summary ->
                _snackbarMessage.emit(
                    "Migración completa: ${summary.uploadedCount} cargados, ${summary.skippedDuplicatesCount} ya existentes (${summary.verifiedCloudAnimals} ovinos verificados)."
                )
            }.onFailure {
                _snackbarMessage.emit(it.message ?: "Error durante la migración")
            }
            _isMigrating.value = false
        }
    }

    fun createCloudBackup(nombre: String) = requireAdmin {
        if (_isBackingUp.value) return@requireAdmin
        viewModelScope.launch {
            _isBackingUp.value = true
            val payload = currentFullPayload()
            migrationService.createCloudBackupSnapshot(payload, nombre, currentMemberUids())
                .onSuccess {
                    _snackbarMessage.emit("Copia de seguridad guardada en la nube (${payload.totalRecords()} registros)")
                }.onFailure {
                    _snackbarMessage.emit(it.message ?: "Error al crear respaldo en la nube")
                }
            _isBackingUp.value = false
        }
    }

    fun restoreFromCloudBackup(backup: CloudBackupSnapshot) = requireAdmin {
        viewModelScope.launch {
            _isBackingUp.value = true
            migrationService.restoreFromBackupJson(backup.payloadJson, currentMemberUids(), backup.nombre)
                .onSuccess { (written, skipped) ->
                    _snackbarMessage.emit("Respaldo '${backup.nombre}' aplicado: $written restaurados, $skipped ya existían")
                }.onFailure {
                    _snackbarMessage.emit(it.message ?: "Error al restaurar respaldo")
                }
            _isBackingUp.value = false
        }
    }

    fun requestAdminTransfer(targetEmail: String) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.requestAdminTransfer(targetEmail, uiState.value.cloudSession.workspace)
                .onSuccess {
                    val clean = targetEmail.trim().lowercase()
                    _snackbarMessage.emit(
                        if (clean.isEmpty()) "Traspaso de Administrador cancelado."
                        else "Invitación de Administrador enviada a $clean."
                    )
                }.onFailure {
                    _snackbarMessage.emit(it.message ?: "Error al configurar traspaso")
                }
        }
    }

    fun restoreFromJsonOrEncrypted(rawContent: String, passphrase: String?, label: String) = requireAdmin {
        viewModelScope.launch {
            _isBackingUp.value = true
            val plainJsonResult = if (BackupCryptoHelper.isEncryptedEnvelope(rawContent)) {
                BackupCryptoHelper.decryptWithPassphrase(rawContent, passphrase.orEmpty())
            } else {
                Result.success(rawContent)
            }
            plainJsonResult.onSuccess { jsonString ->
                migrationService.restoreFromBackupJson(jsonString, currentMemberUids(), label)
                    .onSuccess { (written, skipped) ->
                        _snackbarMessage.emit("Respaldo importado: $written registros restaurados, $skipped omitidos")
                    }.onFailure {
                        _snackbarMessage.emit(it.message ?: "Archivo de respaldo inválido o incompatible")
                    }
            }.onFailure { err ->
                _snackbarMessage.emit(err.message ?: "Contraseña incorrecta o respaldo cifrado inválido")
            }
            _isBackingUp.value = false
        }
    }

    fun restoreFromJsonString(jsonString: String, label: String) =
        restoreFromJsonOrEncrypted(jsonString, null, label)

    fun updatePredioNombre(nombre: String) = requireAdmin {
        viewModelScope.launch {
            cloudRepo.updatePredioNombre(nombre, uiState.value.cloudSession.workspace)
                .onSuccess {
                    prefs.setPredioNombre(nombre)
                    _snackbarMessage.emit("Nombre del criadero actualizado y sincronizado")
                }.onFailure {
                    _snackbarMessage.emit(it.message ?: "Error al actualizar predio")
                }
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch { prefs.setThemeMode(mode) }
    }

    fun notifyMessage(msg: String) {
        _snackbarMessage.tryEmit(msg)
    }

    private fun currentFullPayload(): FullCriaderoBackupPayload {
        val s = uiState.value
        return FullCriaderoBackupPayload(
            version = 2,
            exportedAt = System.currentTimeMillis(),
            predioNombre = s.predioNombre,
            animales = s.animales,
            pesajes = s.pesajes,
            encastes = s.encastes,
            gestaciones = s.gestaciones,
            partos = s.partos,
            sanidad = s.sanidad,
            potreros = s.potreros,
            movimientosPotrero = s.movimientosPotrero,
            raciones = s.raciones,
            inventario = s.inventario,
            movimientosInventario = s.movimientosInventario,
            transacciones = s.transacciones,
            lotes = s.lotes,
            destetes = s.destetes
        )
    }

    suspend fun buildBackupJson(): String =
        BackupJsonSerializer.serializeFullBackup(currentFullPayload(), pretty = true)

    suspend fun buildEncryptedBackupString(passphrase: String): String =
        BackupCryptoHelper.encryptWithPassphrase(buildBackupJson(), passphrase)

    companion object {
        fun provideFactory(
            appContext: Context,
            firestore: FirebaseFirestore,
            roomDb: CriaderoDatabase,
            prefs: SessionPreferences,
            networkMonitor: NetworkMonitor,
            firebaseUser: FirebaseUser,
            criaderoId: String = CloudSchema.DEFAULT_CRIADERO_ID
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return CriaderoViewModel(
                    appContext = appContext.applicationContext,
                    firestore = firestore,
                    roomDb = roomDb,
                    prefs = prefs,
                    networkMonitor = networkMonitor,
                    firebaseUser = firebaseUser,
                    criaderoId = criaderoId
                ) as T
            }
        }
    }
}

private data class CoreCloudBundle(
    val animales: List<CloudAnimalDto>,
    val pesajes: List<CloudPesajeDto>,
    val encastes: List<CloudEncasteDto>,
    val gestaciones: List<CloudGestacionDto>,
    val partos: List<CloudPartoDto>
)

private data class FarmCloudBundle(
    val sanidad: List<CloudSanidadDto>,
    val potreros: List<CloudPotreroDto>,
    val movimientosPotrero: List<CloudMovimientoPotreroDto>,
    val raciones: List<CloudRacionDto>,
    val inventario: List<CloudInventarioItemDto>
)

private data class FinanceCloudBundle(
    val movimientosInventario: List<CloudMovimientoInventarioDto>,
    val transacciones: List<CloudTransaccionDto>,
    val lotes: List<CloudLoteDto>,
    val destetes: List<CloudDesteteDto>,
    val auditLogs: List<AuditLogEntry>
)

private data class SessionMetaBundle(
    val access: CloudAccessSession,
    val wsBundle: CloudSnapshotBundle,
    val currentMember: CriaderoMember?,
    val members: List<CriaderoMember>,
    val backups: List<CloudBackupSnapshot>
)

private data class SystemStatusBundle(
    val themeMode: String,
    val isOnline: Boolean,
    val syncError: String?,
    val localCount: Int,
    val isMigrating: Boolean,
    val isBackingUp: Boolean,
    val animalesPendingWrites: Boolean = false,
    val animalesFromCache: Boolean = false
)
