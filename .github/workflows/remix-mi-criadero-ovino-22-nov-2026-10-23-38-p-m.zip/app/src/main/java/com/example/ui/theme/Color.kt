package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Chilean Agricultural & Pasture Palette
val ForestGreen = Color(0xFF1B4332)
val ForestGreenDark = Color(0xFF0F291E)
val MeadowGreen = Color(0xFF2D6A4F)
val PastureGreen = Color(0xFF40916C)
val FreshGrass = Color(0xFF52B788)
val SoftMint = Color(0xFFD8F3DC)
val PalePasture = Color(0xFFE9F5EC)

val WoolCream = Color(0xFFFBF9F5)
val WarmLinen = Color(0xFFF3EFE6)
val SoftStone = Color(0xFFE6E1D6)
val SlateInk = Color(0xFF1A241E)
val MutedMoss = Color(0xFF4A5D52)

val EarthTerracotta = Color(0xFFBC6C25)
val TerracottaSoft = Color(0xFFFDEBD6)
val SaddleBrown = Color(0xFF6F4E37)
val WarmSand = Color(0xFFDDA15E)

val HarvestAmber = Color(0xFFD97706)
val AmberSoft = Color(0xFFFEF3C7)
val CrimsonAlert = Color(0xFFB91C1C)
val CrimsonSoft = Color(0xFFFEE2E2)
val SkyInfo = Color(0xFF0369A1)
val SkySoft = Color(0xFFE0F2FE)

// Dark Theme Tokens
val DarkForestBg = Color(0xFF0E1713)
val DarkForestSurface = Color(0xFF15221C)
val DarkForestSurfaceHigh = Color(0xFF1E3027)
val DarkFreshLeaf = Color(0xFF74C69D)
val DarkWarmSand = Color(0xFFE9B872)
val DarkCreamText = Color(0xFFECF3EE)
