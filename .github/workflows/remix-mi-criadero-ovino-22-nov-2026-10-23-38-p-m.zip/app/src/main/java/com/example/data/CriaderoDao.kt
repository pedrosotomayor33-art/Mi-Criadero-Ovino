package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CriaderoDao {

    // --- Animales ---
    @Query("SELECT * FROM animales ORDER BY arete ASC")
    fun observeAnimales(): Flow<List<AnimalEntity>>

    @Query("SELECT * FROM animales WHERE id = :id")
    suspend fun getAnimalById(id: Long): AnimalEntity?

    @Query("SELECT * FROM animales WHERE LOWER(arete) = LOWER(:arete) LIMIT 1")
    suspend fun getAnimalByArete(arete: String): AnimalEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAnimal(animal: AnimalEntity): Long

    @Update
    suspend fun updateAnimal(animal: AnimalEntity)

    @Delete
    suspend fun deleteAnimal(animal: AnimalEntity)

    @Query("UPDATE animales SET potreroId = :potreroId WHERE id IN (:animalIds)")
    suspend fun updateAnimalesPotrero(animalIds: List<Long>, potreroId: Long)

    @Query("UPDATE animales SET loteId = :loteId WHERE id IN (:animalIds)")
    suspend fun updateAnimalesLote(animalIds: List<Long>, loteId: Long)

    // --- Pesajes ---
    @Query("SELECT * FROM pesajes ORDER BY fecha DESC")
    fun observePesajes(): Flow<List<PesajeEntity>>

    @Query("SELECT * FROM pesajes WHERE animalId = :animalId ORDER BY fecha ASC")
    fun observePesajesForAnimal(animalId: Long): Flow<List<PesajeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPesaje(pesaje: PesajeEntity): Long

    @Delete
    suspend fun deletePesaje(pesaje: PesajeEntity)

    // --- Encastes ---
    @Query("SELECT * FROM encastes ORDER BY fechaInicio DESC")
    fun observeEncastes(): Flow<List<EncasteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEncaste(encaste: EncasteEntity): Long

    @Delete
    suspend fun deleteEncaste(encaste: EncasteEntity)

    // --- Gestaciones ---
    @Query("SELECT * FROM gestaciones ORDER BY fechaProbableParto ASC")
    fun observeGestaciones(): Flow<List<GestacionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGestacion(gestacion: GestacionEntity): Long

    @Update
    suspend fun updateGestacion(gestacion: GestacionEntity)

    @Delete
    suspend fun deleteGestacion(gestacion: GestacionEntity)

    // --- Partos ---
    @Query("SELECT * FROM partos ORDER BY fechaParto DESC")
    fun observePartos(): Flow<List<PartoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParto(parto: PartoEntity): Long

    @Delete
    suspend fun deleteParto(parto: PartoEntity)

    // --- Sanidad ---
    @Query("SELECT * FROM registros_sanitarios ORDER BY fecha DESC")
    fun observeSanidad(): Flow<List<SanidadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSanidad(sanidad: SanidadEntity): Long

    @Update
    suspend fun updateSanidad(sanidad: SanidadEntity)

    @Delete
    suspend fun deleteSanidad(sanidad: SanidadEntity)

    // --- Potreros y Movimientos ---
    @Query("SELECT * FROM potreros ORDER BY nombre ASC")
    fun observePotreros(): Flow<List<PotreroEntity>>

    @Query("SELECT * FROM potreros WHERE id = :id")
    suspend fun getPotreroById(id: Long): PotreroEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPotrero(potrero: PotreroEntity): Long

    @Update
    suspend fun updatePotrero(potrero: PotreroEntity)

    @Delete
    suspend fun deletePotrero(potrero: PotreroEntity)

    @Query("SELECT * FROM movimientos_potrero ORDER BY fechaMovimiento DESC")
    fun observeMovimientosPotrero(): Flow<List<MovimientoPotreroEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovimientoPotrero(movimiento: MovimientoPotreroEntity): Long

    // --- Alimentación ---
    @Query("SELECT * FROM raciones_alimento ORDER BY nombre ASC")
    fun observeRaciones(): Flow<List<AlimentoRacionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRacion(racion: AlimentoRacionEntity): Long

    @Update
    suspend fun updateRacion(racion: AlimentoRacionEntity)

    @Delete
    suspend fun deleteRacion(racion: AlimentoRacionEntity)

    // --- Inventario ---
    @Query("SELECT * FROM inventario ORDER BY nombre ASC")
    fun observeInventario(): Flow<List<InventarioItemEntity>>

    @Query("SELECT * FROM inventario WHERE id = :id")
    suspend fun getInventarioItemById(id: Long): InventarioItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventarioItem(item: InventarioItemEntity): Long

    @Update
    suspend fun updateInventarioItem(item: InventarioItemEntity)

    @Delete
    suspend fun deleteInventarioItem(item: InventarioItemEntity)

    @Query("SELECT * FROM movimientos_inventario ORDER BY fecha DESC")
    fun observeMovimientosInventario(): Flow<List<MovimientoInventarioEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovimientoInventario(movimiento: MovimientoInventarioEntity): Long

    // --- Economía ---
    @Query("SELECT * FROM transacciones_economicas ORDER BY fecha DESC")
    fun observeTransacciones(): Flow<List<TransaccionEconomicaEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaccion(tx: TransaccionEconomicaEntity): Long

    @Delete
    suspend fun deleteTransaccion(tx: TransaccionEconomicaEntity)

    // --- Lotes & Destetes ---
    @Query("SELECT * FROM lotes ORDER BY nombre ASC")
    fun observeLotes(): Flow<List<LoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLote(lote: LoteEntity): Long

    @Update
    suspend fun updateLote(lote: LoteEntity)

    @Delete
    suspend fun deleteLote(lote: LoteEntity)

    @Query("SELECT * FROM destetes ORDER BY fecha DESC")
    fun observeDestetes(): Flow<List<DesteteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDestete(destete: DesteteEntity): Long

    // --- Usuarios ---
    @Query("SELECT * FROM usuarios ORDER BY id ASC")
    fun observeUsuarios(): Flow<List<UserAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsuario(user: UserAccountEntity): Long

    @Update
    suspend fun updateUsuario(user: UserAccountEntity)

    @Delete
    suspend fun deleteUsuario(user: UserAccountEntity)

    // --- Respaldo / Limpieza ---
    @Query("DELETE FROM animales") suspend fun clearAnimales()
    @Query("DELETE FROM pesajes") suspend fun clearPesajes()
    @Query("DELETE FROM encastes") suspend fun clearEncastes()
    @Query("DELETE FROM gestaciones") suspend fun clearGestaciones()
    @Query("DELETE FROM partos") suspend fun clearPartos()
    @Query("DELETE FROM registros_sanitarios") suspend fun clearSanidad()
    @Query("DELETE FROM potreros") suspend fun clearPotreros()
    @Query("DELETE FROM movimientos_potrero") suspend fun clearMovimientosPotrero()
    @Query("DELETE FROM raciones_alimento") suspend fun clearRaciones()
    @Query("DELETE FROM inventario") suspend fun clearInventario()
    @Query("DELETE FROM movimientos_inventario") suspend fun clearMovimientosInventario()
    @Query("DELETE FROM transacciones_economicas") suspend fun clearTransacciones()
    @Query("DELETE FROM lotes") suspend fun clearLotes()
    @Query("DELETE FROM destetes") suspend fun clearDestetes()
}
