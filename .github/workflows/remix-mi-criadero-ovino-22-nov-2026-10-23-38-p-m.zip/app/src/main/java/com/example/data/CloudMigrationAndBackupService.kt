package com.example.data

import android.content.Context
import com.google.firebase.firestore.FieldValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import java.io.File

data class MigrationSummary(
    val backupFilePath: String,
    val uploadedCount: Int,
    val skippedDuplicatesCount: Int,
    val verifiedCloudAnimals: Int
)

class CloudMigrationAndBackupService(
    private val cloudRepo: CloudCriaderoRepository
) {
    private fun subCol(name: String) = cloudRepo.subCol(name)

    suspend fun createCloudBackupSnapshot(
        payload: FullCriaderoBackupPayload,
        nombre: String,
        memberUids: List<String>
    ): Result<String> {
        return try {
            val uids = cloudRepo.effectiveMemberUids(memberUids)
            val actorEmail = cloudRepo.currentEmail
            require(actorEmail.isNotBlank()) { "Se requiere una cuenta Google con correo verificado." }
            val json = BackupJsonSerializer.serializeFullBackup(payload, pretty = false)
            require(json.length <= 900_000) {
                "El respaldo supera el límite de 900 KB para un documento en la nube; use Exportar respaldo."
            }
            val backupId = "bkp_${System.currentTimeMillis()}"
            val total = payload.totalRecords().toLong()
            val resumen = "${payload.animales.size} ovinos · ${payload.pesajes.size} pesajes · ${payload.partos.size} partos · ${payload.sanidad.size} sanidad · ${payload.transacciones.size} mov. econ."
            val snapshot = CloudBackupSnapshot(
                memberUids = uids,
                nombre = nombre.ifBlank { "Respaldo Nube" },
                creadoPorUid = cloudRepo.currentUid,
                creadoPorEmail = actorEmail,
                fechaMs = System.currentTimeMillis(),
                totalRegistros = total,
                resumen = resumen,
                payloadJson = json
            )
            val batch = cloudRepo.db.batch()
            batch.set(subCol(CloudSchema.SUB_BACKUPS).document(backupId), snapshot.toCreateMap())
            cloudRepo.appendAuditLog(
                batch, uids, "RESPALDO", "Respaldo", backupId, snapshot.nombre,
                "Copia de seguridad en la nube ($total registros)",
                "", resumen
            )
            batch.commit().await()
            Result.success(backupId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, CloudSchema.SUB_BACKUPS)
            Result.failure(e)
        }
    }

    /**
     * Migración segura de Room SQLite local hacia Cloud Firestore:
     * 1. Lee todos los registros locales y crea una copia de seguridad local cifrada con Android KeyStore (AES-256-GCM) ANTES de migrar.
     * 2. Crea además una instantánea en Firestore (/backups) antes de escribir registros.
     * 3. Verifica claves e IDs existentes en las 14 colecciones de Firestore para evitar duplicados o sobrescrituras.
     * 4. Sube en lotes atómicos sin borrar la base local Room.
     * 5. Verifica conteos en múltiples módulos y marca migratedFromLocal = true en el workspace.
     */
    suspend fun migrateLocalRoomToCloud(
        appContext: Context,
        roomDb: CriaderoDatabase,
        predioNombre: String,
        memberUids: List<String>
    ): Result<MigrationSummary> {
        return try {
            val localRepo = CriaderoRepository(roomDb)
            val snapshot = localRepo.readLocalSnapshot(predioNombre)
            require(snapshot.totalRecords() > 0) {
                "No existen registros locales en SQLite para migrar."
            }

            // Paso 1: Copia de seguridad local previa CIFRADA con Android KeyStore (AES-256-GCM)
            val backupsDir = File(appContext.filesDir, "backups").apply { mkdirs() }
            val preFile = File(backupsDir, "pre_migracion_${System.currentTimeMillis()}.enc")
            val jsonPretty = BackupJsonSerializer.serializeFullBackup(snapshot, pretty = true)
            val encryptedEnvelope = BackupCryptoHelper.encryptWithDeviceKeyStore(jsonPretty)
            preFile.writeText(encryptedEnvelope, Charsets.UTF_8)

            // Paso 2: Copia de seguridad en la nube previa (si cabe en 900 KB)
            val compactJson = BackupJsonSerializer.serializeFullBackup(snapshot, pretty = false)
            if (compactJson.length <= 900_000) {
                createCloudBackupSnapshot(
                    payload = snapshot,
                    nombre = "Respaldo Pre-Migración Local",
                    memberUids = memberUids
                )
            }

            // Paso 3 & 4: Subida deduplicada y sin colisiones de ID preservando relaciones
            val (uploaded, skipped) = uploadPayloadDeduplicated(
                payload = snapshot,
                memberUids = memberUids,
                auditAction = "MIGRAR",
                auditNote = "Migración verificada desde SQLite local a Firestore"
            )

            // Paso 5: Verificación de conteo en la nube (múltiples colecciones, sin borrar Room local)
            val verifiedAnimals = cloudCount(CloudSchema.SUB_ANIMALES)
            val verifiedPesajes = cloudCount(CloudSchema.SUB_PESAJES)
            val verifiedSanidad = cloudCount(CloudSchema.SUB_SANIDAD)
            val verifiedPotreros = cloudCount(CloudSchema.SUB_POTREROS)
            val verifiedTx = cloudCount(CloudSchema.SUB_TRANSACCIONES)

            require(
                verifiedAnimals >= snapshot.animales.size &&
                    verifiedPesajes >= snapshot.pesajes.size &&
                    verifiedSanidad >= snapshot.sanidad.size &&
                    verifiedPotreros >= snapshot.potreros.size &&
                    verifiedTx >= snapshot.transacciones.size
            ) {
                "La verificación post-migración detectó registros faltantes en la nube respecto al respaldo local."
            }

            cloudRepo.workspaceRef.update(
                mapOf(
                    "migratedFromLocal" to true,
                    "migrationVerifiedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            Result.success(
                MigrationSummary(
                    backupFilePath = preFile.absolutePath,
                    uploadedCount = uploaded,
                    skippedDuplicatesCount = skipped,
                    verifiedCloudAnimals = verifiedAnimals
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, CloudSchema.SUB_ANIMALES)
            Result.failure(e)
        }
    }

    suspend fun restoreFromBackupJson(
        jsonString: String,
        memberUids: List<String>,
        sourceLabel: String
    ): Result<Pair<Int, Int>> {
        return try {
            val payload = BackupJsonSerializer.parseFullBackup(jsonString).getOrThrow()
            val result = uploadPayloadDeduplicated(
                payload = payload,
                memberUids = memberUids,
                auditAction = "RESPALDO",
                auditNote = "Restauración desde respaldo ($sourceLabel)"
            )
            Result.success(result)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, CloudSchema.SUB_BACKUPS)
            Result.failure(e)
        }
    }

    private suspend fun cloudCount(subcollection: String): Int =
        subCol(subcollection).whereArrayContains("memberUids", cloudRepo.currentUid).get().await().size()

    private fun reserveNonCollidingId(candidateId: Long, usedIds: MutableSet<Long>): Long {
        var resolved = if (candidateId > 0L && candidateId !in usedIds) candidateId else cloudRepo.nextRecordId()
        while (resolved in usedIds) {
            resolved = cloudRepo.nextRecordId()
        }
        usedIds += resolved
        return resolved
    }

    private fun remapCsvIds(csv: String, idMap: Map<Long, Long>): String =
        csv.split(",")
            .mapNotNull { token -> token.trim().toLongOrNull()?.let { idMap[it] ?: it }?.toString() }
            .joinToString(",")

    private data class ExistingCollectionIndex(
        val usedIds: MutableSet<Long>,
        val keys: MutableSet<String>,
        val nameToId: MutableMap<String, Long> = mutableMapOf()
    )

    private suspend fun loadIndex(
        subcollection: String,
        nameExtractor: ((com.google.firebase.firestore.DocumentSnapshot) -> String?)? = null,
        keyExtractor: ((com.google.firebase.firestore.DocumentSnapshot) -> String)? = null
    ): ExistingCollectionIndex {
        val snap = subCol(subcollection).whereArrayContains("memberUids", cloudRepo.currentUid).get().await()
        val usedIds = mutableSetOf<Long>()
        val keys = mutableSetOf<String>()
        val nameToId = mutableMapOf<String, Long>()
        snap.documents.forEach { d ->
            val recId = d.getLong("recordId") ?: d.id.toLongOrNull() ?: 0L
            if (recId > 0L) usedIds += recId
            if (nameExtractor != null) {
                val n = nameExtractor(d)?.trim()?.lowercase().orEmpty()
                if (n.isNotEmpty() && recId > 0L) nameToId[n] = recId
            }
            if (keyExtractor != null) {
                keys += keyExtractor(d)
            }
        }
        return ExistingCollectionIndex(usedIds, keys, nameToId)
    }

    private suspend fun uploadPayloadDeduplicated(
        payload: FullCriaderoBackupPayload,
        memberUids: List<String>,
        auditAction: String,
        auditNote: String
    ): Pair<Int, Int> {
        val uids = cloudRepo.effectiveMemberUids(memberUids)

        // Consultar llaves e IDs existentes en todas las colecciones para no sobrescribir ni duplicar nada
        val animalesIdx = loadIndex(
            CloudSchema.SUB_ANIMALES,
            nameExtractor = { it.getString("arete") }
        )
        val potrerosIdx = loadIndex(
            CloudSchema.SUB_POTREROS,
            nameExtractor = { it.getString("nombre") }
        )
        val lotesIdx = loadIndex(
            CloudSchema.SUB_LOTES,
            nameExtractor = { it.getString("nombre") }
        )
        val invIdx = loadIndex(
            CloudSchema.SUB_INVENTARIO,
            nameExtractor = { it.getString("nombre") }
        )
        val racionesIdx = loadIndex(
            CloudSchema.SUB_RACIONES,
            keyExtractor = { it.getString("nombre")?.trim()?.lowercase().orEmpty() }
        )
        val pesajesIdx = loadIndex(CloudSchema.SUB_PESAJES) { d ->
            "${d.getLong("animalId")}|${d.getLong("fecha")}|${d.getDouble("pesoKg")}"
        }
        val sanidadIdx = loadIndex(CloudSchema.SUB_SANIDAD) { d ->
            "${d.getLong("animalId")}|${d.getLong("fecha")}|${d.getString("diagnostico")?.lowercase()}"
        }
        val encastesIdx = loadIndex(CloudSchema.SUB_ENCASTES) { d ->
            "${d.getLong("carneroId")}|${d.getLong("fechaInicio")}|${d.getString("ovejaIdsCsv")}"
        }
        val gestacionesIdx = loadIndex(CloudSchema.SUB_GESTACIONES) { d ->
            "${d.getLong("ovejaId")}|${d.getLong("fechaDiagnostico")}|${d.getString("estadoGestacion")}"
        }
        val partosIdx = loadIndex(CloudSchema.SUB_PARTOS) { d ->
            "${d.getLong("madreId")}|${d.getLong("fechaParto")}|${d.getLong("cantidadCrias")}"
        }
        val movPotreroIdx = loadIndex(CloudSchema.SUB_MOV_POTRERO) { d ->
            "${d.getLong("potreroDestinoId")}|${d.getLong("fechaMovimiento")}|${d.getString("animalIdsCsv")}"
        }
        val movInvIdx = loadIndex(CloudSchema.SUB_MOV_INVENTARIO) { d ->
            "${d.getLong("itemId")}|${d.getLong("fecha")}|${d.getDouble("cantidad")}"
        }
        val txIdx = loadIndex(CloudSchema.SUB_TRANSACCIONES) { d ->
            "${d.getString("tipo")}|${d.getLong("fecha")}|${d.getDouble("montoClp")}|${d.getString("categoria")?.lowercase()}"
        }
        val desteteIdx = loadIndex(CloudSchema.SUB_DESTETES) { d ->
            "${d.getLong("corderoId")}|${d.getLong("fecha")}"
        }

        val ops = mutableListOf<Pair<com.google.firebase.firestore.DocumentReference, Map<String, Any>>>()
        var skipped = 0

        // 1. Potreros
        val potreroIdMap = mutableMapOf<Long, Long>()
        payload.potreros.forEach { p ->
            val key = p.nombre.trim().lowercase()
            val existingId = potrerosIdx.nameToId[key]
            if (existingId != null && existingId > 0L) {
                potreroIdMap[p.id] = existingId
                skipped++
            } else {
                val id = reserveNonCollidingId(p.id, potrerosIdx.usedIds)
                potreroIdMap[p.id] = id
                ops += subCol(CloudSchema.SUB_POTREROS).document(id.toString()) to p.copy(id = id).toCloudCreateMap(uids)
            }
        }

        // 2. Lotes
        val loteIdMap = mutableMapOf<Long, Long>()
        payload.lotes.forEach { l ->
            val key = l.nombre.trim().lowercase()
            val existingId = lotesIdx.nameToId[key]
            if (existingId != null && existingId > 0L) {
                loteIdMap[l.id] = existingId
                skipped++
            } else {
                val id = reserveNonCollidingId(l.id, lotesIdx.usedIds)
                loteIdMap[l.id] = id
                val mappedPotrero = l.potreroId?.let { potreroIdMap[it] ?: it }
                ops += subCol(CloudSchema.SUB_LOTES).document(id.toString()) to l.copy(id = id, potreroId = mappedPotrero).toCloudCreateMap(uids)
            }
        }

        // 3. Animales (doble pasada para remapeo completo de madreId/padreId en cualquier orden)
        val animalIdMap = mutableMapOf<Long, Long>()
        val animalsToInsert = mutableListOf<Pair<Long, AnimalEntity>>()
        payload.animales.forEach { a ->
            val key = a.arete.trim().lowercase()
            val existingId = animalesIdx.nameToId[key]
            if (existingId != null && existingId > 0L) {
                animalIdMap[a.id] = existingId
                skipped++
            } else {
                val candidateId = reserveNonCollidingId(a.id, animalesIdx.usedIds)
                animalIdMap[a.id] = candidateId
                animalsToInsert += candidateId to a
            }
        }
        animalsToInsert.forEach { (newId, a) ->
            val mapped = a.copy(
                id = newId,
                madreId = a.madreId?.let { animalIdMap[it] ?: it },
                padreId = a.padreId?.let { animalIdMap[it] ?: it },
                potreroId = a.potreroId?.let { potreroIdMap[it] ?: it },
                loteId = a.loteId?.let { loteIdMap[it] ?: it }
            )
            ops += subCol(CloudSchema.SUB_ANIMALES).document(newId.toString()) to mapped.toCloudCreateMap(uids)
        }

        // 4. Inventario
        val invIdMap = mutableMapOf<Long, Long>()
        payload.inventario.forEach { item ->
            val key = item.nombre.trim().lowercase()
            val existingId = invIdx.nameToId[key]
            if (existingId != null && existingId > 0L) {
                invIdMap[item.id] = existingId
                skipped++
            } else {
                val id = reserveNonCollidingId(item.id, invIdx.usedIds)
                invIdMap[item.id] = id
                ops += subCol(CloudSchema.SUB_INVENTARIO).document(id.toString()) to item.copy(id = id).toCloudCreateMap(uids)
            }
        }

        // 5. Raciones
        payload.raciones.forEach { r ->
            val key = r.nombre.trim().lowercase()
            if (key in racionesIdx.keys) {
                skipped++
            } else {
                racionesIdx.keys += key
                val id = reserveNonCollidingId(r.id, racionesIdx.usedIds)
                ops += subCol(CloudSchema.SUB_RACIONES).document(id.toString()) to r.copy(id = id).toCloudCreateMap(uids)
            }
        }

        // 6. Pesajes
        payload.pesajes.forEach { p ->
            val mappedAnimal = animalIdMap[p.animalId] ?: p.animalId
            val k = "$mappedAnimal|${p.fecha}|${p.pesoKg}"
            if (k in pesajesIdx.keys) skipped++ else {
                pesajesIdx.keys += k
                val id = reserveNonCollidingId(p.id, pesajesIdx.usedIds)
                ops += subCol(CloudSchema.SUB_PESAJES).document(id.toString()) to p.copy(id = id, animalId = mappedAnimal).toCloudCreateMap(uids)
            }
        }

        // 7. Encastes (incluye remapeo de ovejaIdsCsv)
        val encasteIdMap = mutableMapOf<Long, Long>()
        payload.encastes.forEach { e ->
            val mappedCarnero = animalIdMap[e.carneroId] ?: e.carneroId
            val mappedOvejasCsv = remapCsvIds(e.ovejaIdsCsv, animalIdMap)
            val k = "$mappedCarnero|${e.fechaInicio}|$mappedOvejasCsv"
            if (k in encastesIdx.keys) skipped++ else {
                encastesIdx.keys += k
                val id = reserveNonCollidingId(e.id, encastesIdx.usedIds)
                encasteIdMap[e.id] = id
                ops += subCol(CloudSchema.SUB_ENCASTES).document(id.toString()) to e.copy(
                    id = id,
                    carneroId = mappedCarnero,
                    ovejaIdsCsv = mappedOvejasCsv
                ).toCloudCreateMap(uids)
            }
        }

        // 8. Gestaciones
        payload.gestaciones.forEach { g ->
            val mappedOveja = animalIdMap[g.ovejaId] ?: g.ovejaId
            val k = "$mappedOveja|${g.fechaDiagnostico}|${g.estadoGestacion}"
            if (k in gestacionesIdx.keys) skipped++ else {
                gestacionesIdx.keys += k
                val id = reserveNonCollidingId(g.id, gestacionesIdx.usedIds)
                ops += subCol(CloudSchema.SUB_GESTACIONES).document(id.toString()) to g.copy(
                    id = id,
                    ovejaId = mappedOveja,
                    carneroId = g.carneroId?.let { animalIdMap[it] ?: it },
                    encasteId = g.encasteId?.let { encasteIdMap[it] ?: it }
                ).toCloudCreateMap(uids)
            }
        }

        // 9. Partos
        payload.partos.forEach { pa ->
            val mappedMadre = animalIdMap[pa.madreId] ?: pa.madreId
            val k = "$mappedMadre|${pa.fechaParto}|${pa.cantidadCrias}"
            if (k in partosIdx.keys) skipped++ else {
                partosIdx.keys += k
                val id = reserveNonCollidingId(pa.id, partosIdx.usedIds)
                ops += subCol(CloudSchema.SUB_PARTOS).document(id.toString()) to pa.copy(
                    id = id,
                    madreId = mappedMadre,
                    padreId = pa.padreId?.let { animalIdMap[it] ?: it }
                ).toCloudCreateMap(uids)
            }
        }

        // 10. Sanidad
        payload.sanidad.forEach { s ->
            val mappedAnimal = s.animalId?.let { animalIdMap[it] ?: it }
            val k = "$mappedAnimal|${s.fecha}|${s.diagnostico.lowercase()}"
            if (k in sanidadIdx.keys) skipped++ else {
                sanidadIdx.keys += k
                val id = reserveNonCollidingId(s.id, sanidadIdx.usedIds)
                ops += subCol(CloudSchema.SUB_SANIDAD).document(id.toString()) to s.copy(id = id, animalId = mappedAnimal).toCloudCreateMap(uids)
            }
        }

        // 11. Movimientos de Potrero (incluye remapeo de animalIdsCsv)
        payload.movimientosPotrero.forEach { m ->
            val mappedDest = potreroIdMap[m.potreroDestinoId] ?: m.potreroDestinoId
            val mappedCsv = remapCsvIds(m.animalIdsCsv, animalIdMap)
            val k = "$mappedDest|${m.fechaMovimiento}|$mappedCsv"
            if (k in movPotreroIdx.keys) skipped++ else {
                movPotreroIdx.keys += k
                val id = reserveNonCollidingId(m.id, movPotreroIdx.usedIds)
                ops += subCol(CloudSchema.SUB_MOV_POTRERO).document(id.toString()) to m.copy(
                    id = id,
                    potreroOrigenId = m.potreroOrigenId?.let { potreroIdMap[it] ?: it },
                    potreroDestinoId = mappedDest,
                    animalIdsCsv = mappedCsv
                ).toCloudCreateMap(uids)
            }
        }

        // 12. Movimientos de Inventario
        payload.movimientosInventario.forEach { mi ->
            val mappedItem = invIdMap[mi.itemId] ?: mi.itemId
            val k = "$mappedItem|${mi.fecha}|${mi.cantidad}"
            if (k in movInvIdx.keys) skipped++ else {
                movInvIdx.keys += k
                val id = reserveNonCollidingId(mi.id, movInvIdx.usedIds)
                ops += subCol(CloudSchema.SUB_MOV_INVENTARIO).document(id.toString()) to mi.copy(id = id, itemId = mappedItem).toCloudCreateMap(uids)
            }
        }

        // 13. Transacciones Económicas
        payload.transacciones.forEach { tx ->
            val k = "${tx.tipo}|${tx.fecha}|${tx.montoClp}|${tx.categoria.lowercase()}"
            if (k in txIdx.keys) skipped++ else {
                txIdx.keys += k
                val id = reserveNonCollidingId(tx.id, txIdx.usedIds)
                ops += subCol(CloudSchema.SUB_TRANSACCIONES).document(id.toString()) to tx.copy(
                    id = id,
                    animalId = tx.animalId?.let { animalIdMap[it] ?: it },
                    loteId = tx.loteId?.let { loteIdMap[it] ?: it }
                ).toCloudCreateMap(uids)
            }
        }

        // 14. Destetes
        payload.destetes.forEach { d ->
            val mappedCordero = animalIdMap[d.corderoId] ?: d.corderoId
            val k = "$mappedCordero|${d.fecha}"
            if (k in desteteIdx.keys) skipped++ else {
                desteteIdx.keys += k
                val id = reserveNonCollidingId(d.id, desteteIdx.usedIds)
                ops += subCol(CloudSchema.SUB_DESTETES).document(id.toString()) to d.copy(
                    id = id,
                    corderoId = mappedCordero,
                    madreId = d.madreId?.let { animalIdMap[it] ?: it },
                    loteDestinoId = d.loteDestinoId?.let { loteIdMap[it] ?: it }
                ).toCloudCreateMap(uids)
            }
        }

        var written = 0
        for (chunk in ops.chunked(350)) {
            val batch = cloudRepo.db.batch()
            chunk.forEach { (ref, data) -> batch.set(ref, data) }
            batch.commit().await()
            written += chunk.size
        }

        val auditBatch = cloudRepo.db.batch()
        cloudRepo.appendAuditLog(
            auditBatch, uids, auditAction, "Migración/Respaldo", cloudRepo.criaderoId,
            payload.predioNombre, auditNote,
            "Duplicados omitidos: $skipped",
            "Registros cargados: $written"
        )
        auditBatch.commit().await()

        return written to skipped
    }
}
