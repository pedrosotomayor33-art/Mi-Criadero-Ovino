package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.*
import com.example.ui.CriaderoUiState
import com.example.ui.CriaderoViewModel
import com.example.ui.components.DropdownField
import com.example.ui.components.KpiMetricCard
import com.example.ui.theme.*
import com.example.util.ChileanFormatters
import com.example.util.ReportExporter
import kotlinx.coroutines.launch

@Composable
fun ManagementScreen(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    initialTab: Int = 0
) {
    var activeTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    var showAddInventory by remember { mutableStateOf(false) }
    var movementForItem by remember { mutableStateOf<InventarioItemEntity?>(null) }
    var showAddTx by remember { mutableStateOf(false) }

    val tabs = listOf("Inventario", "Economía", "Informes", "Alertas", "Historial", "Equipo y Nube")

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        floatingActionButton = {
            if (state.canEdit && (activeTab == 0 || activeTab == 1)) {
                FloatingActionButton(
                    onClick = {
                        when (activeTab) {
                            0 -> showAddInventory = true
                            1 -> showAddTx = true
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "Agregar registro")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            ScrollableTabRow(selectedTabIndex = activeTab, edgePadding = 12.dp) {
                tabs.forEachIndexed { idx, title ->
                    Tab(
                        selected = activeTab == idx,
                        onClick = { activeTab = idx },
                        text = { Text(title, maxLines = 1) }
                    )
                }
            }

            when (activeTab) {
                0 -> InventoryTab(
                    state = state,
                    viewModel = viewModel,
                    onMoveStock = { movementForItem = it }
                )
                1 -> EconomyTab(state = state, viewModel = viewModel)
                2 -> ReportsTab(state = state, viewModel = viewModel)
                3 -> AlertsTab(state = state)
                4 -> HistoryAndTrashTab(state = state, viewModel = viewModel)
                5 -> TeamCloudAndBackupTab(state = state, viewModel = viewModel)
            }
        }
    }

    if (showAddInventory) AddInventarioDialog(viewModel = viewModel) { showAddInventory = false }
    movementForItem?.let { item ->
        StockMovementDialog(item = item, viewModel = viewModel) { movementForItem = null }
    }
    if (showAddTx) AddTransaccionDialog(state = state, viewModel = viewModel) { showAddTx = false }
}

@Composable
private fun InventoryTab(
    state: CriaderoUiState,
    viewModel: CriaderoViewModel,
    onMoveStock: (InventarioItemEntity) -> Unit
) {
    val lowStockCount = state.inventario.count { it.cantidadDisponible <= it.stockMinimo }
    var pendingDeleteInv by remember { mutableStateOf<InventarioItemEntity?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            KpiMetricCard(
                title = "Bodega e Insumos",
                value = "${state.inventario.size} productos",
                subtitle = if (lowStockCount > 0) "$lowStockCount con stock bajo" else "Stock saludable",
                icon = Icons.Outlined.Inventory2,
                accentColor = if (lowStockCount > 0) CrimsonAlert else MeadowGreen
            )
        }
        items(state.inventario, key = { it.id }) { item ->
            val low = item.cantidadDisponible <= item.stockMinimo
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, if (low) CrimsonAlert else MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(item.nombre, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Surface(
                            color = if (low) CrimsonSoft else SoftMint,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "${ChileanFormatters.formatNumber(item.cantidadDisponible)} ${item.unidad}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (low) CrimsonAlert else ForestGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Text("${item.categoria} · Mínimo: ${item.stockMinimo} ${item.unidad}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    item.fechaVencimiento?.let {
                        Text("Vence: ${ChileanFormatters.formatDate(it)}", style = MaterialTheme.typography.labelSmall, color = EarthTerracotta)
                    }
                    if (state.canEdit) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onMoveStock(item) }) {
                                Text("Entrada / Salida")
                            }
                            TextButton(
                                onClick = { pendingDeleteInv = item },
                                colors = ButtonDefaults.textButtonColors(contentColor = CrimsonAlert)
                            ) { Text("Eliminar") }
                        }
                    }
                }
            }
        }
    }

    pendingDeleteInv?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDeleteInv = null },
            title = { Text("¿Enviar insumo a Papelera?") },
            text = { Text("Se enviará '${item.nombre}' a la Papelera recuperable.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteInventarioItem(item)
                        pendingDeleteInv = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert)
                ) { Text("Enviar a Papelera") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteInv = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun EconomyTab(state: CriaderoUiState, viewModel: CriaderoViewModel) {
    val ingresos = state.transacciones.filter { it.tipo == "Ingreso" }.sumOf { it.montoClp }
    val gastos = state.transacciones.filter { it.tipo == "Gasto" }.sumOf { it.montoClp }
    val utilidad = ingresos - gastos
    val kgVendidos = state.transacciones.filter { it.tipo == "Ingreso" }.sumOf { it.cantidadKg ?: 0.0 }
    val costoPorKg = if (kgVendidos > 0) gastos / kgVendidos else 0.0
    val activosCount = state.animales.count { it.estado == "Activo" }.coerceAtLeast(1)
    val rentabilidadPorAnimal = utilidad / activosCount
    var pendingDeleteTx by remember { mutableStateOf<TransaccionEconomicaEntity?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KpiMetricCard(
                    title = "Ingresos",
                    value = ChileanFormatters.formatClp(ingresos),
                    subtitle = "${kgVendidos.toInt()} kg vendidos",
                    icon = Icons.Outlined.ArrowUpward,
                    accentColor = MeadowGreen,
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    title = "Gastos",
                    value = ChileanFormatters.formatClp(gastos),
                    subtitle = if (costoPorKg > 0) "Costo: ${ChileanFormatters.formatClp(costoPorKg)}/kg" else "Control operativo",
                    icon = Icons.Outlined.ArrowDownward,
                    accentColor = CrimsonAlert,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            KpiMetricCard(
                title = "Utilidad Neta del Criadero",
                value = ChileanFormatters.formatClp(utilidad),
                subtitle = "Rentabilidad prom.: ${ChileanFormatters.formatClp(rentabilidadPorAnimal)} / ovino activo",
                icon = Icons.Outlined.AccountBalanceWallet,
                accentColor = if (utilidad >= 0) ForestGreen else CrimsonAlert
            )
        }
        items(state.transacciones, key = { it.id }) { tx ->
            val isIncome = tx.tipo == "Ingreso"
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isIncome) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
                        contentDescription = null,
                        tint = if (isIncome) MeadowGreen else CrimsonAlert
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(tx.categoria, fontWeight = FontWeight.Bold)
                        Text("${ChileanFormatters.formatDate(tx.fecha)} · ${tx.descripcion}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = (if (isIncome) "+" else "-") + ChileanFormatters.formatClp(tx.montoClp),
                            fontWeight = FontWeight.Bold,
                            color = if (isIncome) MeadowGreen else CrimsonAlert
                        )
                        if (state.canEdit) {
                            IconButton(onClick = { pendingDeleteTx = tx }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Eliminar", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDeleteTx?.let { tx ->
        AlertDialog(
            onDismissRequest = { pendingDeleteTx = null },
            title = { Text("¿Enviar movimiento a Papelera?") },
            text = { Text("Se enviará '${tx.tipo}: ${tx.categoria}' (${ChileanFormatters.formatClp(tx.montoClp)}) a la Papelera recuperable.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTransaccion(tx)
                        pendingDeleteTx = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert)
                ) { Text("Enviar a Papelera") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteTx = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun ReportsTab(state: CriaderoUiState, viewModel: CriaderoViewModel) {
    val context = LocalContext.current
    var selectedPeriod by remember { mutableStateOf("Todo") }
    var selectedReport by remember { mutableStateOf("Inventario general") }

    val periods = listOf("Último mes", "Trimestre", "Año actual", "Todo")
    val reportTypes = listOf(
        "Inventario general", "Nacimientos", "Mortalidad", "Ventas",
        "Pesajes y Crecimiento (GMD)", "Reproducción y Fertilidad", "Destete",
        "Salud", "Gastos e Ingresos", "Producción de carne"
    )

    val minFecha = remember(selectedPeriod) {
        val now = System.currentTimeMillis()
        when (selectedPeriod) {
            "Último mes" -> now - 30L * 86_400_000L
            "Trimestre" -> now - 90L * 86_400_000L
            "Año actual" -> now - 365L * 86_400_000L
            else -> 0L
        }
    }

    val (summaryLines, headers, rows) = remember(selectedReport, minFecha, state) {
        buildReportData(selectedReport, minFecha, state, viewModel)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            DropdownField(
                label = "Tipo de informe",
                selectedText = selectedReport,
                options = reportTypes,
                onSelect = { selectedReport = reportTypes[it] }
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                periods.forEach { p ->
                    FilterChip(selected = selectedPeriod == p, onClick = { selectedPeriod = p }, label = { Text(p) })
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        ReportExporter.sharePdfReport(
                            context = context,
                            predioNombre = state.predioNombre,
                            title = "$selectedReport ($selectedPeriod)",
                            summaryLines = summaryLines,
                            headers = headers,
                            rows = rows
                        ).onFailure {
                            viewModel.notifyMessage("No se pudo generar el PDF")
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Exportar PDF")
                }
                OutlinedButton(
                    onClick = {
                        ReportExporter.shareCsvReport(
                            context = context,
                            title = "$selectedReport ($selectedPeriod)",
                            headers = headers,
                            rows = rows
                        ).onFailure {
                            viewModel.notifyMessage("No se pudo exportar Excel/CSV")
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Excel (CSV)")
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Resumen: $selectedReport", fontWeight = FontWeight.Bold, color = ForestGreen)
                    summaryLines.forEach { line ->
                        Text("• $line", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        items(rows.take(25)) { row ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(row.firstOrNull() ?: "", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text(row.drop(1).joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun AlertsTab(state: CriaderoUiState) {
    var filter by remember { mutableStateOf("Todas") }
    val filtered = remember(state.alertas, filter) {
        if (filter == "Todas") state.alertas else state.alertas.filter { it.prioridad == filter }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Todas", "Atrasada", "Hoy", "Próxima").forEach { f ->
                val count = if (f == "Todas") state.alertas.size else state.alertas.count { it.prioridad == f }
                FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text("$f ($count)") })
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (filtered.isEmpty()) {
                item {
                    Text("No hay alertas en esta categoría.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(filtered, key = { it.id }) { al ->
                    val color = when (al.prioridad) {
                        "Atrasada" -> CrimsonAlert
                        "Hoy" -> EarthTerracotta
                        else -> MeadowGreen
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
                    ) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = color, shape = RoundedCornerShape(8.dp)) {
                                Text(al.prioridad, style = MaterialTheme.typography.labelSmall, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(al.titulo, fontWeight = FontWeight.Bold)
                                Text(al.detalle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${al.modulo} · ${ChileanFormatters.formatDate(al.fechaObjetivo)}", style = MaterialTheme.typography.labelSmall, color = color)
                            }
                        }
                    }
                }
            }
        }
    }
}



private fun buildReportData(
    reportType: String,
    minFecha: Long,
    state: CriaderoUiState,
    viewModel: CriaderoViewModel
): Triple<List<String>, List<String>, List<List<String>>> {
    val animalById = state.animales.associateBy { it.id }
    return when (reportType) {
        "Nacimientos" -> {
            val list = state.partos.filter { it.fechaParto >= minFecha }
            val vivos = list.sumOf { it.criasVivas }
            val total = list.sumOf { it.cantidadCrias }
            val prolif = if (list.isNotEmpty()) total.toDouble() / list.size else 0.0
            Triple(
                listOf("Partos registrados: ${list.size}", "Crías vivas: $vivos", "Prolificidad promedio: ${ChileanFormatters.formatNumber(prolif, 2)} crías/parto"),
                listOf("Fecha", "Madre", "Tipo", "Vivas/Muertas"),
                list.map { listOf(ChileanFormatters.formatDate(it.fechaParto), animalById[it.madreId]?.arete ?: "-", it.tipoParto, "${it.criasVivas}/${it.criasMuertas}") }
            )
        }
        "Mortalidad" -> {
            val bajas = state.animales.filter { it.estado == "Muerte" && it.fechaIngreso >= minFecha }
            val mortinatos = state.partos.filter { it.fechaParto >= minFecha }.sumOf { it.criasMuertas }
            Triple(
                listOf("Muertes registradas: ${bajas.size}", "Mortinatos en partos: $mortinatos"),
                listOf("Arete", "Categoría", "Raza", "Observaciones"),
                bajas.map { listOf(it.arete, ChileanFormatters.animalCategory(it), it.raza, it.observaciones) }
            )
        }
        "Ventas" -> {
            val ventas = state.transacciones.filter { it.tipo == "Ingreso" && it.fecha >= minFecha }
            val totalClp = ventas.sumOf { it.montoClp }
            Triple(
                listOf("Operaciones de venta: ${ventas.size}", "Total ingresos: ${ChileanFormatters.formatClp(totalClp)}"),
                listOf("Fecha", "Categoría", "Monto CLP", "Detalle"),
                ventas.map { listOf(ChileanFormatters.formatDate(it.fecha), it.categoria, ChileanFormatters.formatClp(it.montoClp), it.descripcion) }
            )
        }
        "Pesajes y Crecimiento (GMD)" -> {
            val activos = state.animales.filter { it.estado == "Activo" }
            val rows = activos.map { a ->
                val stats = viewModel.repo.calculateWeightStats(a, state.pesajes.filter { it.animalId == a.id })
                listOf(a.arete, a.raza, ChileanFormatters.formatKg(stats.pesoActualKg), stats.gmdGramsPerDay?.let { "${it.toInt()} g/d" } ?: "-")
            }
            Triple(
                listOf("Ovinos activos evaluados: ${activos.size}", "Peso promedio rebaño: ${ChileanFormatters.formatKg(if (activos.isNotEmpty()) activos.map { it.pesoActualKg }.average() else 0.0)}"),
                listOf("Arete", "Raza", "Peso Actual", "GMD"),
                rows
            )
        }
        "Reproducción y Fertilidad" -> {
            val hembras = state.animales.filter { it.estado == "Activo" && it.sexo == "Hembra" }
            val prenadas = hembras.count { it.prenada }
            val fert = if (hembras.isNotEmpty()) (prenadas * 100.0) / hembras.size else 0.0
            Triple(
                listOf("Hembras activas: ${hembras.size}", "Preñadas actuales: $prenadas (${fert.toInt()}%)", "Encastes registrados: ${state.encastes.size}"),
                listOf("Oveja", "Estado Gest.", "Fetos", "Parto Probable"),
                state.gestaciones.map { listOf(animalById[it.ovejaId]?.arete ?: "-", it.estadoGestacion, "${it.numeroFetos}", ChileanFormatters.formatDate(it.fechaProbableParto)) }
            )
        }
        "Destete" -> {
            val list = state.destetes.filter { it.fecha >= minFecha }
            val prom = if (list.isNotEmpty()) list.map { it.pesoKg }.average() else 0.0
            Triple(
                listOf("Destetes realizados: ${list.size}", "Peso promedio al destete: ${ChileanFormatters.formatKg(prom)}"),
                listOf("Fecha", "Cordero", "Peso", "Tipo"),
                list.map { listOf(ChileanFormatters.formatDate(it.fecha), animalById[it.corderoId]?.arete ?: "-", ChileanFormatters.formatKg(it.pesoKg), it.tipoDestete) }
            )
        }
        "Salud" -> {
            val list = state.sanidad.filter { it.fecha >= minFecha }
            Triple(
                listOf("Manejos sanitarios: ${list.size}", "En tratamiento activo: ${list.count { it.evolucion == "En tratamiento" }}"),
                listOf("Fecha", "Sujeto", "Manejo", "Diagnóstico / Evolución"),
                list.map { listOf(ChileanFormatters.formatDate(it.fecha), it.animalId?.let { id -> animalById[id]?.arete } ?: (it.loteNombre ?: "Lote"), it.tipoManejo, "${it.diagnostico} (${it.evolucion})") }
            )
        }
        "Gastos e Ingresos" -> {
            val txs = state.transacciones.filter { it.fecha >= minFecha }
            val ing = txs.filter { it.tipo == "Ingreso" }.sumOf { it.montoClp }
            val gas = txs.filter { it.tipo == "Gasto" }.sumOf { it.montoClp }
            Triple(
                listOf("Ingresos: ${ChileanFormatters.formatClp(ing)}", "Gastos: ${ChileanFormatters.formatClp(gas)}", "Utilidad: ${ChileanFormatters.formatClp(ing - gas)}"),
                listOf("Fecha", "Tipo", "Categoría", "Monto"),
                txs.map { listOf(ChileanFormatters.formatDate(it.fecha), it.tipo, it.categoria, ChileanFormatters.formatClp(it.montoClp)) }
            )
        }
        "Producción de carne" -> {
            val activos = state.animales.filter { it.estado == "Activo" }
            val biomasa = activos.sumOf { it.pesoActualKg }
            val engorda = activos.filter { it.proposito == "Engorda" }
            Triple(
                listOf("Biomasa en pie total: ${ChileanFormatters.formatKg(biomasa)}", "Ovinos en engorda: ${engorda.size} (${ChileanFormatters.formatKg(engorda.sumOf { it.pesoActualKg })})"),
                listOf("Arete", "Propósito", "Peso Vivo", "Categoría"),
                activos.map { listOf(it.arete, it.proposito, ChileanFormatters.formatKg(it.pesoActualKg), ChileanFormatters.animalCategory(it)) }
            )
        }
        else -> { // Inventario general
            val activos = state.animales.filter { it.estado == "Activo" }
            Triple(
                listOf("Total ovinos activos: ${activos.size}", "Peso total: ${ChileanFormatters.formatKg(activos.sumOf { it.pesoActualKg })}"),
                listOf("Arete", "Raza", "Categoría", "Peso Actual"),
                activos.map { listOf(it.arete, it.raza, ChileanFormatters.animalCategory(it), ChileanFormatters.formatKg(it.pesoActualKg)) }
            )
        }
    }
}

@Composable
private fun AddInventarioDialog(viewModel: CriaderoViewModel, onDismiss: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("Medicamentos") }
    var unidad by remember { mutableStateOf("ml") }
    var cantStr by remember { mutableStateOf("100") }
    var minStr by remember { mutableStateOf("20") }
    var costoStr by remember { mutableStateOf("0") }
    val cats = listOf("Medicamentos", "Vacunas", "Antiparasitarios", "Alimentos", "Fardos", "Minerales", "Insumos veterinarios")
    val units = listOf("ml", "dosis", "kg", "fardos", "unidades")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo Insumo en Bodega") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre del producto *") }, singleLine = true)
                DropdownField(label = "Categoría", selectedText = categoria, options = cats, onSelect = { categoria = cats[it] })
                DropdownField(label = "Unidad", selectedText = unidad, options = units, onSelect = { unidad = units[it] })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = cantStr, onValueChange = { cantStr = it }, label = { Text("Cantidad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = minStr, onValueChange = { minStr = it }, label = { Text("Stock mín.") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = costoStr, onValueChange = { costoStr = it }, label = { Text("Costo unitario (CLP)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                viewModel.saveInventarioItem(
                    InventarioItemEntity(
                        nombre = nombre.trim(),
                        categoria = categoria,
                        unidad = unidad,
                        cantidadDisponible = cantStr.replace(",", ".").toDoubleOrNull() ?: 0.0,
                        stockMinimo = minStr.replace(",", ".").toDoubleOrNull() ?: 0.0,
                        ultimoCostoUnitarioClp = costoStr.toDoubleOrNull() ?: 0.0
                    ),
                    onSuccess = onDismiss
                )
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun StockMovementDialog(item: InventarioItemEntity, viewModel: CriaderoViewModel, onDismiss: () -> Unit) {
    var tipo by remember { mutableStateOf("Entrada / Compra") }
    var cantStr by remember { mutableStateOf("10") }
    var costoStr by remember { mutableStateOf("0") }
    var nota by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Movimiento: ${item.nombre}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DropdownField(
                    label = "Tipo",
                    selectedText = tipo,
                    options = listOf("Entrada / Compra", "Salida / Consumo"),
                    onSelect = { tipo = listOf("Entrada / Compra", "Salida / Consumo")[it] }
                )
                OutlinedTextField(value = cantStr, onValueChange = { cantStr = it }, label = { Text("Cantidad (${item.unidad})") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                if (tipo.startsWith("Entrada")) {
                    OutlinedTextField(value = costoStr, onValueChange = { costoStr = it }, label = { Text("Costo total compra (CLP)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                }
                OutlinedTextField(value = nota, onValueChange = { nota = it }, label = { Text("Nota / Comprobante") })
            }
        },
        confirmButton = {
            Button(onClick = {
                viewModel.registrarMovimientoInventario(
                    itemId = item.id,
                    tipo = tipo,
                    cantidad = cantStr.replace(",", ".").toDoubleOrNull() ?: 0.0,
                    costoTotalClp = costoStr.toDoubleOrNull() ?: 0.0,
                    nota = nota,
                    onSuccess = onDismiss
                )
            }) { Text("Registrar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun AddTransaccionDialog(state: CriaderoUiState, viewModel: CriaderoViewModel, onDismiss: () -> Unit) {
    var tipo by remember { mutableStateOf("Ingreso") }
    val incomeCats = listOf("Venta de corderos", "Venta de reproductores", "Venta de ovejas de descarte", "Venta de lana", "Otros ingresos")
    val expenseCats = listOf("Alimentación", "Medicamentos", "Vacunas", "Fertilizantes", "Mantención", "Mano de obra", "Compra de animales", "Otros gastos")
    var categoria by remember(tipo) { mutableStateOf(if (tipo == "Ingreso") incomeCats.first() else expenseCats.first()) }
    var montoStr by remember { mutableStateOf("") }
    var kgStr by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Movimiento Económico") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tipo == "Ingreso", onClick = { tipo = "Ingreso" }, label = { Text("Ingreso / Venta") })
                    FilterChip(selected = tipo == "Gasto", onClick = { tipo = "Gasto" }, label = { Text("Gasto") })
                }
                val cats = if (tipo == "Ingreso") incomeCats else expenseCats
                DropdownField(label = "Categoría", selectedText = categoria, options = cats, onSelect = { categoria = cats[it] })
                OutlinedTextField(value = montoStr, onValueChange = { montoStr = it }, label = { Text("Monto (CLP $) *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                if (tipo == "Ingreso") {
                    OutlinedTextField(value = kgStr, onValueChange = { kgStr = it }, label = { Text("Kilos vendidos (opcional)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Descripción") })
            }
        },
        confirmButton = {
            Button(onClick = {
                viewModel.saveTransaccion(
                    TransaccionEconomicaEntity(
                        tipo = tipo,
                        categoria = categoria,
                        montoClp = montoStr.toDoubleOrNull() ?: 0.0,
                        fecha = System.currentTimeMillis(),
                        cantidadKg = kgStr.replace(",", ".").toDoubleOrNull(),
                        descripcion = desc.trim()
                    ),
                    onSuccess = onDismiss
                )
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}


