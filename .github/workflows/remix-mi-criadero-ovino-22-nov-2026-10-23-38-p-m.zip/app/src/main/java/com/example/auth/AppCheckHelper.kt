package com.example.auth

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.recaptcha.RecaptchaAppCheckProviderFactory

private const val TAG = "AppCheckInit"
private const val DEBUG_TOKEN_EXTRA = "FIREBASE_APPCHECK_DEBUG_TOKEN"
private const val DEBUG_STORE_PREFIX = "com.google.firebase.appcheck.debug.store."
private const val DEBUG_SECRET_KEY = "com.google.firebase.appcheck.debug.DEBUG_SECRET"
private const val RECAPTCHA_SITE_KEY_RES = "recaptcha_site_key"

/**
 * Configura Firebase App Check de forma segura y compatible sin bloquear compilaciones legítimas:
 * - En Debug: usa DebugAppCheckProviderFactory (y registra token si viene por Intent extra).
 * - En Release: usa RecaptchaAppCheckProviderFactory si `recaptcha_site_key` está configurado;
 *   si aún no se ha definido una clave de sitio, registra aviso diagnóstico sin bloquear la app.
 */
fun configureAppCheck(context: Context, intent: Intent?) {
    try {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }

        if (BuildConfig.DEBUG) {
            val debugToken = intent?.getStringExtra(DEBUG_TOKEN_EXTRA)
            if (!debugToken.isNullOrEmpty()) {
                val persistenceKey = FirebaseApp.getInstance().persistenceKey
                val prefs = context.getSharedPreferences(
                    "$DEBUG_STORE_PREFIX$persistenceKey",
                    Context.MODE_PRIVATE
                )
                // commit() síncrono obligatorio antes de instalar DebugAppCheckProviderFactory
                prefs.edit()
                    .putString(DEBUG_SECRET_KEY, debugToken)
                    .commit()
                Log.d(TAG, "App Check debug secret configurado desde Intent.")
            } else {
                Log.d(TAG, "DebugAppCheckProviderFactory usará el token debug del SDK.")
            }

            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
                DebugAppCheckProviderFactory.getInstance()
            )
            Log.d(TAG, "Firebase App Check (Debug) inicializado.")
        } else {
            val resId = context.resources.getIdentifier(RECAPTCHA_SITE_KEY_RES, "string", context.packageName)
            if (resId != 0) {
                val siteKey = context.getString(resId)
                if (siteKey.isNotBlank()) {
                    FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
                        RecaptchaAppCheckProviderFactory.getInstance(siteKey)
                    )
                    Log.d(TAG, "Firebase App Check (reCAPTCHA Enterprise) inicializado.")
                } else {
                    Log.w(TAG, "recaptcha_site_key está vacío; App Check en modo monitoreo/no forzado.")
                }
            } else {
                Log.w(TAG, "recaptcha_site_key no configurado; define este string en release antes de exigir App Check en Firestore.")
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "No se pudo inicializar Firebase App Check", e)
    }
}
