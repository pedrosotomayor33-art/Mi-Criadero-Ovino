const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const CRIADERO_ID = "criadero_principal";

const ADMIN_UID = "admin_principal_uid";
const ADMIN_EMAIL = "admin.principal@example.com";
const NEW_ADMIN_UID = "admin_relevo_uid";
const NEW_ADMIN_EMAIL = "admin.relevo@example.com";
const SOCIO1_UID = "socio_1_uid";
const SOCIO1_EMAIL = "socio1@example.com";
const SOCIO2_UID = "socio_2_uid";
const SOCIO2_EMAIL = "socio2@example.com";
const INTRUDER_UID = "intruder_uid";
const INTRUDER_EMAIL = "intruso@example.com";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(msOffset = 10000) {
  return new Date(Date.now() - msOffset);
}

function futureDate(msOffset = 60000) {
  return new Date(Date.now() + msOffset);
}

function adminContext(verified = true) {
  return testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: verified,
  });
}

function userContext(uid, email, verified = true) {
  return testEnv.authenticatedContext(uid, {
    email,
    email_verified: verified,
  });
}

async function seedBasicWorkspace() {
  const adminDb = adminContext(true).firestore();
  const wsRef = adminDb.collection("criaderos").doc(CRIADERO_ID);
  const created = pastDate(10000);
  await wsRef.set({
    nombrePredio: "Fundo Santa Elena · Biobío",
    adminUid: ADMIN_UID,
    adminEmail: ADMIN_EMAIL,
    socio1Email: SOCIO1_EMAIL,
    socio2Email: SOCIO2_EMAIL,
    pendingAdminEmail: "",
    memberUids: [ADMIN_UID],
    migratedFromLocal: true,
    createdAt: created,
    updatedAt: created,
  });
  await wsRef.collection("members").doc(ADMIN_UID).set({
    uid: ADMIN_UID,
    adminUid: ADMIN_UID,
    email: ADMIN_EMAIL,
    displayName: "Admin Principal",
    etiqueta: "Administrador",
    rol: "Administrador",
    activo: true,
    createdAt: created,
    updatedAt: created,
  });
  return { adminDb, wsRef, created };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("1. Usuario no autenticado: bloqueo total de lectura y escritura", async () => {
  await seedBasicWorkspace();
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const wsRef = unauthDb.collection("criaderos").doc(CRIADERO_ID);

  await assertFails(wsRef.get());
  await assertFails(wsRef.collection("animales").where("memberUids", "array-contains", ADMIN_UID).get());
  await assertFails(wsRef.collection("pesajes").where("memberUids", "array-contains", ADMIN_UID).get());
  await assertFails(wsRef.collection("sanidad").where("memberUids", "array-contains", ADMIN_UID).get());
  await assertFails(wsRef.collection("transacciones").where("memberUids", "array-contains", ADMIN_UID).get());
  await assertFails(wsRef.collection("auditLogs").where("memberUids", "array-contains", ADMIN_UID).get());
  await assertFails(wsRef.collection("backups").where("memberUids", "array-contains", ADMIN_UID).get());
  await assertFails(
    wsRef.set({
      nombrePredio: "Fake",
      adminUid: ADMIN_UID,
      adminEmail: ADMIN_EMAIL,
      memberUids: [ADMIN_UID],
      migratedFromLocal: false,
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
});

test("2. Correo no verificado o suplantado: bloqueado en creación y acceso", async () => {
  const unverifiedDb = userContext("unverified_uid", ADMIN_EMAIL, false).firestore();
  await assertFails(
    unverifiedDb.collection("criaderos").doc(CRIADERO_ID).set({
      nombrePredio: "Fundo Hack",
      adminUid: "unverified_uid",
      adminEmail: ADMIN_EMAIL,
      socio1Email: "",
      socio2Email: "",
      pendingAdminEmail: "",
      memberUids: ["unverified_uid"],
      migratedFromLocal: false,
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );

  // No se permite crear un criadero reclamando otro adminEmail diferente al token real
  const spoofEmailDb = userContext("spoof_uid", INTRUDER_EMAIL, true).firestore();
  await assertFails(
    spoofEmailDb.collection("criaderos").doc(CRIADERO_ID).set({
      nombrePredio: "Fundo Spoof",
      adminUid: "spoof_uid",
      adminEmail: ADMIN_EMAIL,
      socio1Email: "",
      socio2Email: "",
      pendingAdminEmail: "",
      memberUids: ["spoof_uid"],
      migratedFromLocal: false,
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
});

test("3. Validación estricta de TODOS los elementos de memberUids", async () => {
  const { wsRef, created } = await seedBasicWorkspace();
  const baseAnimal = {
    recordId: 101,
    arete: "CL-101",
    nombre: "Estrella",
    sexo: "Hembra",
    raza: "Suffolk Down",
    fechaNacimiento: Date.now() - 86400000 * 365,
    pesoNacimientoKg: 4.0,
    pesoActualKg: 60.0,
    tipoNacimiento: "Único",
    predioOrigen: "Propio",
    fechaIngreso: Date.now(),
    estado: "Activo",
    proposito: "Reproducción",
    prenada: false,
    destetado: true,
    observaciones: "",
    registroActivo: true,
    createdAt: created,
    updatedAt: created,
  };

  // Rechaza elemento vacío en índice 1
  await assertFails(
    wsRef.collection("animales").doc("101").set({
      ...baseAnimal,
      memberUids: [ADMIN_UID, ""],
    })
  );
  // Rechaza elemento no-string en índice 1
  await assertFails(
    wsRef.collection("animales").doc("101").set({
      ...baseAnimal,
      memberUids: [ADMIN_UID, 12345],
    })
  );
  // Rechaza UID con caracteres inválidos en índice 2
  await assertFails(
    wsRef.collection("animales").doc("101").set({
      ...baseAnimal,
      memberUids: [ADMIN_UID, SOCIO1_UID, "bad uid with spaces"],
    })
  );
  // Rechaza lista mayor a 5 elementos
  await assertFails(
    wsRef.collection("animales").doc("101").set({
      ...baseAnimal,
      memberUids: [ADMIN_UID, "u2", "u3", "u4", "u5", "u6"],
    })
  );
  // Acepta lista válida con todos los elementos válidos
  await assertSucceeds(
    wsRef.collection("animales").doc("101").set({
      ...baseAnimal,
      memberUids: [ADMIN_UID, SOCIO1_UID, SOCIO2_UID],
    })
  );
});

test("4. Administrador principal: CRUD completo, timestamp servidor, Papelera, AuditLog y Respaldo", async () => {
  const { wsRef, created } = await seedBasicWorkspace();

  const animalRef = wsRef.collection("animales").doc("101");
  await assertSucceeds(
    animalRef.set({
      recordId: 101,
      memberUids: [ADMIN_UID],
      arete: "CL-101",
      nombre: "Estrella",
      sexo: "Hembra",
      raza: "Suffolk Down",
      fechaNacimiento: Date.now() - 86400000 * 400,
      pesoNacimientoKg: 4.2,
      pesoActualKg: 64.5,
      tipoNacimiento: "Único",
      predioOrigen: "Propio",
      fechaIngreso: Date.now(),
      estado: "Activo",
      proposito: "Reproducción",
      prenada: false,
      destetado: true,
      observaciones: "Excelente madre",
      registroActivo: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Rechaza timestamp futuro falsificado
  await assertFails(
    wsRef.collection("animales").doc("103").set({
      recordId: 103,
      memberUids: [ADMIN_UID],
      arete: "CL-103",
      nombre: "",
      sexo: "Macho",
      raza: "Texel",
      fechaNacimiento: Date.now(),
      pesoNacimientoKg: 4.5,
      pesoActualKg: 45.0,
      tipoNacimiento: "Único",
      predioOrigen: "Propio",
      fechaIngreso: Date.now(),
      estado: "Activo",
      proposito: "Reproducción",
      prenada: false,
      destetado: false,
      observaciones: "",
      registroActivo: true,
      createdAt: futureDate(),
      updatedAt: futureDate(),
    })
  );

  // AuditLog: creación legítima permitida; suplantación, edición de payload y borrado PROHIBIDOS
  const logRef = wsRef.collection("auditLogs").doc("log_1");
  await assertSucceeds(
    logRef.set({
      memberUids: [ADMIN_UID],
      actorUid: ADMIN_UID,
      actorEmail: ADMIN_EMAIL,
      actorNombre: "Admin Principal",
      actorRol: "Administrador",
      accion: "CREAR",
      modulo: "Animales",
      entidadId: "101",
      entidadNombre: "CL-101 Estrella",
      resumen: "Alta de ovino",
      valorAnterior: "",
      valorNuevo: "Peso=64.5kg",
      fechaClienteMs: Date.now(),
      createdAt: created,
      updatedAt: created,
    })
  );
  // Intento de falsificar actorEmail
  await assertFails(
    wsRef.collection("auditLogs").doc("log_spoof").set({
      memberUids: [ADMIN_UID],
      actorUid: ADMIN_UID,
      actorEmail: SOCIO1_EMAIL,
      actorNombre: "Falso",
      actorRol: "Administrador",
      accion: "CREAR",
      modulo: "Animales",
      entidadId: "101",
      entidadNombre: "CL-101",
      resumen: "Spoof",
      valorAnterior: "",
      valorNuevo: "",
      fechaClienteMs: Date.now(),
      createdAt: created,
      updatedAt: created,
    })
  );
  // Intento de alterar resumen del log ya creado
  await assertFails(
    logRef.update({
      resumen: "Resumen adulterado",
      updatedAt: pastDate(500),
    })
  );
  // Intento de eliminar log
  await assertFails(logRef.delete());

  // Backup en la nube: solo el creador real
  await assertSucceeds(
    wsRef.collection("backups").doc("bkp_1").set({
      memberUids: [ADMIN_UID],
      nombre: "Respaldo Inicial",
      creadoPorUid: ADMIN_UID,
      creadoPorEmail: ADMIN_EMAIL,
      fechaMs: Date.now(),
      totalRegistros: 1,
      resumen: "1 ovino",
      payloadJson: "{\"app\":\"Mi Criadero Ovino\"}",
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertFails(
    wsRef.collection("backups").doc("bkp_spoof").set({
      memberUids: [ADMIN_UID],
      nombre: "Respaldo Spoof",
      creadoPorUid: SOCIO1_UID,
      creadoPorEmail: ADMIN_EMAIL,
      fechaMs: Date.now(),
      totalRegistros: 1,
      resumen: "1 ovino",
      payloadJson: "{}",
      createdAt: created,
      updatedAt: created,
    })
  );
});

test("5. Socios (Solo Consulta) vs Intrusos: bloqueo estricto de escritura en todos los módulos y aislamiento", async () => {
  const { wsRef, created } = await seedBasicWorkspace();
  await wsRef.collection("members").doc(SOCIO2_UID).set({
    uid: SOCIO2_UID,
    adminUid: ADMIN_UID,
    email: SOCIO2_EMAIL,
    displayName: "Socio Dos",
    etiqueta: "Socio 2",
    rol: "Consulta",
    activo: true,
    createdAt: created,
    updatedAt: created,
  });
  await wsRef.collection("animales").doc("201").set({
    recordId: 201,
    memberUids: [ADMIN_UID, SOCIO1_UID],
    arete: "CL-201",
    nombre: "Nube",
    sexo: "Hembra",
    raza: "Corriedale",
    fechaNacimiento: Date.now() - 86400000 * 300,
    pesoNacimientoKg: 4.0,
    pesoActualKg: 58.0,
    tipoNacimiento: "Mellizo",
    predioOrigen: "Propio",
    fechaIngreso: Date.now(),
    estado: "Activo",
    proposito: "Reproducción",
    prenada: true,
    destetado: true,
    observaciones: "",
    registroActivo: true,
    createdAt: created,
    updatedAt: created,
  });

  // Intruso no invitado: cero acceso
  const intruderDb = userContext(INTRUDER_UID, INTRUDER_EMAIL, true).firestore();
  const intruderWsRef = intruderDb.collection("criaderos").doc(CRIADERO_ID);
  await assertFails(intruderWsRef.get());
  await assertFails(intruderWsRef.collection("animales").doc("201").get());
  await assertFails(intruderWsRef.collection("animales").where("memberUids", "array-contains", ADMIN_UID).get());
  const emptyIntruderSnap = await assertSucceeds(
    intruderWsRef.collection("animales").where("memberUids", "array-contains", INTRUDER_UID).get()
  );
  assert.equal(emptyIntruderSnap.size, 0);

  // Socio 1 invitado: puede reclamar su UID (size + 1) pero NO inyectar terceros (size + 2)
  const s1Db = userContext(SOCIO1_UID, SOCIO1_EMAIL, true).firestore();
  const s1WsRef = s1Db.collection("criaderos").doc(CRIADERO_ID);
  await assertSucceeds(s1WsRef.get());
  await assertFails(
    s1WsRef.update({
      memberUids: [ADMIN_UID, SOCIO1_UID, INTRUDER_UID],
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    s1WsRef.update({
      memberUids: [ADMIN_UID, SOCIO1_UID],
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    s1WsRef.collection("members").doc(SOCIO1_UID).set({
      uid: SOCIO1_UID,
      adminUid: ADMIN_UID,
      email: SOCIO1_EMAIL,
      displayName: "Socio Uno",
      etiqueta: "Socio 1",
      rol: "Consulta",
      activo: true,
      createdAt: pastDate(900),
      updatedAt: pastDate(900),
    })
  );

  // Socio 1 NO puede ver PII de Socio 2
  await assertFails(s1WsRef.collection("members").doc(SOCIO2_UID).get());
  await assertFails(s1WsRef.collection("members").where("adminUid", "==", ADMIN_UID).get());

  // Socio 1 SÍ puede leer animales compartidos, pero NO sin filtro ni escribir nada en ningún módulo
  await assertSucceeds(s1WsRef.collection("animales").where("memberUids", "array-contains", SOCIO1_UID).get());
  await assertFails(s1WsRef.collection("animales").get());

  // Bloqueo de escalada y de escritura directa en TODOS los módulos críticos
  await assertFails(s1WsRef.update({ adminUid: SOCIO1_UID, updatedAt: pastDate(500) }));
  await assertFails(s1WsRef.update({ socio2Email: INTRUDER_EMAIL, updatedAt: pastDate(500) }));
  await assertFails(s1WsRef.collection("members").doc(SOCIO1_UID).update({ rol: "Administrador", updatedAt: pastDate(500) }));
  await assertFails(s1WsRef.collection("animales").doc("201").update({ pesoActualKg: 99.0, updatedAt: pastDate(500) }));
  await assertFails(s1WsRef.collection("animales").doc("201").delete());
  await assertFails(
    s1WsRef.collection("pesajes").doc("301").set({
      recordId: 301,
      memberUids: [ADMIN_UID, SOCIO1_UID],
      animalId: 201,
      fecha: Date.now(),
      pesoKg: 60.0,
      edadDias: 300,
      observaciones: "",
      registroActivo: true,
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    s1WsRef.collection("sanidad").doc("401").set({
      recordId: 401,
      memberUids: [ADMIN_UID, SOCIO1_UID],
      tipoManejo: "Tratamiento",
      diagnostico: "Pietín",
      fecha: Date.now(),
      sintomas: "",
      medicamento: "Antibiótico",
      principioActivo: "",
      dosis: 2.0,
      unidadDosis: "ml",
      viaAdministracion: "IM",
      duracionDias: 3,
      veterinario: "",
      evolucion: "En tratamiento",
      observaciones: "",
      registroActivo: true,
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    s1WsRef.collection("transacciones").doc("501").set({
      recordId: 501,
      memberUids: [ADMIN_UID, SOCIO1_UID],
      tipo: "Gasto",
      categoria: "Insumos",
      montoClp: 50000,
      fecha: Date.now(),
      descripcion: "Intento de socio",
      registroActivo: true,
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    s1WsRef.collection("backups").doc("bkp_s1").set({
      memberUids: [ADMIN_UID, SOCIO1_UID],
      nombre: "Respaldo Socio",
      creadoPorUid: SOCIO1_UID,
      creadoPorEmail: SOCIO1_EMAIL,
      fechaMs: Date.now(),
      totalRegistros: 0,
      resumen: "",
      payloadJson: "{}",
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    s1WsRef.collection("auditLogs").doc("log_s1").set({
      memberUids: [ADMIN_UID, SOCIO1_UID],
      actorUid: SOCIO1_UID,
      actorEmail: SOCIO1_EMAIL,
      actorNombre: "Socio 1",
      actorRol: "Administrador",
      accion: "CREAR",
      modulo: "Equipo",
      entidadId: "1",
      entidadNombre: "Test",
      resumen: "Intento de log",
      valorAnterior: "",
      valorNuevo: "",
      fechaClienteMs: Date.now(),
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
});

test("6. Traspaso seguro de Administrador (pendingAdminEmail) y revocación del anterior", async () => {
  const { wsRef } = await seedBasicWorkspace();

  // Admin actual invita traspaso a NEW_ADMIN_EMAIL
  await assertSucceeds(
    wsRef.update({
      pendingAdminEmail: NEW_ADMIN_EMAIL,
      updatedAt: pastDate(2000),
    })
  );

  // Intruso NO puede robar el traspaso
  const intruderDb = userContext(INTRUDER_UID, INTRUDER_EMAIL, true).firestore();
  await assertFails(
    intruderDb.collection("criaderos").doc(CRIADERO_ID).update({
      adminUid: INTRUDER_UID,
      adminEmail: INTRUDER_EMAIL,
      pendingAdminEmail: "",
      memberUids: [INTRUDER_UID],
      updatedAt: pastDate(1000),
    })
  );

  // Nuevo Administrador designado sí acepta el traspaso y releva al Admin anterior
  const newAdminDb = userContext(NEW_ADMIN_UID, NEW_ADMIN_EMAIL, true).firestore();
  const newWsRef = newAdminDb.collection("criaderos").doc(CRIADERO_ID);
  await assertSucceeds(newWsRef.get());
  await assertSucceeds(
    newWsRef.update({
      adminUid: NEW_ADMIN_UID,
      adminEmail: NEW_ADMIN_EMAIL,
      pendingAdminEmail: "",
      memberUids: [NEW_ADMIN_UID],
      updatedAt: pastDate(900),
    })
  );
  await assertSucceeds(
    newWsRef.collection("members").doc(NEW_ADMIN_UID).set({
      uid: NEW_ADMIN_UID,
      adminUid: NEW_ADMIN_UID,
      email: NEW_ADMIN_EMAIL,
      displayName: "Nuevo Admin",
      etiqueta: "Administrador",
      rol: "Administrador",
      activo: true,
      createdAt: pastDate(800),
      updatedAt: pastDate(800),
    })
  );

  // Antiguo administrador pierde permisos inmediatamente
  const oldAdminDb = adminContext(true).firestore();
  await assertFails(oldAdminDb.collection("criaderos").doc(CRIADERO_ID).get());
  await assertFails(
    oldAdminDb.collection("criaderos").doc(CRIADERO_ID).update({
      nombrePredio: "Secuestro",
      updatedAt: pastDate(500),
    })
  );
});
